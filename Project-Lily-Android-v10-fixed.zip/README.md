# Project Lily — SQL Learning Lab

Project Lily is an offline Android SQL learning/editor app built around a real SQLite engine. It keeps the lightweight Lily UI while adding a practical learning workflow.

## Current features

- Real Android SQLite execution — not a fake interpreter
- Run the selected SQL only; with no selection, run all statements
- Multiple result tabs with row count and execution time
- Tap result headers to sort client-side; long-press cells to copy
- Share the active result as CSV from the Android share sheet
- Query history (last 30 runs) with tap-to-reload
- Named snippets stored locally
- Line numbers and current-line highlight
- Comment/uncomment selected lines with `-- Line` or Ctrl/Cmd + `/`
- SQL formatting helper
- Context-aware autocomplete for tables, columns, keywords and aggregate functions
- Plain-English common SQLite error explanations
- Practice mode with expected-result checking
- Readable `EXPLAIN QUERY PLAN` tree rendering
- Parks & Recreation and a bundled Northwind-style sample database
- Import `.sql`, `.db`, `.sqlite`, and `.sqlite3`
- Export the current working database as a `.db` backup
- Tablet layout with a live schema rail
- Project Lily pixel-lily branding

## Offline behavior

The app does not need a web connection or Python server to execute SQL. SQLite runs locally on the Android device and the sample databases are bundled in `app/src/main/assets/`.

## Open/build

Open the project root in Android Studio and build the `app` module. Minimum Android version is API 23; target/compile SDK is 35.
