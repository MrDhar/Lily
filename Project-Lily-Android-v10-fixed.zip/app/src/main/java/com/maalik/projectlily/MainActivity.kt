package com.maalik.projectlily

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.text.*
import android.text.style.ForegroundColorSpan
import android.text.style.ClickableSpan
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.view.*
import android.widget.*
import java.io.*
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var editor: LineNumberEditText
    private lateinit var status: TextView
    private lateinit var tabStrip: LinearLayout
    private lateinit var resultContainer: FrameLayout
    private lateinit var db: SQLiteDatabase
    private lateinit var dbFile: File
    private var schemaPanel: TextView? = null
    private var highlighting = false
    private var currentChallenge = -1
    private val challengeSql = listOf(
        "SELECT * FROM employee_demographics WHERE age > 40;",
        "SELECT d.first_name, d.last_name, s.salary FROM employee_demographics d JOIN employee_salary s ON d.employee_id=s.employee_id;",
        "SELECT first_name, salary FROM employee_salary ORDER BY salary DESC LIMIT 3;",
        "SELECT gender, COUNT(*) AS total FROM employee_demographics GROUP BY gender;",
        "SELECT * FROM parks_departments ORDER BY department_id;"
    )
    private val prefs by lazy { getSharedPreferences("lily", MODE_PRIVATE) }
    private val history = mutableListOf<String>()
    private val snippets = linkedMapOf<String, String>()

    private val blue=Color.rgb(178,90,130)
    private val green=Color.rgb(111,143,113); private val orange=Color.rgb(180,130,90)
    private val red=Color.rgb(192,96,91); private val white=Color.rgb(58,52,47)
    private val keywords = listOf("SELECT","FROM","WHERE","INSERT","INTO","VALUES","UPDATE","SET","DELETE","CREATE","TABLE","DROP","ALTER","JOIN","INNER","LEFT","RIGHT","FULL","OUTER","CROSS","NATURAL","ON","USING","GROUP","BY","ORDER","ASC","DESC","HAVING","LIMIT","OFFSET","AS","DISTINCT","AND","OR","NOT","NULL","IS","LIKE","GLOB","REGEXP","IN","BETWEEN","ESCAPE","UNION","INTERSECT","EXCEPT","ALL","CASE","WHEN","THEN","ELSE","END","COUNT","SUM","AVG","MIN","MAX","TOTAL","GROUP_CONCAT","OVER","PARTITION","ROWS","RANGE","GROUPS","UNBOUNDED","PRECEDING","FOLLOWING","CURRENT","ROW","ROW_NUMBER","RANK","DENSE_RANK","NTILE","LAG","LEAD","FIRST_VALUE","LAST_VALUE","NTH_VALUE","FILTER","WITH","RECURSIVE","EXISTS","RETURNING","PRIMARY","KEY","FOREIGN","REFERENCES","DEFAULT","UNIQUE","CHECK","CONSTRAINT","AUTOINCREMENT","GENERATED","ALWAYS","STORED","VIRTUAL","WITHOUT","ROWID","STRICT","COLLATE","INDEX","VIEW","TRIGGER","BEFORE","AFTER","INSTEAD","OF","FOR","EACH","BEGIN","CASCADE","RESTRICT","IF","RENAME","COLUMN","TO","ADD","TEMP","TEMPORARY","TRANSACTION","COMMIT","ROLLBACK","SAVEPOINT","RELEASE","ATTACH","DETACH","EXPLAIN","QUERY","PLAN","ANALYZE","VACUUM","PRAGMA","CAST","COALESCE","IFNULL","NULLIF","TRUE","FALSE","CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP")

    data class ResultTab(val button: Button, val view: View, val isError: Boolean, val csv: List<List<String>>?, val title: String)
    private val HISTORY_SEP = "\u0001"
    private val tabs=mutableListOf<ResultTab>(); private var activeTab=-1

    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        editor=findViewById(R.id.editor); status=findViewById(R.id.status); tabStrip=findViewById(R.id.tabStrip); resultContainer=findViewById(R.id.resultContainer); schemaPanel=findViewById(R.id.schemaPanel)
        loadPrefs(); copyBundledDatabase("Parks_and_Recreation.db")
        editor.setText("-- Select a query and tap Run.\n-- Select multiple statements to run only that selection.\nSELECT * FROM employee_demographics;\n\nSELECT first_name, salary\nFROM employee_salary\nORDER BY salary DESC;")
        editor.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){updateAutocomplete()};override fun afterTextChanged(e:Editable?){highlight(); editor.invalidate()}})
        editor.setSelection(editor.length())
        findViewById<Button>(R.id.runButton).setOnClickListener{runSelectedOrAll()}; findViewById<Button>(R.id.importButton).setOnClickListener{pickFile()}
        findViewById<Button>(R.id.schemaButton).setOnClickListener{showSchema()}; findViewById<Button>(R.id.dbButton).setOnClickListener{chooseDatabase()}; findViewById<Button>(R.id.resetButton).setOnClickListener{resetDatabase()}; findViewById<Button>(R.id.clearButton).setOnClickListener{editor.setText("")}
        findViewById<Button>(R.id.historyButton).setOnClickListener{showHistory()}; findViewById<Button>(R.id.snippetButton).setOnClickListener{showSnippetMenu()}; findViewById<Button>(R.id.practiceButton).setOnClickListener{showPractice()}; findViewById<Button>(R.id.checkPracticeButton).setOnClickListener{checkPractice()}
        findViewById<Button>(R.id.formatButton).setOnClickListener{editor.setText(formatSql(editor.text.toString())); editor.setSelection(editor.length())}
        findViewById<Button>(R.id.commentButton).setOnClickListener{toggleComment()}; findViewById<Button>(R.id.exportDbButton).setOnClickListener{exportDatabase()}; findViewById<Button>(R.id.exportCsvButton).setOnClickListener{exportCsv()}; findViewById<Button>(R.id.explainButton).setOnClickListener{showExplain(status.text.toString())}
        refreshSchemaPanel(); showPlaceholder()
    }

    private fun loadPrefs(){ val raw=prefs.getString("history","")?:""; if(raw.isNotEmpty()) history.addAll(raw.split(HISTORY_SEP)); prefs.all.filterKeys{it.startsWith("snippet:")}.forEach{snippets[it.key.removePrefix("snippet:")]=it.value as String} }
    private fun savePrefs(){prefs.edit().putString("history",history.take(30).joinToString(HISTORY_SEP)).apply()}

    private fun copyBundledDatabase(asset:String){ dbFile=File(filesDir,asset); if(!dbFile.exists()) assets.open(asset).use{i->dbFile.outputStream().use{i.copyTo(it)}}; db=SQLiteDatabase.openOrCreateDatabase(dbFile,null) }
    private fun pickFile(){val i=Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.type="*/*";startActivityForResult(i,77)}
    override fun onActivityResult(req:Int,res:Int,data:Intent?){super.onActivityResult(req,res,data);if(req==88&&res==RESULT_OK&&data?.data!=null){try{contentResolver.openOutputStream(data.data!!).use{out->dbFile.inputStream().use{it.copyTo(out!!)}};statusOk("Database exported")}catch(e:Exception){showError(e.message?:"Export failed")};return};if(req!=77||res!=RESULT_OK||data?.data==null)return;try{val uri=data.data!!;val name=uri.lastPathSegment?.lowercase()?: "";val bytes=contentResolver.openInputStream(uri)!!.use{it.readBytes()};if(name.endsWith(".db")||name.endsWith(".sqlite")||name.endsWith(".sqlite3")){db.close();dbFile.delete();dbFile.writeBytes(bytes);db=SQLiteDatabase.openOrCreateDatabase(dbFile,null);statusOk("Database imported");editor.setText("SELECT * FROM ${firstTable()};");refreshSchemaPanel();clearResults();showPlaceholder()}else importSqlScript(bytes.toString(Charsets.UTF_8))}catch(e:Exception){showError(e.message?:"Could not open file")}}
    private fun importSqlScript(sql:String){editor.setText(sql);try{db.beginTransaction();var count=0;for(s in splitSql(sql)){if(stripLineComments(s).isBlank())continue;if(!isQueryStatement(s))db.execSQL(s);count++};db.setTransactionSuccessful();db.endTransaction();statusOk("Imported — $count statement(s) applied");refreshSchemaPanel();clearResults();showPlaceholder()}catch(e:Exception){try{db.endTransaction()}catch(_:Exception){};showError(e.message?:"SQL error")}}
    private fun isQueryStatement(s:String)=s.trimStart().let{it.startsWith("SELECT",true)||it.startsWith("WITH",true)||it.startsWith("PRAGMA",true)||it.startsWith("EXPLAIN",true)}
    private fun leadingKeyword(s:String)=Regex("^\\s*([A-Za-z]+)").find(s)?.groupValues?.get(1)?.uppercase(Locale.US)?: "SQL"
    private fun splitSql(s:String):List<String>{val out=mutableListOf<String>();var start=0;var q:Char?=null;for(i in s.indices){val c=s[i];if((c=='\''||c=='\"')&&(i==0||s[i-1]!='\\'))q=if(q==c)null else if(q==null)c else q;if(c==';'&&q==null){if(s.substring(start,i).trim().isNotEmpty())out.add(s.substring(start,i).trim());start=i+1}};if(s.substring(start).trim().isNotEmpty())out.add(s.substring(start).trim());return out}
    private fun stripLineComments(s:String):String{val sb=StringBuilder();var q:Char?=null;var i=0;while(i<s.length){val c=s[i];if((c=='\''||c=='\"')&&(i==0||s[i-1]!='\\'))q=if(q==c)null else if(q==null)c else q;if(q==null&&c=='-'&&i+1<s.length&&s[i+1]=='-'){while(i<s.length&&s[i]!='\n')i++;continue};sb.append(c);i++};return sb.toString()}

    private fun runSelectedOrAll(){val a=editor.selectionStart;val z=editor.selectionEnd;val selected=if(a!=z)editor.text.substring(minOf(a,z),maxOf(a,z)).trim() else "";val source=if(selected.isNotEmpty())selected else editor.text.toString();val statements=splitSql(source).filter{stripLineComments(it).isNotBlank()};if(statements.isEmpty()){showError("Nothing to run");return};clearResults();var ok=0;var err=0;var schemaChanged=false
        for((idx,s) in statements.withIndex()){val label=leadingKeyword(s)+" "+(idx+1);val started=System.nanoTime();try{if(isQueryStatement(s)){if(s.trimStart().startsWith("EXPLAIN QUERY PLAN",true)){val rows=planRows(s);addResultTab("PLAN ${idx+1} · ${elapsed(started)}ms",buildPlanView(rows),false,rows.map{listOf(it.first.toString(),it.second.toString(),it.third)} ,"PLAN")}else{db.rawQuery(s,null).use{c->val built=buildTableView(c);addResultTab("$label · ${built.second}r · ${elapsed(started)}ms",built.first,false,built.third,"RESULT")}}}else{db.execSQL(s);if(label.startsWith("CREATE",true)||label.startsWith("DROP",true)||label.startsWith("ALTER",true))schemaChanged=true;val changed=db.rawQuery("SELECT changes()",null).use{c->c.moveToFirst();c.getInt(0)};addResultTab("$label · OK · ${elapsed(started)}ms",buildMessageView("✓ OK — $changed row(s) affected"),false,null,"MESSAGE")};ok++;history.add(0,s.trim());trimHistory()}catch(e:Exception){addResultTab("$label · error",buildMessageView("✕ ${e.message?:"SQL error"}\n\nTap Explain Error for a hint."),true,null,"ERROR");err++}}
        savePrefs();if(tabs.isNotEmpty())selectTab(0) else showPlaceholder();status.text=if(err==0)"✓ Ran $ok statement(s)"+if(selected.isNotEmpty())" • selected only" else "" else "✕ $err of ${statements.size} statement(s) failed";status.setTextColor(if(err==0)green else red);if(schemaChanged)refreshSchemaPanel() }
    private fun elapsed(s:Long)=((System.nanoTime()-s)/1_000_000L).toString(); private fun trimHistory(){while(history.size>30)history.removeAt(history.lastIndex)}

    private fun buildTableView(c:Cursor):Triple<View,Int,List<List<String>>>{
        val data=mutableListOf<List<String>>()
        val headers=(0 until c.columnCount).map{c.getColumnName(it)}; data.add(headers)
        while(c.moveToNext()) data.add((0 until c.columnCount).map{if(c.isNull(it) ) "NULL" else c.getString(it)})
        return Triple(buildGrid(data), data.size-1, data)
    }
    private fun buildGrid(data:List<List<String>>):View{
        val table=TableLayout(this); if(data.isEmpty()) return table
        val header=TableRow(this)
        for(i in data[0].indices){val h=cell(data[0][i],true){sortActiveResult(i)};header.addView(h)};table.addView(header)
        for(rowIndex in 1 until min(data.size,1001)){val r=TableRow(this);for(v in data[rowIndex])r.addView(cell(v,false){copyText(v)});table.addView(r)}
        if(data.size==1){val t=TextView(this);t.text="(0 rows)";t.setPadding(16,16,16,16);table.addView(t)} else if(data.size>1001){val t=TextView(this);t.text="… showing first 1000 of ${data.size-1} rows";t.setPadding(16,10,16,10);table.addView(t)}
        val hs=HorizontalScrollView(this);hs.addView(table);val vs=ScrollView(this);vs.isFillViewport=true;vs.addView(hs);return vs
    }
    private fun cell(v:String,head:Boolean,onClick:()->Unit):TextView{val t=TextView(this);t.text=v;t.textSize=12f;t.setTextColor(if(head)Color.rgb(122,107,96)else white);t.setPadding(16,12,16,12);t.setBackgroundColor(if(head) Color.rgb(246,240,235) else Color.WHITE);if(head)t.setOnClickListener{onClick()} else t.setOnLongClickListener{onClick();true};return t}
    private fun sortActiveResult(column:Int){if(activeTab<0||tabs[activeTab].csv==null)return;val old=tabs[activeTab].csv!!;if(old.size<2)return;val ascending=!(tabs[activeTab].button.tag as? Boolean ?: false);val sorted=old.drop(1).sortedWith(Comparator<List<String>>{a,b->compareCells(a.getOrElse(column){""},b.getOrElse(column){""})}).let{if(ascending)it else it.reversed()};val data=listOf(old[0])+sorted;tabs[activeTab].button.tag=ascending;tabs[activeTab].button.text=tabs[activeTab].title+" · sort ${if(ascending)"↑" else "↓"}";tabs[activeTab]=tabs[activeTab].copy(view=buildGrid(data),csv=data);selectTab(activeTab)}
    private fun compareCells(a:String,b:String):Int{val da=a.toDoubleOrNull();val db=b.toDoubleOrNull();return if(da!=null&&db!=null)da.compareTo(db) else a.compareTo(b,true)}
    private fun copyText(v:String){(getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("SQL cell",v));Toast.makeText(this,"Cell copied",Toast.LENGTH_SHORT).show()}

    private fun addResultTab(label:String,content:View,isError:Boolean,csv:List<List<String>>?,title:String){val idx=tabs.size;val btn=Button(ContextThemeWrapper(this,R.style.FlatButton));btn.text=label;btn.isAllCaps=false;val lp=LinearLayout.LayoutParams(-2,-2);lp.marginEnd=8;btn.layoutParams=lp;btn.setOnClickListener{selectTab(idx)};tabStrip.addView(btn);tabs.add(ResultTab(btn,content,isError,csv,title))}
    private fun selectTab(i:Int){if(i<0||i>=tabs.size)return;activeTab=i;resultContainer.removeAllViews();resultContainer.addView(tabs[i].view);for((j,t) in tabs.withIndex()){t.button.setBackgroundResource(if(j==i)R.drawable.button_accent else R.drawable.button_flat);t.button.setTextColor(if(j==i)Color.WHITE else if(t.isError)red else Color.rgb(122,107,96))}}
    private fun clearResults(){tabStrip.removeAllViews();resultContainer.removeAllViews();tabs.clear();activeTab=-1}
    private fun showPlaceholder(){val t=TextView(this);t.text="Run a query to see results here";t.setTextColor(Color.rgb(196,188,178));t.textSize=13f;t.gravity=Gravity.CENTER;resultContainer.removeAllViews();resultContainer.addView(t)}
    private fun buildMessageView(msg:String):View{val t=TextView(this);t.text=msg;t.textSize=13f;t.setTextColor(Color.rgb(122,107,96));t.setPadding(20,20,20,20);val s=ScrollView(this);s.addView(t);return s}

    private fun schemaText():String{val b=StringBuilder();db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->if(!c.moveToFirst())b.append("No tables yet.\nImport a .db or .sql file,\nor run a CREATE TABLE.")else{do{val n=c.getString(0);b.append(n).append("  ");try{db.rawQuery("SELECT COUNT(*) FROM \""+n.replace("\"","\"\"")+"\"",null).use{r->if(r.moveToFirst())b.append("(").append(r.getLong(0)).append(" rows)")}}catch(_:Exception){};b.append("\n");db.rawQuery("PRAGMA table_info('"+n.replace("'","''")+"')",null).use{p->while(p.moveToNext())b.append("   ").append(p.getString(1)).append("  ").append(p.getString(2).ifBlank{"ANY"}).append("\n")};b.append("\n")}while(c.moveToNext())}};return b.toString().trimEnd()}

    private fun interactiveSchema():SpannableStringBuilder{
        val out=SpannableStringBuilder()
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->
            if(!c.moveToFirst()){out.append("No tables yet.\nImport a .db/.sql file or create a table.");return out}
            do{
                val table=c.getString(0); val start=out.length; out.append("▾ ").append(table)
                try{db.rawQuery("SELECT COUNT(*) FROM \""+table.replace("\"","\"\"")+"\"",null).use{r->if(r.moveToFirst())out.append("  ·  ").append(r.getLong(0)).append(" rows")}}catch(_:Exception){}
                out.append("\n")
                out.setSpan(object:ClickableSpan(){override fun onClick(w:View){showTableExplorer(table)};override fun updateDrawState(ds:android.text.TextPaint){ds.color=blue;ds.isUnderlineText=false;ds.isFakeBoldText=true}},start,out.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                db.rawQuery("PRAGMA table_info('"+table.replace("'","''")+"')",null).use{p->while(p.moveToNext()){val col=p.getString(1);val typ=p.getString(2).ifBlank{"ANY"};val cs=out.length;out.append("   ↳ ").append(col).append("  :  ").append(typ).append("\n");out.setSpan(object:ClickableSpan(){override fun onClick(w:View){insertSql(col)};override fun updateDrawState(ds:android.text.TextPaint){ds.color=white;ds.isUnderlineText=false}},cs,out.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}}
                out.append("\n")
            }while(c.moveToNext())
        }
        return out
    }

    private fun showTableExplorer(table:String){
        val safe=table.replace("\"","\"\"")
        val pragmaSafe=table.replace("'","''")
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(20,4,20,8)
        val meta=TextView(this);meta.setTextColor(Color.rgb(122,107,96));meta.textSize=12f;meta.setPadding(0,0,0,10)
        val columns=mutableListOf<Triple<String,String,Boolean>>()
        db.rawQuery("PRAGMA table_info('$pragmaSafe')",null).use{c->while(c.moveToNext()) columns.add(Triple(c.getString(1),c.getString(2).ifBlank{"ANY"},c.getInt(5)>0))}
        val count=db.rawQuery("SELECT COUNT(*) FROM \"$safe\"",null).use{c->c.moveToFirst();c.getLong(0)}
        meta.text="${columns.size} columns  ·  $count rows  ·  previewing first 50"
        box.addView(meta)
        val actions=LinearLayout(this);actions.orientation=LinearLayout.HORIZONTAL
        val select=Button(ContextThemeWrapper(this,R.style.FlatButton));select.text="Insert SELECT *";select.isAllCaps=false;select.setOnClickListener{insertSql("SELECT * FROM \"$table\";");statusOk("Inserted SELECT from explorer")};actions.addView(select)
        box.addView(actions)
        val colLabel=TextView(this);colLabel.text="Columns — tap a column to insert it";colLabel.setTextColor(blue);colLabel.textSize=12f;colLabel.setPadding(0,12,0,6);box.addView(colLabel)
        val colScroll=HorizontalScrollView(this);val colRow=LinearLayout(this);colRow.orientation=LinearLayout.HORIZONTAL
        for((name,type,pk) in columns){val b=Button(ContextThemeWrapper(this,R.style.FlatButton));b.text=name+" : "+type+(if(pk)"  PK" else "");b.isAllCaps=false;b.setOnClickListener{insertSql("\"${name.replace("\"","\"\"")}\"")};colRow.addView(b)}
        colScroll.addView(colRow);box.addView(colScroll)
        val previewLabel=TextView(this);previewLabel.text="Data preview";previewLabel.setTextColor(blue);previewLabel.textSize=12f;previewLabel.setPadding(0,12,0,6);box.addView(previewLabel)
        val previewData=mutableListOf<List<String>>()
        db.rawQuery("SELECT * FROM \"$safe\" LIMIT 50",null).use{c->previewData.add((0 until c.columnCount).map{c.getColumnName(it)});while(c.moveToNext())previewData.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)})}
        val preview=buildPreviewGrid(previewData)
        box.addView(preview,LinearLayout.LayoutParams(-1,0,1f))
        AlertDialog.Builder(this).setTitle(table).setView(box).setPositiveButton("Close",null).show()
    }

    private fun buildPreviewGrid(data:List<List<String>>):View{
        val table=TableLayout(this);table.isStretchAllColumns=false
        if(data.isEmpty()) return TextView(this).apply{text="No columns";setPadding(12,12,12,12)}
        val header=TableRow(this)
        for(v in data[0]) header.addView(cell(v,true){})
        table.addView(header)
        for(i in 1 until data.size){val row=TableRow(this);for(v in data[i]) row.addView(cell(v,false){copyText(v)});table.addView(row)}
        if(data.size==1){table.addView(TextView(this).apply{text="(0 rows)";setPadding(16,16,16,16)})}
        val hs=HorizontalScrollView(this);hs.addView(table);val vs=ScrollView(this);vs.addView(hs);return vs
    }

    private fun insertSql(text:String){val a=editor.selectionStart.coerceAtLeast(0);val z=editor.selectionEnd.coerceAtLeast(0);val s=minOf(a,z);val e=maxOf(a,z);editor.text.replace(s,e,text);editor.setSelection((s+text.length).coerceAtMost(editor.length()));editor.requestFocus();statusOk("Inserted from database explorer")}

    private fun showSchema(){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(24,8,24,0)
        val hint=TextView(this);hint.text="Tap a table to inspect it · preview rows · insert SQL · tap a column to insert it";hint.setTextColor(Color.rgb(180,169,157));hint.textSize=12f;hint.setPadding(0,0,0,12);box.addView(hint)
        val scroll=ScrollView(this);val view=TextView(this);view.text=interactiveSchema();view.setTextSize(12f);view.setTextColor(white);view.setMovementMethod(LinkMovementMethod.getInstance());view.setHighlightColor(Color.TRANSPARENT);scroll.addView(view);box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        AlertDialog.Builder(this).setTitle("Database Explorer").setView(box).setPositiveButton("Close",null).show()
    }
    private fun refreshSchemaPanel(){schemaPanel?.apply{text=interactiveSchema();movementMethod=LinkMovementMethod.getInstance();highlightColor=Color.TRANSPARENT}}
    private fun firstTable():String{db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 1",null).use{c->if(c.moveToFirst())return c.getString(0)};return "employee_demographics"}
    private fun chooseDatabase(){val names=arrayOf("Parks & Recreation","Northwind-style");AlertDialog.Builder(this).setTitle("Sample database").setItems(names){_,which->val asset=if(which==0)"Parks_and_Recreation.db" else "Northwind.db";db.close();dbFile=File(filesDir,asset);if(!dbFile.exists())assets.open(asset).use{i->dbFile.outputStream().use{i.copyTo(it)}};db=SQLiteDatabase.openOrCreateDatabase(dbFile,null);clearResults();showPlaceholder();editor.setText("SELECT * FROM ${firstTable()};");statusOk("Using $asset");refreshSchemaPanel()}.setNegativeButton("Cancel",null).show()}

    private fun resetDatabase(){db.close();dbFile.delete();copyBundledDatabase(if(dbFile.name.contains("Northwind",true))"Northwind.db" else "Parks_and_Recreation.db");clearResults();showPlaceholder();editor.setText("SELECT * FROM ${firstTable()};");statusOk("Database reset");refreshSchemaPanel()}
    private fun statusOk(s:String){status.text="✓ $s";status.setTextColor(green)};private fun showError(s:String){status.text="✕ $s";status.setTextColor(red)}

    private fun highlight(){if(highlighting)return;highlighting=true;val e=editor.text;val pos=editor.selectionStart;e.getSpans(0,e.length,ForegroundColorSpan::class.java).forEach{e.removeSpan(it)};val text=e.toString();val patterns=listOf(Pattern.compile("(?i)\\b("+keywords.joinToString("|")+")\\b") to blue,Pattern.compile("'(?:''|[^'])*'") to orange,Pattern.compile("--[^\\n]*") to Color.rgb(180,172,160),Pattern.compile("\\b\\d+(?:\\.\\d+)?\\b") to green);for((p,col) in patterns)p.matcher(text).run{while(find())e.setSpan(ForegroundColorSpan(col),start(),end(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)};editor.setSelection(pos.coerceIn(0,e.length));highlighting=false}

    private fun formatSql(s:String):String{var x=s.replace(Regex("\\s+")," ").replace(Regex("\\s*;\\s*"),";\n");val kws=listOf("SELECT","FROM","WHERE","JOIN","LEFT JOIN","RIGHT JOIN","INNER JOIN","ORDER BY","GROUP BY","HAVING","LIMIT","UNION","VALUES","SET");for(k in kws)x=x.replace(Regex("\\s*${k.replace(" ","\\s+")}\\s*",RegexOption.IGNORE_CASE),"\n${k} ");return x.trim().replace(Regex("\\n+"),"\n")}
    private fun toggleComment(){val a=editor.selectionStart;val z=editor.selectionEnd;val s=minOf(a,z);val e=maxOf(a,z);val start=editor.text.lastIndexOf('\n',s-1).let{if(it<0)0 else it+1};val end=editor.text.indexOf('\n',e).let{if(it<0)editor.length() else it};val block=editor.text.substring(start,end);val lines=block.split('\n');val uncomment=lines.filter{it.trimStart().startsWith("--")}.size>lines.size/2;val repl=lines.joinToString("\n"){if(uncomment)it.replaceFirst(Regex("^\\s*--\\s?"),"") else if(it.isBlank())it else "-- $it"};editor.text.replace(start,end,repl);editor.setSelection(start,start+repl.length)}

    private fun showHistory(){if(history.isEmpty()){AlertDialog.Builder(this).setTitle("Query history").setMessage("No runs yet.").setPositiveButton("Close",null).show();return};AlertDialog.Builder(this).setTitle("Query history").setItems(history.toTypedArray()){_,which->editor.setText(history[which]);editor.setSelection(editor.length())}.setNegativeButton("Close",null).show()}
    private fun saveSnippetDialog(){val input=EditText(this);input.hint="My JOIN practice";AlertDialog.Builder(this).setTitle("Save snippet").setView(input).setPositiveButton("Save"){_,_->val name=input.text.toString().trim();if(name.isNotEmpty()){snippets[name]=editor.text.toString();prefs.edit().putString("snippet:$name",editor.text.toString()).apply();statusOk("Snippet saved: $name")}}.setNegativeButton("Cancel",null).show()}
    private fun showSnippetMenu(){val names=snippets.keys.toTypedArray();val items=(if(names.isEmpty())listOf("Save current snippet")else listOf("Save current snippet")+names.toList()).toTypedArray();AlertDialog.Builder(this).setTitle("Snippets").setItems(items){_,i->if(i==0)saveSnippetDialog()else{editor.setText(snippets[names[i-1]]);editor.setSelection(editor.length())}}.setNegativeButton("Close",null).show()}

    private fun showExplain(msg:String){val lower=msg.lowercase();val hint=when{lower.contains("no such column")->"SQLite cannot find that column. Check spelling, table aliases, and whether the column belongs to the table you are querying.";lower.contains("no such table")->"SQLite cannot find that table. Check the table name and make sure you imported/created the right database.";lower.contains("syntax error")->"SQLite could not parse the SQL. Check commas, parentheses, quotes, keywords, and the statement order.";lower.contains("constraint failed")->"A table constraint was violated. Check PRIMARY KEY, UNIQUE, NOT NULL, FOREIGN KEY, or CHECK rules.";lower.contains("datatype mismatch")->"A value does not fit the operation or column type. Check casts and the values being inserted/compared.";lower.contains("ambiguous column")->"More than one table has that column name. Qualify it with a table name or alias, e.g. e.salary.";else->"Run the statement again and inspect the SQLite message above. The most useful first checks are table/column names, aliases, commas, quotes, and parentheses."};AlertDialog.Builder(this).setTitle("Explain this error").setMessage(hint).setPositiveButton("OK",null).show()}

    private fun showPractice(){val challenges=listOf("1. Find employees older than 40","2. Join employee salary with demographics","3. Find the highest 3 salaries","4. Count employees by gender","5. Show departments with their names");AlertDialog.Builder(this).setTitle("Practice mode").setItems(challenges.toTypedArray()){_,which->currentChallenge=which;editor.setText(challengeSql[which]);editor.setSelection(editor.length());statusOk("Challenge loaded — run it, then tap Check")}.setNegativeButton("Close",null).show()}
    private fun checkPractice(){if(currentChallenge<0){showError("Load a practice challenge first");return};try{val user=editor.text.toString();val expected=challengeSql[currentChallenge];val ur=collectResult(user);val er=collectResult(expected);if(ur==er)statusOk("Practice check passed ✓ — result matches the expected output")else showError("Practice check did not match the expected output. Compare columns, rows, ordering, and filters.")}catch(e:Exception){showError("Practice check error: ${e.message?:"SQL error"}")}}
    private fun collectResult(sql:String):List<List<String>>{val q=splitSql(sql).lastOrNull{isQueryStatement(it)}?:throw Exception("No query found");db.rawQuery(q,null).use{c->val out=mutableListOf<List<String>>();out.add((0 until c.columnCount).map{c.getColumnName(it)});while(c.moveToNext())out.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)});return out}}

    private fun planRows(sql:String):List<Triple<Int,Int,String>>{val out=mutableListOf<Triple<Int,Int,String>>();db.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(Triple(c.getInt(0),c.getInt(1),c.getString(3))) };return out}
    private fun buildPlanView(rows:List<Triple<Int,Int,String>>):View{val t=LinearLayout(this);t.orientation=LinearLayout.VERTICAL;t.setPadding(18,16,18,16);for((id,parent,detail) in rows){val v=TextView(this);v.text=(if(parent==0)"▸ " else "  └─ ")+detail+"  [id=$id parent=$parent]";v.textSize=13f;v.setTextColor(white);v.setPadding(8,8,8,8);t.addView(v)};val s=ScrollView(this);s.addView(t);return s}

    private fun exportDatabase(){val i=Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.type="application/octet-stream";i.putExtra(Intent.EXTRA_TITLE,"ProjectLily-${dbFile.name}");startActivityForResult(i,88)}
    private fun exportCsv(){if(activeTab<0||tabs[activeTab].csv==null){showError("Run a result query first");return};val csv=tabs[activeTab].csv!!.joinToString("\n"){row->row.joinToString(","){csvEscape(it)}};val i=Intent(Intent.ACTION_SEND);i.type="text/csv";i.putExtra(Intent.EXTRA_TEXT,csv);i.putExtra(Intent.EXTRA_TITLE,"query-result.csv");startActivity(Intent.createChooser(i,"Share CSV"))}
    private fun csvEscape(s:String)=if(s.contains(',')||s.contains('"')||s.contains('\n'))"\"${s.replace("\"","\"\"")}\"" else s

    private fun updateAutocomplete(){if(!editor.hasFocus())return;val before=editor.text.substring(0,editor.selectionStart.coerceAtLeast(0));val token=Regex("[A-Za-z_][A-Za-z0-9_]*$").find(before)?.value?:return;if(token.length<2)return;val lower=before.lowercase();val names=mutableListOf<String>();val mode=when{Regex("\\b(from|join|update|into|table)\\s+\\w*$",RegexOption.IGNORE_CASE).containsMatchIn(before)->"table";Regex("\\b(select|where|on|order by|group by|having|set)\\s+\\w*$",RegexOption.IGNORE_CASE).containsMatchIn(before)->"column";else->"keyword"};if(mode=="table"){db.rawQuery("SELECT name FROM sqlite_master WHERE (type='table' OR type='view') AND name NOT LIKE 'sqlite_%'",null).use{c->while(c.moveToNext())if(c.getString(0).lowercase().startsWith(token.lowercase()))names.add(c.getString(0))}}else if(mode=="column"){db.rawQuery("SELECT name FROM pragma_table_info(?)",arrayOf(firstTable())).use{c->while(c.moveToNext())if(c.getString(0).lowercase().startsWith(token.lowercase()))names.add(c.getString(0))}}else keywords.filter{it.lowercase().startsWith(token.lowercase())}.take(8).forEach{names.add(it)};if(names.isEmpty())return;val popup=PopupWindow(this);val list=ListView(this);list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,names.distinct());list.setOnItemClickListener{_,_,p,_->val end=editor.selectionStart;editor.text.replace(end-token.length,end,names[p]);popup.dismiss()};popup.contentView=list;popup.width=220;popup.height=ListView.LayoutParams.WRAP_CONTENT;popup.isFocusable=false;popup.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.WHITE));popup.showAsDropDown(editor)}

    override fun onKeyDown(keyCode:Int,event:KeyEvent):Boolean{if((event.isCtrlPressed||event.isMetaPressed)&&keyCode==KeyEvent.KEYCODE_ENTER){runSelectedOrAll();return true};if((event.isCtrlPressed||event.isMetaPressed)&&keyCode==KeyEvent.KEYCODE_SLASH){toggleComment();return true};return super.onKeyDown(keyCode,event)}
    override fun onDestroy(){if(::db.isInitialized&&db.isOpen)db.close();super.onDestroy()}
}

class LineNumberEditText(context:Context, attrs:android.util.AttributeSet?=null):android.widget.EditText(context,attrs){
    private val paint=android.graphics.Paint().apply{color=Color.rgb(180,172,160);textSize=36f;typeface=android.graphics.Typeface.MONOSPACE}
    init{setPadding(58,paddingTop,paddingRight,paddingBottom);setBackgroundColor(Color.TRANSPARENT);setTextColor(Color.rgb(58,52,47));setOnFocusChangeListener{_,_->invalidate()}}
    override fun onDraw(canvas:android.graphics.Canvas){val lineH=lineHeight.toFloat();val current=layout?.getLineForOffset(selectionStart)?:0;val top=current*lineH-scrollY;val hi=android.graphics.Paint().apply{color=Color.rgb(250,244,247)};canvas.drawRect(0f,top,width.toFloat(),top+lineH,hi);val first=(scrollY/lineH).toInt();val last=((scrollY+height)/lineH).toInt()+1;paint.textSize=textSize*0.78f;for(line in first..last){val y=(line+1)*lineH - scrollY;canvas.drawText((line+1).toString(),8f,y,paint)};super.onDraw(canvas)}
}
