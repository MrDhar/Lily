## v17 — Lily Dark macOS-inspired workspace

- App-wide dark theme built around Lily pink, graphite, and soft neutral tones.
- macOS-inspired main dashboard chrome with red/yellow/green traffic-light dots.
- Reorganized workspace into clear Workspace, Editor, and Tools areas.
- Dark result grid, buttons, tabs, editor line numbers, and status surfaces.
- Popup cards use the same dark visual language so the app feels like one system.
- Existing interactive database explorer, local database import, contextual autocomplete, history, snippets, practice mode, CSV export, and DB export are retained.

# Project Lily — SQL Learning Lab

Project Lily is an offline Android SQL learning/editor app built around a real SQLite engine. It keeps the lightweight Lily UI while adding a practical learning workflow.

## Current features

- Real Android SQLite execution — not a fake interpreter
- Run the selected SQL only; with no selection, run all statements
- Multiple result tabs with row count and execution time
- Tap result headers to sort client-side; long-press cells to copy
- Share the active result as CSV from the Android share sheet
- Query history (last 30 runs) with tap-to-reload
- Named snippets stored locally
- Line numbers and current-line highlight
- Comment/uncomment selected lines with `-- Line` or Ctrl/Cmd + `/`
- SQL formatting helper
- Context-aware autocomplete for tables, columns, keywords and aggregate functions
- Plain-English common SQLite error explanations
- Practice mode with expected-result checking
- Readable `EXPLAIN QUERY PLAN` tree rendering
- Parks & Recreation and a bundled Northwind-style sample database
- Import `.sql`, `.db`, `.sqlite`, and `.sqlite3`
- Export the current working database as a `.db` backup
- Interactive database explorer: tap tables to inspect columns and preview up to 50 rows; tap columns to insert SQL into the editor
- Tablet layout with a live schema rail
- Result tabs have individual × close controls and can be removed without clearing the other results
- SQL imports identify the real selected filename and skip common MySQL-only `DROP DATABASE`, `CREATE DATABASE`, and `USE` control statements so compatible table/data definitions can populate the SQLite schema
- Project Lily pixel-lily branding

## Offline behavior

The app does not need a web connection or Python server to execute SQL. SQLite runs locally on the Android device and the sample databases are bundled in `app/src/main/assets/`.

## Open/build

Open the project root in Android Studio and build the `app` module. Minimum Android version is API 23; target/compile SDK is 35.


## v16 interaction and import refinement
- Contextual autocomplete only: table/column suggestions appear when the SQL context calls for them.
- Popup is anchored beside the current editor line instead of below the whole editor.
- Popup is dismissed on cursor/selection changes, focus loss, Escape, and selection.
- No generic keyword popup while simply typing.
- Qualified names such as `e.` can trigger column completion.


### v16 fixes
- Autocomplete is now strictly contextual: it appears only after a table/column trigger with a typed prefix, never as a permanent generic list.
- Autocomplete is a compact cursor-positioned popup (max 6 items) with custom rounded rows and guarded insertion to avoid crashes.
- Imported SQLite databases are validated, opened as the active working database, and immediately reflected in the schema explorer.
- SQL imports build a fresh local SQLite database instead of merging into the bundled sample database.
- File picker accepts all document providers and validates SQLite files by their SQLite header.
- Database Explorer includes a direct Import .db / .sql action and shows the current database filename.
- macOS-inspired dialogs use one clean rounded shell with a subtle border and traffic-light dots, avoiding nested rounded backgrounds that produced corner artifacts.
- Reset returns to the currently selected bundled sample database after an import.
