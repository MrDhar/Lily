package com.maalik.projectlily

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.text.*
import android.text.style.ForegroundColorSpan
import android.text.style.ClickableSpan
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.method.LinkMovementMethod
import android.view.*
import android.widget.*
import java.io.*
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var editor: LineNumberEditText
    private lateinit var status: TextView
    private lateinit var tabStrip: LinearLayout
    private lateinit var resultContainer: FrameLayout
    private lateinit var db: SQLiteDatabase
    private lateinit var dbFile: File
    private var schemaPanel: TextView? = null
    private var highlighting = false
    private var autocompletePopup: PopupWindow? = null
    private var autocompleteTokenStart = -1
    private var suppressAutocompleteDismiss = false
    private var currentChallenge = -1
    private var bundledAsset = "Parks_and_Recreation.db"
    private val challengeSql = listOf(
        "SELECT * FROM employee_demographics WHERE age > 40;",
        "SELECT d.first_name, d.last_name, s.salary FROM employee_demographics d JOIN employee_salary s ON d.employee_id=s.employee_id;",
        "SELECT first_name, salary FROM employee_salary ORDER BY salary DESC LIMIT 3;",
        "SELECT gender, COUNT(*) AS total FROM employee_demographics GROUP BY gender;",
        "SELECT * FROM parks_departments ORDER BY department_id;"
    )
    private val prefs by lazy { getSharedPreferences("lily", MODE_PRIVATE) }
    private val history = mutableListOf<String>()
    private val snippets = linkedMapOf<String, String>()

    private val blue=Color.rgb(213,138,175); private val purple=Color.rgb(154,141,184)
    private val green=Color.rgb(143,175,146); private val orange=Color.rgb(208,163,111)
    private val red=Color.rgb(255,107,100); private val white=Color.rgb(231,227,233)
    private val keywords = listOf("SELECT","FROM","WHERE","INSERT","INTO","VALUES","UPDATE","SET","DELETE","CREATE","TABLE","DROP","ALTER","JOIN","INNER","LEFT","RIGHT","FULL","OUTER","CROSS","NATURAL","ON","USING","GROUP","BY","ORDER","ASC","DESC","HAVING","LIMIT","OFFSET","AS","DISTINCT","AND","OR","NOT","NULL","IS","LIKE","GLOB","REGEXP","IN","BETWEEN","ESCAPE","UNION","INTERSECT","EXCEPT","ALL","CASE","WHEN","THEN","ELSE","END","COUNT","SUM","AVG","MIN","MAX","TOTAL","GROUP_CONCAT","OVER","PARTITION","ROWS","RANGE","GROUPS","UNBOUNDED","PRECEDING","FOLLOWING","CURRENT","ROW","ROW_NUMBER","RANK","DENSE_RANK","NTILE","LAG","LEAD","FIRST_VALUE","LAST_VALUE","NTH_VALUE","FILTER","WITH","RECURSIVE","EXISTS","RETURNING","PRIMARY","KEY","FOREIGN","REFERENCES","DEFAULT","UNIQUE","CHECK","CONSTRAINT","AUTOINCREMENT","GENERATED","ALWAYS","STORED","VIRTUAL","WITHOUT","ROWID","STRICT","COLLATE","INDEX","VIEW","TRIGGER","BEFORE","AFTER","INSTEAD","OF","FOR","EACH","BEGIN","CASCADE","RESTRICT","IF","RENAME","COLUMN","TO","ADD","TEMP","TEMPORARY","TRANSACTION","COMMIT","ROLLBACK","SAVEPOINT","RELEASE","ATTACH","DETACH","EXPLAIN","QUERY","PLAN","ANALYZE","VACUUM","PRAGMA","CAST","COALESCE","IFNULL","NULLIF","TRUE","FALSE","CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP")

    data class ResultTab(val button: Button, val closeButton: Button, val container: LinearLayout, val view: View, val isError: Boolean, val csv: List<List<String>>?, val title: String)
    private val tabs=mutableListOf<ResultTab>(); private var activeTab=-1

    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        editor=findViewById(R.id.editor); status=findViewById(R.id.status); tabStrip=findViewById(R.id.tabStrip); resultContainer=findViewById(R.id.resultContainer); schemaPanel=findViewById(R.id.schemaPanel)
        loadPrefs(); bundledAsset="Parks_and_Recreation.db"; copyBundledDatabase(bundledAsset)
        editor.setText("""-- Select a query and tap Run.\n-- Select multiple statements to run only that selection.\nSELECT * FROM employee_demographics;\n\nSELECT first_name, salary\nFROM employee_salary\nORDER BY salary DESC;""")
        editor.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){updateAutocomplete()};override fun afterTextChanged(e:Editable?){highlight(); editor.invalidate()}})
        editor.setOnFocusChangeListener{_,hasFocus->if(!hasFocus)dismissAutocomplete()}
        editor.setSelection(editor.length())
        findViewById<Button>(R.id.runButton).setOnClickListener{runSelectedOrAll()}; findViewById<Button>(R.id.importButton).setOnClickListener{pickFile()}
        findViewById<Button>(R.id.schemaButton).setOnClickListener{showSchema()}; findViewById<Button>(R.id.dbButton).setOnClickListener{chooseDatabase()}; findViewById<Button>(R.id.resetButton).setOnClickListener{resetDatabase()}; findViewById<Button>(R.id.clearButton).setOnClickListener{editor.setText("")}
        findViewById<Button>(R.id.historyButton).setOnClickListener{showHistory()}; findViewById<Button>(R.id.snippetButton).setOnClickListener{showSnippetMenu()}; findViewById<Button>(R.id.practiceButton).setOnClickListener{showPractice()}; findViewById<Button>(R.id.checkPracticeButton).setOnClickListener{checkPractice()}
        findViewById<Button>(R.id.formatButton).setOnClickListener{editor.setText(formatSql(editor.text.toString())); editor.setSelection(editor.length())}
        findViewById<Button>(R.id.commentButton).setOnClickListener{toggleComment()}; findViewById<Button>(R.id.exportDbButton).setOnClickListener{exportDatabase()}; findViewById<Button>(R.id.exportCsvButton).setOnClickListener{exportCsv()}; findViewById<Button>(R.id.explainButton).setOnClickListener{showExplain(status.text.toString())}
        refreshSchemaPanel(); showPlaceholder()
    }

    private fun loadPrefs(){ history.addAll(prefs.getStringSet("history", emptySet<String>())!!.toList()); prefs.all.filterKeys{it.startsWith("snippet:")}.forEach{snippets[it.key.removePrefix("snippet:")]=it.value as String} }
    private fun savePrefs(){prefs.edit().putStringSet("history",history.take(30).toSet()).apply()}

    private fun copyBundledDatabase(asset:String){ dbFile=File(filesDir,asset); if(!dbFile.exists()) assets.open(asset).use{i->dbFile.outputStream().use{i.copyTo(it)}}; db=SQLiteDatabase.openOrCreateDatabase(dbFile,null) }

    private fun pickFile(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE)
            type="*/*"
        }
        startActivityForResult(i,77)
    }

    private fun displayName(uri:Uri):String{
        var name:String?=null
        try{contentResolver.query(uri,arrayOf("_display_name"),null,null,null)?.use{c->if(c.moveToFirst())name=c.getString(0)}}catch(_:Exception){}
        return name ?: (uri.lastPathSegment ?: "import.sql").substringAfterLast('/').ifBlank{"import.sql"}
    }

    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data)
        if(req==88&&res==RESULT_OK&&data?.data!=null){
            try{contentResolver.openOutputStream(data.data!!).use{out->dbFile.inputStream().use{it.copyTo(out!!)}};statusOk("Database exported")}catch(e:Exception){showError(e.message?:"Export failed")}
            return
        }
        if(req!=77||res!=RESULT_OK||data?.data==null)return
        try{
            val uri=data.data!!
            try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
            val fileName=displayName(uri)
            val name=fileName.lowercase(Locale.US)
            val bytes=contentResolver.openInputStream(uri)?.use{it.readBytes()} ?: throw Exception("Could not read the selected file")
            when{
                name.endsWith(".db")||name.endsWith(".sqlite")||name.endsWith(".sqlite3")->{
                    importDatabaseBytes(bytes,fileName)
                }
                name.endsWith(".sql")||name.endsWith(".txt")-> {importSqlScript(bytes.toString(Charsets.UTF_8),fileName)}
                else->{
                    val text=bytes.toString(Charsets.UTF_8)
                    if(Regex("(?is)\\b(CREATE|INSERT|ALTER|DROP)\\s+").containsMatchIn(text)) importSqlScript(text,fileName)
                    else throw Exception("Unsupported file. Choose a .sql, .db, .sqlite, or .sqlite3 file.")
                }
            }

        }catch(e:Exception){showError(e.message?:"Could not open file")}
    }

    private fun importDatabaseBytes(bytes:ByteArray,fileName:String){
        if(bytes.size<16 || String(bytes,0,16,Charsets.US_ASCII)!="SQLite format 3\u0000"){
            throw Exception("The selected file is not a valid SQLite database")
        }
        val safe=fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")
        val target=File(filesDir,"Imported_${System.currentTimeMillis()}_$safe")
        target.writeBytes(bytes)
        val opened=try{SQLiteDatabase.openDatabase(target.path,null,SQLiteDatabase.OPEN_READWRITE)}catch(e:Exception){target.delete();throw Exception("Could not open SQLite database: ${e.message?:"invalid database"}")}
        if(!hasUserTables(opened)){
            opened.close();target.delete();throw Exception("The database opened successfully but contains no user tables")
        }
        if(::db.isInitialized && db.isOpen) db.close()
        db=opened
        dbFile=target
        clearResults();showPlaceholder();refreshSchemaPanel()
        val table=firstTable()
        editor.setText(if(table.isNotBlank())"SELECT * FROM \"${table.replace("\"","\"\"")}\";" else "")
        editor.setSelection(editor.length())
        statusOk("Imported database: $fileName")
    }

    private fun hasUserTables(database:SQLiteDatabase):Boolean{
        database.rawQuery("SELECT 1 FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' LIMIT 1",null).use{return it.moveToFirst()}
    }

    private fun prepareSqlForSQLite(sql:String):Pair<String,Int>{
        var x=sql.replace("\r\n","\n").replace("\r","\n")
        var skipped=0
        val controlPatterns=listOf(
            Regex("(?im)^\\s*(DROP\\s+DATABASE(?:\\s+IF\\s+EXISTS)?|CREATE\\s+DATABASE(?:\\s+IF\\s+NOT\\s+EXISTS)?|USE)\\s+[^;]+;?\\s*$"),
            Regex("(?im)^\\s*(SET\\s+(?:NAMES|CHARACTER\\s+SET|FOREIGN_KEY_CHECKS|SQL_MODE|TIME_ZONE|UNIQUE_CHECKS|SQL_NOTES|AUTOCOMMIT)\\b[^;]*;?\\s*$)"),
            Regex("(?im)^\\s*(LOCK\\s+TABLES|UNLOCK\\s+TABLES|DELIMITER)\\b[^;]*;?\\s*$")
        )
        controlPatterns.forEach{r->skipped+=r.findAll(x).count();x=r.replace(x,"")}
        x=x.replace("`","\"")
        // Common MySQL dump syntax -> SQLite-compatible declarations.
        x=x.replace(Regex("(?i)\\bINT(?:EGER)?\\s+AUTO_INCREMENT\\s+PRIMARY\\s+KEY"),"INTEGER PRIMARY KEY AUTOINCREMENT")
        x=x.replace(Regex("(?i)\\bBIGINT\\s+AUTO_INCREMENT\\s+PRIMARY\\s+KEY"),"INTEGER PRIMARY KEY AUTOINCREMENT")
        x=x.replace(Regex("(?i)\\bAUTO_INCREMENT\\b"),"")
        x=x.replace(Regex("(?i)\\s+ENGINE\\s*=\\s*\\w+"),"")
            .replace(Regex("(?i)\\s+DEFAULT\\s+CHARSET\\s*=\\s*\\w+"),"")
            .replace(Regex("(?i)\\s+CHARSET\\s*=\\s*\\w+"),"")
            .replace(Regex("(?i)\\s+COLLATE\\s*=\\s*[A-Za-z0-9_]+"),"")
            .replace(Regex("(?i)\\s+UNSIGNED\\b"),"")
            .replace(Regex("(?i)\\bTINYINT\\s*\\(\\s*1\\s*\\)"),"INTEGER")
            .replace(Regex("(?i)\\bMEDIUMINT\\b"),"INTEGER")
        return x to skipped
    }

    private fun importSqlScript(sql:String,fileName:String="SQL script"){
        if(sql.isBlank()){showError("$fileName is empty");return}
        val prepared=prepareSqlForSQLite(sql)
        val target=File(filesDir,"Imported_${System.currentTimeMillis()}_${fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")}.db")
        var fresh:SQLiteDatabase?=null
        var count=0
        var statementNumber=0
        try{
            fresh=SQLiteDatabase.openOrCreateDatabase(target,null)
            fresh.beginTransaction()
            for(raw in splitSql(prepared.first)){
                val statement=stripLineComments(raw).trim()
                if(statement.isBlank() || isQueryStatement(statement)) continue
                statementNumber++
                fresh.execSQL(statement)
                count++
            }
            fresh.setTransactionSuccessful()
            fresh.endTransaction()
            if(!hasUserTables(fresh)) throw Exception("No user tables were created")
            if(::db.isInitialized && db.isOpen) db.close()
            db=fresh
            dbFile=target
            fresh=null
            clearResults();showPlaceholder();refreshSchemaPanel()
            val table=firstTable()
        editor.setText(if(table.isNotBlank())"SELECT * FROM \"${table.replace("\"","\"\"")}\";" else "")
            editor.setSelection(editor.length())
            val suffix=if(prepared.second>0)" · skipped ${prepared.second} dump-control statement(s)" else ""
            statusOk("Imported $fileName: $count statement(s) applied$suffix")
        }catch(e:Exception){
            try{fresh?.endTransaction()}catch(_:Exception){}
            try{fresh?.close()}catch(_:Exception){}
            target.delete()
            val detail=e.message?:"SQL error"
            showError("Import failed at statement $statementNumber: $detail")
        }
    }

    private fun isQueryStatement(s:String)=s.trimStart().let{it.startsWith("SELECT",true)||it.startsWith("WITH",true)||it.startsWith("PRAGMA",true)||it.startsWith("EXPLAIN",true)}
    private fun leadingKeyword(s:String)=Regex("^\\s*([A-Za-z]+)").find(s)?.groupValues?.get(1)?.uppercase(Locale.US)?: "SQL"
    private fun splitSql(s:String):List<String>{val out=mutableListOf<String>();var start=0;var q:Char?=null;for(i in s.indices){val c=s[i];if((c=='\''||c=='\"')&&(i==0||s[i-1]!='\\'))q=if(q==c)null else if(q==null)c else q;if(c==';'&&q==null){if(s.substring(start,i).trim().isNotEmpty())out.add(s.substring(start,i).trim());start=i+1}};if(s.substring(start).trim().isNotEmpty())out.add(s.substring(start).trim());return out}
    private fun stripLineComments(s:String):String{val sb=StringBuilder();var q:Char?=null;var i=0;while(i<s.length){val c=s[i];if((c=='\''||c=='\"')&&(i==0||s[i-1]!='\\'))q=if(q==c)null else if(q==null)c else q;if(q==null&&c=='-'&&i+1<s.length&&s[i+1]=='-'){while(i<s.length&&s[i]!='\n')i++;continue};sb.append(c);i++};return sb.toString()}

    private fun runSelectedOrAll(){val a=editor.selectionStart;val z=editor.selectionEnd;val selected=if(a!=z)editor.text.substring(minOf(a,z),maxOf(a,z)).trim() else "";val source=if(selected.isNotEmpty())selected else editor.text.toString();val statements=splitSql(source).filter{stripLineComments(it).isNotBlank()};if(statements.isEmpty()){showError("Nothing to run");return};clearResults();var ok=0;var err=0;var schemaChanged=false
        for((idx,s) in statements.withIndex()){val label=leadingKeyword(s)+" "+(idx+1);val started=System.nanoTime();try{if(isQueryStatement(s)){if(s.trimStart().startsWith("EXPLAIN QUERY PLAN",true)){val rows=planRows(s);addResultTab("PLAN ${idx+1} · ${elapsed(started)}ms",buildPlanView(rows),false,rows.map{listOf(it.first.toString(),it.second.toString(),it.third)} ,"PLAN")}else{db.rawQuery(s,null).use{c->val built=buildTableView(c);addResultTab("$label · ${built.second}r · ${elapsed(started)}ms",built.first,false,built.third,"RESULT")}}}else{db.execSQL(s);if(label.startsWith("CREATE",true)||label.startsWith("DROP",true)||label.startsWith("ALTER",true))schemaChanged=true;val changed=db.rawQuery("SELECT changes()",null).use{c->c.moveToFirst();c.getInt(0)};addResultTab("$label · OK · ${elapsed(started)}ms",buildMessageView("✓ OK — $changed row(s) affected"),false,null,"MESSAGE")};ok++;history.add(0,s.trim());trimHistory()}catch(e:Exception){addResultTab("$label · error",buildMessageView("✕ ${e.message?:"SQL error"}\n\nTap Explain Error for a hint."),true,null,"ERROR");err++}}
        savePrefs();if(tabs.isNotEmpty())selectTab(0) else showPlaceholder();status.text=if(err==0)"✓ Ran $ok statement(s)"+if(selected.isNotEmpty())" • selected only" else "" else "✕ $err of ${statements.size} statement(s) failed";status.setTextColor(if(err==0)green else red);if(schemaChanged)refreshSchemaPanel() }
    private fun elapsed(s:Long)=((System.nanoTime()-s)/1_000_000L).toString(); private fun trimHistory(){while(history.size>30)history.removeAt(history.lastIndex)}

    private fun buildTableView(c:Cursor):Triple<View,Int,List<List<String>>>{
        val data=mutableListOf<List<String>>()
        val headers=(0 until c.columnCount).map{c.getColumnName(it)}; data.add(headers)
        while(c.moveToNext()) data.add((0 until c.columnCount).map{if(c.isNull(it) ) "NULL" else c.getString(it)})
        return Triple(buildGrid(data), data.size-1, data)
    }
    private fun buildGrid(data:List<List<String>>):View{
        val table=TableLayout(this); if(data.isEmpty()) return table
        val header=TableRow(this)
        for(i in data[0].indices){val h=cell(data[0][i],true){sortActiveResult(i)};header.addView(h)};table.addView(header)
        for(rowIndex in 1 until min(data.size,1001)){val r=TableRow(this);for(v in data[rowIndex])r.addView(cell(v,false){copyText(v)});table.addView(r)}
        if(data.size==1){val t=TextView(this);t.text="(0 rows)";t.setPadding(16,16,16,16);table.addView(t)} else if(data.size>1001){val t=TextView(this);t.text="… showing first 1000 of ${data.size-1} rows";t.setPadding(16,10,16,10);table.addView(t)}
        val hs=HorizontalScrollView(this);hs.addView(table);val vs=ScrollView(this);vs.isFillViewport=true;vs.addView(hs);return vs
    }
    private fun cell(v:String,head:Boolean,onClick:()->Unit):TextView{val t=TextView(this);t.text=v;t.textSize=12f;t.setTextColor(if(head)Color.rgb(185,181,191)else white);t.setPadding(16,12,16,12);t.setBackgroundColor(if(head) Color.rgb(28,31,39) else Color.rgb(24,26,33));if(head)t.setOnClickListener{onClick()} else t.setOnLongClickListener{onClick();true};return t}
    private fun sortActiveResult(column:Int){if(activeTab<0||tabs[activeTab].csv==null)return;val old=tabs[activeTab].csv!!;if(old.size<2)return;val ascending=!(tabs[activeTab].button.tag as? Boolean ?: false);val sorted=old.drop(1).sortedWith(Comparator<List<String>>{a,b->compareCells(a.getOrElse(column){""},b.getOrElse(column){""})}).let{if(ascending)it else it.reversed()};val data=listOf(old[0])+sorted;tabs[activeTab].button.tag=ascending;tabs[activeTab].button.text=tabs[activeTab].title+" · sort ${if(ascending)"↑" else "↓"}";tabs[activeTab]=tabs[activeTab].copy(view=buildGrid(data),csv=data);selectTab(activeTab)}
    private fun compareCells(a:String,b:String):Int{val da=a.toDoubleOrNull();val db=b.toDoubleOrNull();return if(da!=null&&db!=null)da.compareTo(db) else a.compareTo(b,true)}
    private fun copyText(v:String){(getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("SQL cell",v));Toast.makeText(this,"Cell copied",Toast.LENGTH_SHORT).show()}

    private fun addResultTab(label:String,content:View,isError:Boolean,csv:List<List<String>>?,title:String){
        val wrap=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val btn=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text=label;isAllCaps=false;minHeight=0;minWidth=0;setPadding(12,0,8,0)}
        val close=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="×";isAllCaps=false;minHeight=0;minWidth=0;setPadding(6,0,8,0);contentDescription="Close $label"}
        wrap.addView(btn,LinearLayout.LayoutParams(-2,42));wrap.addView(close,LinearLayout.LayoutParams(42,42))
        val lp=LinearLayout.LayoutParams(-2,-2);lp.marginEnd=8;wrap.layoutParams=lp;tabStrip.addView(wrap)
        val tab=ResultTab(btn,close,wrap,content,isError,csv,title);tabs.add(tab)
        btn.setOnClickListener{selectTab(tabs.indexOf(tab))};close.setOnClickListener{removeResultTab(tabs.indexOf(tab))}
    }

    private fun removeResultTab(index:Int){
        if(index<0||index>=tabs.size)return
        val wasActive=index==activeTab
        tabStrip.removeView(tabs[index].container);tabs.removeAt(index)
        activeTab=when{tabs.isEmpty()->-1;wasActive->minOf(index,tabs.lastIndex);index<activeTab->activeTab-1;else->activeTab}
        if(activeTab>=0)selectTab(activeTab) else showPlaceholder()
    }

    private fun selectTab(i:Int){
        if(i<0||i>=tabs.size)return
        activeTab=i;resultContainer.removeAllViews();resultContainer.addView(tabs[i].view)
        for((j,t) in tabs.withIndex()){
            val selected=j==i
            t.button.setBackgroundResource(if(selected)R.drawable.button_accent else R.drawable.button_flat)
            t.button.setTextColor(if(selected)Color.WHITE else if(t.isError)red else Color.rgb(185,181,191))
            t.closeButton.setBackgroundResource(if(selected)R.drawable.button_accent else R.drawable.button_flat)
            t.closeButton.setTextColor(if(selected)Color.WHITE else if(t.isError)red else Color.rgb(185,181,191))
        }
    }

    private fun clearResults(){tabStrip.removeAllViews();resultContainer.removeAllViews();tabs.clear();activeTab=-1}
    private fun showPlaceholder(){val t=TextView(this);t.text="Run a query to see results here";t.setTextColor(Color.rgb(104,108,120));t.textSize=13f;t.gravity=Gravity.CENTER;resultContainer.removeAllViews();resultContainer.addView(t)}
    private fun buildMessageView(msg:String):View{val t=TextView(this);t.text=msg;t.textSize=13f;t.setTextColor(Color.rgb(185,181,191));t.setPadding(20,20,20,20);val s=ScrollView(this);s.addView(t);return s}

    private fun schemaText():String{val b=StringBuilder();db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->if(!c.moveToFirst())b.append("No tables yet.\nImport a .db or .sql file,\nor run a CREATE TABLE.")else{do{val n=c.getString(0);b.append(n).append("  ");try{db.rawQuery("SELECT COUNT(*) FROM \""+n.replace("\"","\"\"")+"\"",null).use{r->if(r.moveToFirst())b.append("(").append(r.getLong(0)).append(" rows)")}}catch(_:Exception){};b.append("\n");db.rawQuery("PRAGMA table_info('"+n.replace("'","''")+"')",null).use{p->while(p.moveToNext())b.append("   ").append(p.getString(1)).append("  ").append(p.getString(2).ifBlank{"ANY"}).append("\n")};b.append("\n")}while(c.moveToNext())}};return b.toString().trimEnd()}

    private fun interactiveSchema():SpannableStringBuilder{
        val out=SpannableStringBuilder()
        out.append("DATABASE  ·  ").append(dbFile.name).append("\n\nTABLES\n")
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->
            if(!c.moveToFirst()){out.append("No tables yet.\nImport a .db/.sql file or create a table.");return out}
            do{
                val table=c.getString(0); val start=out.length; out.append("▾ ").append(table)
                try{db.rawQuery("SELECT COUNT(*) FROM \""+table.replace("\"","\"\"")+"\"",null).use{r->if(r.moveToFirst())out.append("  ·  ").append(r.getLong(0).toString()).append(" rows")}}catch(_:Exception){}
                out.append("\n")
                out.setSpan(object:ClickableSpan(){override fun onClick(w:View){showTableExplorer(table)};override fun updateDrawState(ds:android.text.TextPaint){ds.color=blue;ds.isUnderlineText=false;ds.isFakeBoldText=true}},start,out.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                db.rawQuery("PRAGMA table_info('"+table.replace("'","''")+"')",null).use{p->while(p.moveToNext()){val col=p.getString(1);val typ=p.getString(2).ifBlank{"ANY"};val cs=out.length;out.append("   ↳ ").append(col).append("  :  ").append(typ).append("\n");out.setSpan(object:ClickableSpan(){override fun onClick(w:View){insertSql(col)};override fun updateDrawState(ds:android.text.TextPaint){ds.color=white;ds.isUnderlineText=false}},cs,out.length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}}
                out.append("\n")
            }while(c.moveToNext())
        }
        return out
    }

    private fun dp(v:Int):Int=(v*resources.displayMetrics.density).toInt()
    private fun rounded(bg:Int=Color.rgb(24,26,33), stroke:Int=0, strokeColor:Int=Color.TRANSPARENT, radius:Float=18f):android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply{setColor(bg);setCornerRadius(dp(radius.toInt()).toFloat());if(stroke>0)setStroke(dp(stroke),strokeColor)}
    private fun trafficDot(color:Int, onClick:(()->Unit)?=null):View{
        val v=TextView(this)
        v.text=""
        v.background=rounded(color,0,radius=99f)
        if(onClick!=null){
            v.isClickable=true
            v.setOnClickListener{onClick()}
            v.contentDescription="Close"
        }
        return v
    }

    private fun cardDialog(title:String, body:View, actionText:String="Close", onAction:(()->Unit)?=null):Dialog{
        val dialog=Dialog(this)
        val root=LinearLayout(this)
        root.orientation=LinearLayout.VERTICAL
        root.background=rounded(Color.rgb(24,26,33),1,Color.rgb(48,51,62),20f)
        root.elevation=dp(8).toFloat()
        root.clipToOutline=true
        root.outlineProvider=android.view.ViewOutlineProvider.BACKGROUND

        // macOS-inspired title bar: tiny traffic-light dots, lots of breathing room, no visual clutter.
        val head=LinearLayout(this)
        head.orientation=LinearLayout.HORIZONTAL
        head.gravity=Gravity.CENTER_VERTICAL
        head.setPadding(dp(16),dp(8),dp(12),dp(8))
        head.background=android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        val dots=LinearLayout(this)
        dots.orientation=LinearLayout.HORIZONTAL
        dots.gravity=Gravity.CENTER_VERTICAL
        val redDot=trafficDot(Color.rgb(255,95,87)){dialog.dismiss()}
        redDot.contentDescription="Close window"
        dots.addView(redDot,LinearLayout.LayoutParams(dp(13),dp(13)))
        val yellowDot=trafficDot(Color.rgb(254,188,46))
        val greenDot=trafficDot(Color.rgb(40,201,64))
        dots.addView(yellowDot,LinearLayout.LayoutParams(dp(13),dp(13)).apply{leftMargin=dp(7)})
        dots.addView(greenDot,LinearLayout.LayoutParams(dp(13),dp(13)).apply{leftMargin=dp(7)})
        head.addView(dots,LinearLayout.LayoutParams(dp(67),dp(38)))

        val titleView=TextView(this)
        titleView.text=title
        titleView.textSize=16f
        titleView.setTextColor(white)
        titleView.setTypeface(null,android.graphics.Typeface.BOLD)
        titleView.gravity=Gravity.CENTER
        head.addView(titleView,LinearLayout.LayoutParams(0,dp(38),1f))

        val spacer=Space(this)
        head.addView(spacer,LinearLayout.LayoutParams(dp(67),dp(38)))
        root.addView(head)

        val line=View(this)
        line.setBackgroundColor(Color.rgb(42,45,55))
        root.addView(line,LinearLayout.LayoutParams(-1,dp(1)))

        val content=FrameLayout(this)
        content.setPadding(dp(20),dp(16),dp(20),dp(8))
        content.addView(body,FrameLayout.LayoutParams(-1,-2))
        root.addView(content,LinearLayout.LayoutParams(-1,0,1f))

        if(onAction!=null && actionText.isNotBlank()){
            val footer=LinearLayout(this)
            footer.gravity=Gravity.END or Gravity.CENTER_VERTICAL
            footer.setPadding(dp(20),dp(4),dp(20),dp(12))
            val action=Button(ContextThemeWrapper(this,R.style.FlatButton))
            action.text=actionText
            action.isAllCaps=false
            action.minHeight=0
            action.setPadding(dp(20),0,dp(20),0)
            action.setOnClickListener{onAction.invoke();dialog.dismiss()}
            footer.addView(action,LinearLayout.LayoutParams(-2,dp(42)))
            root.addView(footer)
        }

        dialog.setContentView(root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.attributes=dialog.window?.attributes?.apply{dimAmount=.22f}
        dialog.setOnShowListener{
            val max=dp(760)
            val target=minOf((resources.displayMetrics.widthPixels*.90f).toInt(),max)
            dialog.window?.setLayout(target,WindowManager.LayoutParams.WRAP_CONTENT)
        }
        return dialog
    }

    private fun cardListDialog(title:String, items:List<String>, onPick:(Int)->Unit){
        if(items.isEmpty()){val msg=TextView(this);msg.text="Nothing here yet.";msg.textSize=14f;msg.setTextColor(Color.rgb(185,181,191));msg.setPadding(4,10,4,10);cardDialog(title,msg).show();return}
        val scroll=ScrollView(this);val list=LinearLayout(this);list.orientation=LinearLayout.VERTICAL
        items.forEachIndexed{index,label->val row=TextView(this);row.text=label;row.textSize=14f;row.setTextColor(white);row.gravity=Gravity.CENTER_VERTICAL;row.setPadding(dp(14),0,dp(10),0);row.background=rounded(Color.rgb(31,34,43),1,Color.rgb(45,48,58),10f);row.setOnClickListener{onPick(index)};val lp=LinearLayout.LayoutParams(-1,dp(48));if(index>0)lp.topMargin=dp(7);list.addView(row,lp)}
        scroll.addView(list);cardDialog(title,scroll).show()
    }

    private fun showTableExplorer(table:String){
        val safe=table.replace("\"","\"\"")
        val pragmaSafe=table.replace("'","''")
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(20,4,20,8);box.minimumHeight=dp(420)
        val meta=TextView(this);meta.setTextColor(Color.rgb(185,181,191));meta.textSize=12f;meta.setPadding(0,0,0,10)
        val columns=mutableListOf<Triple<String,String,Boolean>>()
        db.rawQuery("PRAGMA table_info('$pragmaSafe')",null).use{c->while(c.moveToNext()) columns.add(Triple(c.getString(1),c.getString(2).ifBlank{"ANY"},c.getInt(5)>0))}
        val count=db.rawQuery("SELECT COUNT(*) FROM \"$safe\"",null).use{c->c.moveToFirst();c.getLong(0)}
        meta.text="${columns.size} columns  ·  $count rows  ·  previewing first 50"
        box.addView(meta)
        val actions=LinearLayout(this);actions.orientation=LinearLayout.HORIZONTAL
        val select=Button(ContextThemeWrapper(this,R.style.FlatButton));select.text="Insert SELECT *";select.isAllCaps=false;select.setOnClickListener{insertSql("SELECT * FROM \"$table\";");statusOk("Inserted SELECT from explorer")};actions.addView(select)
        box.addView(actions)
        val colLabel=TextView(this);colLabel.text="Columns — tap a column to insert it";colLabel.setTextColor(blue);colLabel.textSize=12f;colLabel.setPadding(0,12,0,6);box.addView(colLabel)
        val colScroll=HorizontalScrollView(this);val colRow=LinearLayout(this);colRow.orientation=LinearLayout.HORIZONTAL
        for((name,type,pk) in columns){val b=Button(ContextThemeWrapper(this,R.style.FlatButton));b.text=name+" : "+type+(if(pk)"  PK" else "");b.isAllCaps=false;b.setOnClickListener{insertSql("\"${name.replace("\"","\"\"")}\"")};colRow.addView(b)}
        colScroll.addView(colRow);box.addView(colScroll)
        val previewLabel=TextView(this);previewLabel.text="Data preview";previewLabel.setTextColor(blue);previewLabel.textSize=12f;previewLabel.setPadding(0,12,0,6);box.addView(previewLabel)
        val previewData=mutableListOf<List<String>>()
        db.rawQuery("SELECT * FROM \"$safe\" LIMIT 50",null).use{c->previewData.add((0 until c.columnCount).map{c.getColumnName(it)});while(c.moveToNext())previewData.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)})}
        val preview=buildPreviewGrid(previewData)
        box.addView(preview,LinearLayout.LayoutParams(-1,0,1f))
        cardDialog(table,box).show()
    }

    private fun buildPreviewGrid(data:List<List<String>>):View{
        val table=TableLayout(this);table.isStretchAllColumns=false
        if(data.isEmpty()) return TextView(this).apply{text="No columns";setPadding(12,12,12,12)}
        val header=TableRow(this)
        for(v in data[0]) header.addView(cell(v,true){})
        table.addView(header)
        for(i in 1 until data.size){val row=TableRow(this);for(v in data[i]) row.addView(cell(v,false){copyText(v)});table.addView(row)}
        if(data.size==1){table.addView(TextView(this).apply{text="(0 rows)";setPadding(16,16,16,16)})}
        val hs=HorizontalScrollView(this);hs.addView(table);val vs=ScrollView(this);vs.addView(hs);return vs
    }

    private fun insertSql(text:String){val a=editor.selectionStart.coerceAtLeast(0);val z=editor.selectionEnd.coerceAtLeast(0);val s=minOf(a,z);val e=maxOf(a,z);editor.text.replace(s,e,text);editor.setSelection((s+text.length).coerceAtMost(editor.length()));editor.requestFocus();statusOk("Inserted from database explorer")}

    private fun showSchema(){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;box.setPadding(24,8,24,0);box.minimumHeight=dp(300)
        val hint=TextView(this);hint.text="Current: ${dbFile.name}\nTap a table to inspect it · preview rows · insert SQL · tap a column to insert it";hint.setTextColor(Color.rgb(112,116,129));hint.textSize=12f;hint.setPadding(0,0,0,12);box.addView(hint)
        val import=Button(ContextThemeWrapper(this,R.style.FlatButton));import.text="Import .db / .sql";import.isAllCaps=false;import.setOnClickListener{dismissAutocomplete();pickFile()};box.addView(import,LinearLayout.LayoutParams(-1,dp(42)).apply{bottomMargin=dp(10)})
        val scroll=ScrollView(this);val view=TextView(this);view.text=interactiveSchema();view.setTextSize(12f);view.setTextColor(white);view.setMovementMethod(LinkMovementMethod.getInstance());view.setHighlightColor(Color.TRANSPARENT);scroll.addView(view);box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        cardDialog("Database Explorer",box).show()
    }
    private fun refreshSchemaPanel(){schemaPanel?.apply{text=interactiveSchema();movementMethod=LinkMovementMethod.getInstance();highlightColor=Color.TRANSPARENT}}
    private fun firstTable():String{db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 1",null).use{c->if(c.moveToFirst())return c.getString(0)};return "employee_demographics"}
    private fun chooseDatabase(){val names=listOf("Parks & Recreation","Northwind-style");cardListDialog("Sample database",names){which->val asset=if(which==0)"Parks_and_Recreation.db" else "Northwind.db";bundledAsset=asset;db.close();dbFile=File(filesDir,asset);if(!dbFile.exists())assets.open(asset).use{i->dbFile.outputStream().use{i.copyTo(it)}};db=SQLiteDatabase.openOrCreateDatabase(dbFile,null);clearResults();showPlaceholder();editor.setText("SELECT * FROM ${firstTable()};");statusOk("Using $asset");refreshSchemaPanel()}}

    private fun resetDatabase(){db.close();dbFile.delete();copyBundledDatabase(bundledAsset);clearResults();showPlaceholder();editor.setText("SELECT * FROM ${firstTable()};");statusOk("Database reset");refreshSchemaPanel()}
    private fun statusOk(s:String){status.text="✓ $s";status.setTextColor(green)};private fun showError(s:String){status.text="✕ $s";status.setTextColor(red)}

    private fun highlight(){if(highlighting)return;highlighting=true;val e=editor.text;val pos=editor.selectionStart;e.getSpans(0,e.length,ForegroundColorSpan::class.java).forEach{e.removeSpan(it)};val text=e.toString();val patterns=listOf(Pattern.compile("(?i)\\b("+keywords.joinToString("|")+")\\b") to blue,Pattern.compile("'(?:''|[^'])*'") to orange,Pattern.compile("--[^\\n]*") to Color.rgb(180,172,160),Pattern.compile("\\b\\d+(?:\\.\\d+)?\\b") to green);for((p,col) in patterns)p.matcher(text).run{while(find())e.setSpan(ForegroundColorSpan(col),start(),end(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)};editor.setSelection(pos.coerceIn(0,e.length));highlighting=false}

    private fun formatSql(s:String):String{var x=s.replace(Regex("\\s+")," ").replace(Regex("\\s*;\\s*"),";\n");val kws=listOf("SELECT","FROM","WHERE","JOIN","LEFT JOIN","RIGHT JOIN","INNER JOIN","ORDER BY","GROUP BY","HAVING","LIMIT","UNION","VALUES","SET");for(k in kws)x=x.replace(Regex("\\s*${k.replace(" ","\\s+")}\\s*",RegexOption.IGNORE_CASE),"\n${k} ");return x.trim().replace(Regex("\\n+"),"\n")}
    private fun toggleComment(){val a=editor.selectionStart;val z=editor.selectionEnd;val s=minOf(a,z);val e=maxOf(a,z);val start=editor.text.lastIndexOf('\n',s-1).let{if(it<0)0 else it+1};val end=editor.text.indexOf('\n',e).let{if(it<0)editor.length() else it};val block=editor.text.substring(start,end);val lines=block.split('\n');val uncomment=lines.filter{it.trimStart().startsWith("--")}.size>lines.size/2;val repl=lines.joinToString("\n"){if(uncomment)it.replaceFirst(Regex("^\\s*--\\s?"),"") else if(it.isBlank())it else "-- $it"};editor.text.replace(start,end,repl);editor.setSelection(start,start+repl.length)}

    private fun showHistory(){
        if(history.isEmpty()){val msg=TextView(this);msg.text="No queries have been run yet.";msg.textSize=14f;msg.setTextColor(Color.rgb(185,181,191));cardDialog("Query history",msg).show();return}
        cardListDialog("Query history",history){which->editor.setText(history[which]);editor.setSelection(editor.length());statusOk("Query restored from history")}
    }
    private fun saveSnippetDialog(){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL
        val hint=TextView(this);hint.text="Give this query a short name.";hint.textSize=12f;hint.setTextColor(Color.rgb(127,131,144));box.addView(hint)
        val input=EditText(this);input.hint="e.g. My JOIN practice";input.setSingleLine(true);input.textSize=14f;input.setTextColor(white);input.setPadding(dp(12),0,dp(12),0);input.background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),12f);box.addView(input,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(10)})
        cardDialog("Save snippet",box,"Save"){val name=input.text.toString().trim();if(name.isNotEmpty()){snippets[name]=editor.text.toString();prefs.edit().putString("snippet:$name",editor.text.toString()).apply();statusOk("Snippet saved: $name")}}.show()
        input.requestFocus()
    }
    private fun showSnippetMenu(){
        val names=snippets.keys.toList();val items=if(names.isEmpty())listOf("＋  Save current snippet") else listOf("＋  Save current snippet")+names
        cardListDialog("Snippets",items){i->if(i==0)saveSnippetDialog()else{editor.setText(snippets[names[i-1]]);editor.setSelection(editor.length());statusOk("Snippet loaded")}}
    }

    private fun showExplain(msg:String){
        val lower=msg.lowercase();val hint=when{lower.contains("no such column")->"SQLite cannot find that column. Check spelling, table aliases, and whether the column belongs to the table you are querying.";lower.contains("no such table")->"SQLite cannot find that table. Check the table name and make sure you imported or created the right database.";lower.contains("syntax error")->"SQLite could not parse the SQL. Check commas, parentheses, quotes, keywords, and statement order.";lower.contains("constraint failed")->"A table constraint was violated. Check PRIMARY KEY, UNIQUE, NOT NULL, FOREIGN KEY, or CHECK rules.";lower.contains("datatype mismatch")->"A value does not fit the operation or column type. Check casts and the values being inserted or compared.";lower.contains("ambiguous column")->"More than one table has that column name. Qualify it with a table name or alias, for example e.salary.";else->"Run the statement again and inspect the SQLite message above. Start by checking table names, column names, aliases, commas, quotes, and parentheses."}
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;val icon=TextView(this);icon.text="SQLite error";icon.textSize=12f;icon.setTextColor(red);icon.setTypeface(null,android.graphics.Typeface.BOLD);box.addView(icon);val text=TextView(this);text.text=hint;text.textSize=14f;text.setTextColor(white);text.setPadding(0,dp(8),0,dp(8));box.addView(text);cardDialog("Explain this error",box).show()
    }

    private fun showPractice(){
        val challenges=listOf("Find employees older than 40","Join salary with demographics","Find the highest 3 salaries","Count employees by gender","Show all departments")
        cardListDialog("Practice mode",challenges.mapIndexed{i,s->"${i+1}.  $s"}){which->currentChallenge=which;editor.setText(challengeSql[which]);editor.setSelection(editor.length());statusOk("Challenge loaded — run it, then tap Check")}
    }
    private fun checkPractice(){if(currentChallenge<0){showError("Load a practice challenge first");return};try{val user=editor.text.toString();val expected=challengeSql[currentChallenge];val ur=collectResult(user);val er=collectResult(expected);if(ur==er)statusOk("Practice check passed ✓ — result matches the expected output")else showError("Practice check did not match the expected output. Compare columns, rows, ordering, and filters.")}catch(e:Exception){showError("Practice check error: ${e.message?:"SQL error"}")}}
    private fun collectResult(sql:String):List<List<String>>{val q=splitSql(sql).lastOrNull{isQueryStatement(it)}?:throw Exception("No query found");db.rawQuery(q,null).use{c->val out=mutableListOf<List<String>>();out.add((0 until c.columnCount).map{c.getColumnName(it)});while(c.moveToNext())out.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)});return out}}

    private fun planRows(sql:String):List<Triple<Int,Int,String>>{val out=mutableListOf<Triple<Int,Int,String>>();db.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(Triple(c.getInt(0),c.getInt(1),c.getString(3))) };return out}
    private fun buildPlanView(rows:List<Triple<Int,Int,String>>):View{val t=LinearLayout(this);t.orientation=LinearLayout.VERTICAL;t.setPadding(18,16,18,16);for((id,parent,detail) in rows){val v=TextView(this);v.text=(if(parent==0)"▸ " else "  └─ ")+detail+"  [id=$id parent=$parent]";v.textSize=13f;v.setTextColor(white);v.setPadding(8,8,8,8);t.addView(v)};val s=ScrollView(this);s.addView(t);return s}

    private fun exportDatabase(){val i=Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.type="application/octet-stream";i.putExtra(Intent.EXTRA_TITLE,"ProjectLily-${dbFile.name}");startActivityForResult(i,88)}
    private fun exportCsv(){if(activeTab<0||tabs[activeTab].csv==null){showError("Run a result query first");return};val csv=tabs[activeTab].csv!!.joinToString("\n"){row->row.joinToString(","){csvEscape(it)}};val i=Intent(Intent.ACTION_SEND);i.type="text/csv";i.putExtra(Intent.EXTRA_TEXT,csv);i.putExtra(Intent.EXTRA_TITLE,"query-result.csv");startActivity(Intent.createChooser(i,"Share CSV"))}
    private fun csvEscape(s:String)=if(s.contains(',')||s.contains('"')||s.contains('\n'))"\"${s.replace("\"","\"\"")}\"" else s

    private fun updateAutocomplete(){
        dismissAutocomplete()
        if(!editor.hasFocus() || !::db.isInitialized || !db.isOpen) return
        val cursor=editor.selectionStart
        if(cursor<1 || editor.selectionStart!=editor.selectionEnd) return
        val before=editor.text.substring(0,cursor)

        // Only offer completion after a meaningful SQL trigger. Never show a
        // permanent/generic keyword list while the user is simply typing.
        val tokenMatch=Regex("[A-Za-z_][A-Za-z0-9_]*$").find(before)
        val token=tokenMatch?.value.orEmpty()
        val tokenStart=if(token.isNotEmpty()) cursor-token.length else cursor
        val context=before.substring(0,tokenStart)
        val trimmed=context.trimEnd()
        val dot=trimmed.endsWith('.')
        val mode=when{
            Regex("\\b(from|join|update|into|table)\\s+$",RegexOption.IGNORE_CASE).containsMatchIn(trimmed) && token.isNotEmpty()->"table"
            Regex("\\b(select|where|on|order\\s+by|group\\s+by|having|set|and|or)\\s+$",RegexOption.IGNORE_CASE).containsMatchIn(trimmed) && token.isNotEmpty()->"column"
            dot->"qualified"
            else->null
        } ?: return

        val names=mutableListOf<String>()
        if(mode=="table"){
            db.rawQuery("SELECT name FROM sqlite_master WHERE (type='table' OR type='view') AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->
                while(c.moveToNext()) if(c.getString(0).startsWith(token,ignoreCase=true)) names.add(c.getString(0))
            }
        }else{
            val qualifier=if(mode=="qualified") Regex("([A-Za-z_][A-Za-z0-9_]*)\\.$").find(trimmed)?.groupValues?.get(1) else null
            val tables=mutableListOf<String>()
            if(qualifier!=null){
                db.rawQuery("SELECT name FROM sqlite_master WHERE (type='table' OR type='view') AND name NOT LIKE 'sqlite_%'",null).use{c->{
                    while(c.moveToNext()) if(c.getString(0).equals(qualifier,true)) tables.add(c.getString(0))
                }}
                Regex("\\b(?:from|join)\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s+(?:as\\s+)?([A-Za-z_][A-Za-z0-9_]*))?",RegexOption.IGNORE_CASE).findAll(before).forEach{m->
                    val table=m.groupValues[1]
                    val alias=m.groupValues.getOrNull(2).orEmpty()
                    if(alias.equals(qualifier,true)) tables.add(table)
                }
                if(tables.isEmpty()) return
            }else{
                Regex("\\b(?:from|join)\\s+([A-Za-z_][A-Za-z0-9_]*)",RegexOption.IGNORE_CASE).findAll(before).forEach{m->tables.add(m.groupValues[1])}
                if(tables.isEmpty()) return
            }
            val wanted=token.lowercase(Locale.US)
            tables.distinct().forEach{table->
                val safe=table.replace("'","''")
                try {
                    db.rawQuery("PRAGMA table_info('$safe')", null).use { c ->
                        while (c.moveToNext()) {
                            val column = c.getString(1)
                            if (column.lowercase(Locale.US).startsWith(wanted)) names.add(column)
                        }
                    }
                } catch (_: Exception) {}
            }
        }

        val suggestions=names.distinct().take(6)
        if(suggestions.isEmpty()) return

        val popup=PopupWindow(this)
        autocompletePopup=popup
        autocompleteTokenStart=tokenStart

        val list=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(4),dp(4),dp(4),dp(4))
            background=rounded(Color.rgb(20,22,29),1,Color.rgb(48,51,62),12f)
        }
        suggestions.forEachIndexed{index,suggestion->
            val row=TextView(this).apply{
                text=suggestion
                textSize=13f
                setTextColor(white)
                gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(11),0,dp(11),0)
                isSingleLine=true
                ellipsize=android.text.TextUtils.TruncateAt.END
                background=rounded(Color.rgb(31,34,43),0,radius=7f)
                isClickable=true
                setOnClickListener{
                    val start=autocompleteTokenStart
                    val end=editor.selectionStart
                    if(start>=0 && start<=end && end<=editor.length() && !isFinishing){
                        suppressAutocompleteDismiss=true
                        try{
                            editor.text.replace(start,end,suggestion)
                            editor.setSelection((start+suggestion.length).coerceAtMost(editor.length()))
                        }catch(_:Exception){}
                        finally{suppressAutocompleteDismiss=false}
                    }
                    dismissAutocomplete()
                    editor.requestFocus()
                }
            }
            list.addView(row,LinearLayout.LayoutParams(-1,dp(34)).apply{if(index>0)topMargin=dp(1)})
        }

        popup.contentView=list
        popup.width=dp(210)
        popup.height=dp(8+34*suggestions.size+(suggestions.size-1))
        popup.isFocusable=false
        popup.isOutsideTouchable=true
        popup.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        popup.setTouchInterceptor { _, event -> if(event.actionMasked==MotionEvent.ACTION_OUTSIDE){dismissAutocomplete();false}else false }
        popup.elevation=dp(6).toFloat()
        editor.post{positionAutocomplete(popup)}
    }

    private fun positionAutocomplete(popup:PopupWindow){
        if(autocompletePopup!==popup || !editor.isShown) return
        val layout=editor.layout ?: return
        val cursor=editor.selectionStart.coerceIn(0,editor.length())
        val line=layout.getLineForOffset(cursor)
        val x=layout.getPrimaryHorizontal(cursor).toInt()-editor.scrollX
        val lineTop=layout.getLineTop(line)-editor.scrollY
        val loc=IntArray(2)
        editor.getLocationOnScreen(loc)
        val popupW=popup.width
        val margin=dp(8)
        val screenW=resources.displayMetrics.widthPixels
        val screenH=resources.displayMetrics.heightPixels
        val px=(loc[0]+x).coerceIn(margin,(screenW-popupW-margin).coerceAtLeast(margin))
        val popupH=popup.height
        var py=loc[1]+lineTop+editor.lineHeight+dp(3)
        if(py+popupH>screenH-margin) py=loc[1]+lineTop-popupH-dp(3)
        py=py.coerceAtLeast(margin)
        try{popup.showAtLocation(editor,Gravity.TOP or Gravity.START,px,py)}catch(_:WindowManager.BadTokenException){dismissAutocomplete()}
    }

    private fun dismissAutocomplete(){
        autocompletePopup?.dismiss()
        autocompletePopup=null
        autocompleteTokenStart=-1
    }

    internal fun shouldKeepAutocompleteVisible():Boolean = suppressAutocompleteDismiss
    internal fun dismissAutocompleteFromEditor(){dismissAutocomplete()}

    override fun onKeyDown(keyCode:Int,event:KeyEvent):Boolean{if((event.isCtrlPressed||event.isMetaPressed)&&keyCode==KeyEvent.KEYCODE_ENTER){runSelectedOrAll();return true};if((event.isCtrlPressed||event.isMetaPressed)&&keyCode==KeyEvent.KEYCODE_SLASH){toggleComment();return true};return super.onKeyDown(keyCode,event)}
    override fun onDestroy(){dismissAutocomplete();if(::db.isInitialized&&db.isOpen)db.close();super.onDestroy()}
}

class LineNumberEditText(context:Context, attrs:android.util.AttributeSet?=null):android.widget.EditText(context,attrs){    override fun onSelectionChanged(selStart:Int,selEnd:Int){
        super.onSelectionChanged(selStart,selEnd)
        (context as? MainActivity)?.let { if(!it.shouldKeepAutocompleteVisible()) it.dismissAutocompleteFromEditor() }
    }

    private val paint=android.graphics.Paint().apply{color=Color.rgb(91,95,108);textSize=36f;typeface=android.graphics.Typeface.MONOSPACE}
    init{setPadding(58,paddingTop,paddingRight,paddingBottom);setBackgroundColor(Color.TRANSPARENT);setTextColor(Color.rgb(231,227,233));setOnFocusChangeListener{_,_->invalidate()}}
    override fun onDraw(canvas:android.graphics.Canvas){val lineH=lineHeight.toFloat();val current=layout?.getLineForOffset(selectionStart)?:0;val top=current*lineH-scrollY;val hi=android.graphics.Paint().apply{color=Color.rgb(39,31,40)};canvas.drawRect(0f,top,width.toFloat(),top+lineH,hi);val first=(scrollY/lineH).toInt();val last=((scrollY+height)/lineH).toInt()+1;paint.textSize=textSize*0.78f;for(line in first..last){val y=(line+1)*lineH - scrollY;canvas.drawText((line+1).toString(),8f,y,paint)};super.onDraw(canvas)}
}
