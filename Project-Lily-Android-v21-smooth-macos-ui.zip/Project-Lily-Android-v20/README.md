# Project Lily v19

Dark macOS-inspired SQL workspace with themed window controls and robust SQL import normalization.

## v19 fixes
- MySQL-style `AUTO_INCREMENT` columns are converted to SQLite `INTEGER PRIMARY KEY AUTOINCREMENT` even when constraints appear in different orders.
- Single-column table-level integer primary keys are promoted to SQLite `INTEGER PRIMARY KEY`, allowing `NULL` IDs in dump inserts to auto-generate IDs.
- Existing database/schema import flow remains intact.
- macOS-style dots now use coordinated Project Lily mauve/pink/lavender shades instead of traffic-light red/yellow/green.
