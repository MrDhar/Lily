# Project Lily v22

Based on Project Lily v21.

Changes:
- Fixed resize-handle Kotlin type issue by casting parent LinearLayout.LayoutParams before setting height/weight.
- Added immersive fullscreen mode on launch; hides status and navigation system bars and reapplies on window focus.
- Bumped version to 1.8 (versionCode 17).
