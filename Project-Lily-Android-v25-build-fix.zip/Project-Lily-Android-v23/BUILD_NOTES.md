# Project Lily v24 build notes

This build includes the missing Kotlin helper implementations that were causing unresolved-reference compiler errors in v23, plus a cleaned GitHub Actions workflow.

## GitHub Actions

Use `.github/workflows/android-build.yml` from this project. It intentionally does **not** pass `build-root-directory` to `gradle/actions/setup-gradle`, because that is not a supported input for the action. It uses current Node 24-compatible action releases:

- `actions/checkout@v6`
- `actions/setup-java@v5`
- `gradle/actions/setup-gradle@v6`
- `actions/upload-artifact@v6`

The workflow can build either an already-extracted Android project or a Project Lily ZIP stored at the repository root.
