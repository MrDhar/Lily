# Project Lily v23

Based on Project Lily v22.

## Workspace fixes
- SQL Server + MySQL `.sql` imports are translated more safely for SQLite, including `IDENTITY_INSERT`, `GO`, bracketed identifiers, identity primary keys, common SQL Server types, and dump-only index/constraint statements.
- Imported databases persist locally as the active working database after app restart.
- Database Explorer is cleaner and more structured; tables are clickable and preview their first 50 rows directly in the main workspace instead of opening a table popup.
- Clicking a column inserts its quoted name into the editor.
- Empty Views/Indexes sections are hidden to reduce clutter.
- Tablet layout now has a real editor/results splitter.
- Project Lily remains immersive fullscreen and keeps the dark Lily/macOS-inspired visual language.
