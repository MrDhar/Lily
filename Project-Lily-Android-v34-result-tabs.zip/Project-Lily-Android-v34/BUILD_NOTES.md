# Project Lily v24 build notes

This build includes the missing Kotlin helper implementations that were causing unresolved-reference compiler errors in v23, plus a cleaned GitHub Actions workflow.

## GitHub Actions

Use `.github/workflows/android-build.yml` from this project. It intentionally does **not** pass `build-root-directory` to `gradle/actions/setup-gradle`, because that is not a supported input for the action. It uses current Node 24-compatible action releases:

- `actions/checkout@v6`
- `actions/setup-java@v5`
- `gradle/actions/setup-gradle@v6`
- `actions/upload-artifact@v6`

The workflow can build either an already-extracted Android project or a Project Lily ZIP stored at the repository root.

## v29 changes
- Database library and persistent multiple imported databases.
- Removed Reset Database UI.
- Functional main-window controls and clean dialog chrome.
- Tools menu and scrollable Quick History.
- Refined tablet sidebar control and editor/results splitter.


## v32 changes
- Replaced the old Tools row with a searchable command palette on the third window dot.
- Removed the redundant tablet sidebar chevron.
- Added non-blocking database/SQL import progress UI with Lily-themed iOS-style three-dot loading, Cancel, Retry, Close, and completion states.
- Moved import file reading and conversion off the main UI thread and added cancellation checks throughout long SQL imports.
- Bumped app versionCode to 21 and versionName to 2.2.


## v32 import hardening
- Reworked SQL import parsing around SQL Server `GO` batches and semicolon-less INSERT dumps.
- SQL Server `IF EXISTS` cleanup batches are discarded as complete batches so their inner `ALTER/DROP` statements cannot leak into SQLite.
- Added broader vendor compatibility handling for common SQL Server, MySQL/MariaDB, and PostgreSQL DDL/data variants.
- Vendor type/function rewrites are protected from quoted string contents.
- Added resilient handling for duplicate-key/replace/truncate forms and unsupported indexes, constraints, programmable objects, permissions, and database-level controls.
- Data-only imports now infer a union of columns across INSERT statements instead of assuming every row has the same column list.
- Verified the supplied SQL Server model converts to 5 SQLite tables with all schema statements that Lily should retain executing successfully.
- Verified the supplied data dump splits into 3,183 INSERT statements and loads 91 Customer, 29 Supplier, 78 Product, 830 Order, and 2,155 OrderItem rows in the equivalent SQLite import test.
