package com.maalik.projectlily

import android.app.*
import android.animation.ValueAnimator
import android.os.Bundle
import android.content.*
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.provider.Settings
import android.text.*
import android.text.style.ForegroundColorSpan
import android.text.style.ClickableSpan
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.method.LinkMovementMethod
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import java.io.*
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var editor: LineNumberEditText
    private lateinit var status: TextView
    private lateinit var tabStrip: LinearLayout
    private lateinit var resultContainer: FrameLayout
    private lateinit var resultArea: View
    private lateinit var editorSurface: View
    private lateinit var resizeHandle: View
    private lateinit var db: SQLiteDatabase
    private lateinit var dbFile: File
    private var schemaPanel: LinearLayout? = null
    private var sidebarPanel: View? = null
    private var sidebarDivider: View? = null
    private var sidebarOpen = true
    private var focusMode = false
    @Volatile private var importCancelled = false
    private var importDialog: Dialog? = null
    private var importDots: LoadingDotsView? = null
    private var importCancelButton: Button? = null
    private var highlighting = false
    private var autocompletePopup: PopupWindow? = null
    private var autocompleteTokenStart = -1
    private var suppressAutocompleteDismiss = false
    private var currentChallenge = -1
    private var bundledAsset = "Parks_and_Recreation.db"
    private val challengeSql = listOf(
        "SELECT * FROM employee_demographics WHERE age > 40;",
        "SELECT d.first_name, d.last_name, s.salary FROM employee_demographics d JOIN employee_salary s ON d.employee_id=s.employee_id;",
        "SELECT first_name, salary FROM employee_salary ORDER BY salary DESC LIMIT 3;",
        "SELECT gender, COUNT(*) AS total FROM employee_demographics GROUP BY gender;",
        "SELECT * FROM parks_departments ORDER BY department_id;"
    )
    private val prefs by lazy { getSharedPreferences("lily", MODE_PRIVATE) }
    private val history = mutableListOf<String>()
    private val snippets = linkedMapOf<String, String>()

    private val blue=Color.rgb(213,138,175); private val purple=Color.rgb(154,141,184)
    private val green=Color.rgb(143,175,146); private val orange=Color.rgb(208,163,111)
    private val red=Color.rgb(255,107,100); private val white=Color.rgb(231,227,233)
    private val keywords = listOf("SELECT","FROM","WHERE","INSERT","INTO","VALUES","UPDATE","SET","DELETE","CREATE","TABLE","DROP","ALTER","JOIN","INNER","LEFT","RIGHT","FULL","OUTER","CROSS","NATURAL","ON","USING","GROUP","BY","ORDER","ASC","DESC","HAVING","LIMIT","OFFSET","AS","DISTINCT","AND","OR","NOT","NULL","IS","LIKE","GLOB","REGEXP","IN","BETWEEN","ESCAPE","UNION","INTERSECT","EXCEPT","ALL","CASE","WHEN","THEN","ELSE","END","COUNT","SUM","AVG","MIN","MAX","TOTAL","GROUP_CONCAT","OVER","PARTITION","ROWS","RANGE","GROUPS","UNBOUNDED","PRECEDING","FOLLOWING","CURRENT","ROW","ROW_NUMBER","RANK","DENSE_RANK","NTILE","LAG","LEAD","FIRST_VALUE","LAST_VALUE","NTH_VALUE","FILTER","WITH","RECURSIVE","EXISTS","RETURNING","PRIMARY","KEY","FOREIGN","REFERENCES","DEFAULT","UNIQUE","CHECK","CONSTRAINT","AUTOINCREMENT","GENERATED","ALWAYS","STORED","VIRTUAL","WITHOUT","ROWID","STRICT","COLLATE","INDEX","VIEW","TRIGGER","BEFORE","AFTER","INSTEAD","OF","FOR","EACH","BEGIN","CASCADE","RESTRICT","IF","RENAME","COLUMN","TO","ADD","TEMP","TEMPORARY","TRANSACTION","COMMIT","ROLLBACK","SAVEPOINT","RELEASE","ATTACH","DETACH","EXPLAIN","QUERY","PLAN","ANALYZE","VACUUM","PRAGMA","CAST","COALESCE","IFNULL","NULLIF","TRUE","FALSE","CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP")

    data class ResultTab(val button: Button, val closeButton: Button, val container: LinearLayout, val view: View, val isError: Boolean, val csv: List<List<String>>?, val title: String)
    private val tabs=mutableListOf<ResultTab>(); private var activeTab=-1

    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main); enterImmersiveMode()
        editor=findViewById(R.id.editor); status=findViewById(R.id.status); tabStrip=findViewById(R.id.tabStrip); resultContainer=findViewById(R.id.resultContainer); resultArea=findViewById(R.id.resultArea); editorSurface=findViewById(R.id.editorSurface); resizeHandle=findViewById(R.id.resizeHandle); schemaPanel=findViewById(R.id.schemaPanel); sidebarPanel=findViewById(R.id.sidebarPanel); sidebarDivider=findViewById(R.id.sidebarDivider)
        loadPrefs(); openSavedOrBundledDatabase()
        editor.setText("""-- Select a query and tap Run.\n-- Select multiple statements to run only that selection.\nSELECT * FROM employee_demographics;\n\nSELECT first_name, salary\nFROM employee_salary\nORDER BY salary DESC;""")
        editor.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){updateAutocomplete()};override fun afterTextChanged(e:Editable?){highlight(); editor.invalidate()}})
        editor.setOnFocusChangeListener{_,hasFocus->if(!hasFocus)dismissAutocomplete()}
        editor.setSelection(editor.length())
        findViewById<Button>(R.id.runButton).setOnClickListener{runSelectedOrAll()}; findViewById<Button>(R.id.importButton).setOnClickListener{pickFile()}
        findViewById<Button>(R.id.formatButton).setOnClickListener{editor.setText(formatSql(editor.text.toString())); editor.setSelection(editor.length())}
        findViewById<Button>(R.id.commentButton).setOnClickListener{toggleComment()}; findViewById<Button>(R.id.exportDbButton).setOnClickListener{exportDatabase()}; findViewById<Button>(R.id.exportCsvButton).setOnClickListener{exportCsv()}; findViewById<Button>(R.id.explainButton).setOnClickListener{showExplain(status.text.toString())}
        setupResizeHandle(); setupWindowDots(); refreshSchemaPanel(); showPlaceholder()
    }

    private fun enterImmersiveMode(){
        if(android.os.Build.VERSION.SDK_INT>=30){
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let{ controller ->
                controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior=android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }else{
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility=(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        }
    }

    override fun onWindowFocusChanged(hasFocus:Boolean){
        super.onWindowFocusChanged(hasFocus)
        if(hasFocus) enterImmersiveMode()
    }

    private fun loadPrefs(){
        history.addAll(prefs.getStringSet("history", emptySet<String>())!!.toList())
        prefs.all.filterKeys{it.startsWith("snippet:")}.forEach{snippets[it.key.removePrefix("snippet:")]=it.value as String}
    }
    private fun savePrefs(){prefs.edit().putStringSet("history",history.take(30).toSet()).apply()}

    private fun userDatabasePaths():MutableList<String>{
        return prefs.getStringSet("user_db_paths", emptySet<String>())?.filter{it.isNotBlank()&&File(it).exists()}?.toMutableList() ?: mutableListOf()
    }
    private fun saveUserDatabasePaths(paths:Collection<String>){prefs.edit().putStringSet("user_db_paths",paths.toSet()).apply()}
    private fun databaseLabel(path:String):String{
        val stored=prefs.getString("db_label_"+path.hashCode(),null)
        if(!stored.isNullOrBlank())return stored
        var n=File(path).name
        n=n.replace(Regex("^Imported_\\d+_"),"")
        return n.substringBeforeLast('.',n).ifBlank{"Database"}
    }
    private fun registerUserDatabase(path:String,label:String){
        val paths=userDatabasePaths();paths.remove(path);paths.add(path);saveUserDatabasePaths(paths)
        prefs.edit().putString("db_label_"+path.hashCode(),label.ifBlank{databaseLabel(path)}).apply()
    }
    private fun unregisterUserDatabase(path:String){
        val paths=userDatabasePaths();paths.remove(path);saveUserDatabasePaths(paths);prefs.edit().remove("db_label_"+path.hashCode()).apply()
    }
    private fun isBundledSample(path:String):Boolean=path.startsWith(filesDir.absolutePath+File.separator+"Sample_")

    private fun openSavedOrBundledDatabase(){
        val saved=prefs.getString("active_db_path",null)
        if(!saved.isNullOrBlank()){
            val f=File(saved)
            if(f.exists()){try{dbFile=f;db=SQLiteDatabase.openDatabase(f.path,null,SQLiteDatabase.OPEN_READWRITE);if(!isBundledSample(f.path))registerUserDatabase(f.path,databaseLabel(f.path));return}catch(_:Exception){}}
        }
        val users=userDatabasePaths()
        if(users.isNotEmpty()){
            val f=File(users.first())
            try{dbFile=f;db=SQLiteDatabase.openDatabase(f.path,null,SQLiteDatabase.OPEN_READWRITE);prefs.edit().putString("active_db_path",f.path).apply();return}catch(_:Exception){}
        }
        copyBundledDatabase("Parks_and_Recreation.db")
        prefs.edit().putString("active_db_path",dbFile.path).apply()
    }

    private fun copyBundledDatabase(asset:String){
        val safe=asset.replace(Regex("[^A-Za-z0-9._-]"),"_")
        dbFile=File(filesDir,"Sample_$safe")
        if(!dbFile.exists()) assets.open(asset).use{i->dbFile.outputStream().use{o->i.copyTo(o)}}
        db=SQLiteDatabase.openOrCreateDatabase(dbFile,null)
    }

    private fun activateDatabase(path:String,label:String?=null){
        val target=File(path)
        val opened=SQLiteDatabase.openDatabase(target.path,null,SQLiteDatabase.OPEN_READWRITE)
        if(::db.isInitialized&&db.isOpen)db.close()
        db=opened;dbFile=target
        prefs.edit().putString("active_db_path",target.path).apply()
        label?.let{prefs.edit().putString("db_label_"+target.path.hashCode(),it).apply()}
        clearResults();showPlaceholder();editor.setText(if(firstTable().isNotBlank())"SELECT * FROM \"${firstTable().replace("\"","\"\"")}\";" else "");editor.setSelection(editor.length());refreshSchemaPanel();statusOk("Using ${databaseLabel(target.path)}")
    }
    private fun pickFile(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE)
            type="*/*"
        }
        startActivityForResult(i,77)
    }

    private fun displayName(uri:Uri):String{
        var name:String?=null
        try{contentResolver.query(uri,arrayOf("_display_name"),null,null,null)?.use{c->if(c.moveToFirst())name=c.getString(0)}}catch(_:Exception){}
        return name ?: (uri.lastPathSegment ?: "import.sql").substringAfterLast('/').ifBlank{"import.sql"}
    }

    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data)
        if(req==88&&res==RESULT_OK&&data?.data!=null){
            try{contentResolver.openOutputStream(data.data!!).use{out->dbFile.inputStream().use{it.copyTo(out!!)}};statusOk("Database exported")}catch(e:Exception){showError(e.message?:"Export failed")}
            return
        }
        if(req!=77||res!=RESULT_OK||data?.data==null)return
        val uri=data.data!!
        try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
        val fileName=displayName(uri)
        startImport(uri,fileName)
    }

    private data class ImportOutcome(val database:SQLiteDatabase,val target:File,val label:String,val status:String)
    private class ImportCancelledException:Exception("Import cancelled")

    private fun startImport(uri:Uri,fileName:String){
        val name=fileName.lowercase(Locale.US)
        val title=when{name.endsWith(".db")||name.endsWith(".sqlite")||name.endsWith(".sqlite3")->"Importing database";else->"Importing SQL"}
        showImportProgress(title,fileName)
        importCancelled=false
        Thread {
            try{
                checkImportCancelled()
                val bytes=contentResolver.openInputStream(uri)?.use{it.readBytes()} ?: throw Exception("Could not read the selected file")
                checkImportCancelled()
                val outcome=when{
                    name.endsWith(".db")||name.endsWith(".sqlite")||name.endsWith(".sqlite3")->importDatabaseBytes(bytes,fileName)
                    name.endsWith(".sql")||name.endsWith(".txt")->importSqlScript(bytes.toString(Charsets.UTF_8),fileName)
                    else->{
                        val text=bytes.toString(Charsets.UTF_8)
                        if(Regex("(?is)\\b(CREATE|INSERT|ALTER|DROP)\\s+").containsMatchIn(text)) importSqlScript(text,fileName)
                        else throw Exception("Unsupported file. Choose a .sql, .db, .sqlite, or .sqlite3 file.")
                    }
                }
                checkImportCancelled()
                runOnUiThread{finishImportedDatabase(outcome)}
            }catch(_:ImportCancelledException){
                runOnUiThread{showImportCancelled()}
            }catch(e:Exception){
                runOnUiThread{showImportFailure(e.message?:"Could not import the selected file",uri,fileName)}
            }
        }.start()
    }

    private fun checkImportCancelled(){if(importCancelled)throw ImportCancelledException()}

    private fun importDatabaseBytes(bytes:ByteArray,fileName:String):ImportOutcome{
        checkImportCancelled()
        if(bytes.size<16 || String(bytes,0,16,Charsets.US_ASCII)!="SQLite format 3\u0000") throw Exception("The selected file is not a valid SQLite database")
        val safe=fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")
        val target=File(filesDir,"Imported_${System.currentTimeMillis()}_$safe")
        try{
            target.writeBytes(bytes)
            checkImportCancelled()
        }catch(e:Exception){target.delete();throw e}
        val opened=try{SQLiteDatabase.openDatabase(target.path,null,SQLiteDatabase.OPEN_READWRITE)}catch(e:Exception){target.delete();throw Exception("Could not open SQLite database: ${e.message?:"invalid database"}")}
        try{
            if(!hasUserTables(opened)) throw Exception("The database opened successfully but contains no user tables")
            checkImportCancelled()
            return ImportOutcome(opened,target,fileName.substringBeforeLast('.',fileName),"Imported database: $fileName")
        }catch(e:Exception){opened.close();target.delete();throw e}
    }

    private fun finishImportedDatabase(outcome:ImportOutcome){
        if(importCancelled){try{outcome.database.close()}catch(_:Exception){};outcome.target.delete();showImportCancelled();return}
        if(::db.isInitialized&&db.isOpen)db.close()
        db=outcome.database;dbFile=outcome.target
        registerUserDatabase(dbFile.path,outcome.label);prefs.edit().putString("active_db_path",dbFile.path).apply()
        clearResults();showPlaceholder();refreshSchemaPanel()
        val table=firstTable()
        editor.setText(if(table.isNotBlank())"SELECT * FROM \"${table.replace("\"","\"\"")}\";" else "")
        editor.setSelection(editor.length())
        showImportSuccess(outcome.status)
    }

    private fun showImportProgress(title:String,fileName:String){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(14));background=rounded(Color.rgb(20,22,29),1,Color.rgb(58,53,64),18f)}
        val titleView=TextView(this).apply{text=title;textSize=16f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD)}
        val detail=TextView(this).apply{text=fileName;textSize=12f;setTextColor(Color.rgb(145,140,151));setSingleLine(true);ellipsize=android.text.TextUtils.TruncateAt.MIDDLE;setPadding(0,dp(5),0,0)}
        val dots=LoadingDotsView(this)
        val cancel=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Cancel";isAllCaps=false;setOnClickListener{importCancelled=true;isEnabled=false;text="Cancelling…";dots.stop();detail.text="Stopping the import…"}}
        box.addView(titleView,LinearLayout.LayoutParams(-1,dp(24)))
        box.addView(detail,LinearLayout.LayoutParams(-1,dp(30)))
        box.addView(dots,LinearLayout.LayoutParams(-1,dp(42)).apply{topMargin=dp(2)})
        box.addView(cancel,LinearLayout.LayoutParams(-1,dp(40)).apply{topMargin=dp(6)})
        val dialog=Dialog(this)
        dialog.setContentView(box);dialog.setCancelable(false);dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setOnShowListener{dialog.window?.setLayout(minOf(dp(390),resources.displayMetrics.widthPixels-dp(32)),WindowManager.LayoutParams.WRAP_CONTENT)}
        importDialog=dialog;importDots=dots;importCancelButton=cancel
        dialog.show();dialog.window?.setLayout(minOf(dp(390),resources.displayMetrics.widthPixels-dp(32)),WindowManager.LayoutParams.WRAP_CONTENT)
        dots.start()
    }

    private fun showImportSuccess(message:String){
        importDots?.stop()
        val dialog=importDialog?:return
        val box=dialog.findViewById<LinearLayout>(android.R.id.content)?.getChildAt(0) as? LinearLayout ?: return
        val title=box.getChildAt(0) as? TextView;title?.text="Import complete";title?.setTextColor(green)
        val detail=box.getChildAt(1) as? TextView;detail?.text=message
        importCancelButton?.apply{isEnabled=false;visibility=View.GONE}
        val dots=importDots;dots?.showComplete()
        window.decorView.postDelayed({dialog.dismiss();clearImportDialog()},650)
    }

    private fun showImportCancelled(){
        importDots?.stop()
        val dialog=importDialog?:return
        val box=dialog.findViewById<LinearLayout>(android.R.id.content)?.getChildAt(0) as? LinearLayout ?: run{dialog.dismiss();clearImportDialog();return}
        (box.getChildAt(0) as? TextView)?.apply{text="Import cancelled";setTextColor(Color.rgb(190,185,195))}
        (box.getChildAt(1) as? TextView)?.text="No changes were made to your database library."
        importCancelButton?.apply{visibility=View.GONE}
        window.decorView.postDelayed({dialog.dismiss();clearImportDialog()},500)
    }

    private fun showImportFailure(message:String,uri:Uri,fileName:String){
        importDots?.stop()
        val dialog=importDialog?:return
        val box=dialog.findViewById<LinearLayout>(android.R.id.content)?.getChildAt(0) as? LinearLayout ?: return
        (box.getChildAt(0) as? TextView)?.apply{text="Import failed";setTextColor(red)}
        (box.getChildAt(1) as? TextView)?.apply{text=message;setSingleLine(false);maxLines=8;setTextIsSelectable(true)}
        importCancelButton?.apply{isEnabled=true;visibility=View.VISIBLE;text="Retry";setOnClickListener{dialog.dismiss();clearImportDialog();startImport(uri,fileName)}}
        importDots?.showError()
        val close=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Close";isAllCaps=false;setOnClickListener{dialog.dismiss();clearImportDialog()}}
        box.addView(close,LinearLayout.LayoutParams(-1,dp(40)).apply{topMargin=dp(5)})
    }

    private fun clearImportDialog(){importDialog=null;importDots=null;importCancelButton=null}

    private fun hasUserTables(database:SQLiteDatabase):Boolean{
        database.rawQuery("SELECT 1 FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' LIMIT 1",null).use{return it.moveToFirst()}
    }

    private fun databaseSummary(database:SQLiteDatabase):String{
        var tables=0;var columns=0;var rows=0L
        database.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'",null).use{c->
            while(c.moveToNext()){
                val n=c.getString(0);tables++
                database.rawQuery("PRAGMA table_info('"+n.replace("'","''")+"')",null).use{p->while(p.moveToNext())columns++}
                try{database.rawQuery("SELECT COUNT(*) FROM \""+n.replace("\"","\"\"")+"\"",null).use{r->if(r.moveToFirst())rows+=r.getLong(0)}}catch(_:Exception){}
            }
        }
        return "$tables tables · $columns columns · $rows rows"
    }

    private fun prepareSqlForSQLite(sql:String):Pair<String,Int>{
        var x=sql.replace("\r\n","\n").replace("\r","\n").removePrefix("\uFEFF")
        var skipped=0

        // Import parsing is deliberately batch-first. SQL Server dumps use GO and
        // IF EXISTS wrappers, while many data-only dumps contain one INSERT per line
        // without semicolons. A normal SQL splitter cannot safely handle both forms.
        val batches=splitImportBatches(x)
        val converted=mutableListOf<String>()
        for(rawBatch in batches){
            checkImportCancelled()
            var batch=stripSqlComments(rawBatch).trim()
            if(batch.isBlank())continue

            // A SQL Server IF EXISTS wrapper is procedural and must be discarded as a
            // whole GO batch. Do this before the normal splitter so ALTER/DROP lines inside
            // the IF body cannot become independent SQLite statements. Other controls such
            // as SET may share a batch with INSERTs, so they are handled after splitting.
            if(Regex("(?is)^IF\\s+(?:NOT\\s+)?EXISTS\\b").containsMatchIn(batch)){
                skipped++;continue
            }

            // One GO batch may still contain several semicolon-delimited statements, and
            // data-only dumps may contain many INSERTs without semicolons. splitSql handles
            // those line-start statement boundaries without splitting CREATE TABLE bodies.
            val statements=splitSql(batch)
            for(raw in statements){
                var statement=stripSqlComments(raw).trim()
                if(statement.isBlank())continue
                if(isImportControlBatch(statement) || isUnsupportedImportBatch(statement)){skipped++;continue}

                // A few exporters emit multiple INSERTs without semicolons in one batch.
                // splitImportBatches normally separates those, but this final guard handles
                // common INSERT-only batches without touching CREATE TABLE bodies.
                val insertParts=splitAdjacentImportInserts(statement)
                for(piece in insertParts){
                    var s=piece.trim()
                    if(s.isBlank())continue
                    if(isImportControlBatch(s) || isUnsupportedImportBatch(s)){skipped++;continue}

                    // SQL Server identifiers, MySQL backticks and schema-qualified names.
                    s=s.replace(Regex("\\[([^\\]]+)\\]"),"\"$1\"")
                    s=s.replace("`","\"")
                    s=s.replace(Regex("(?i)\"[A-Za-z_][A-Za-z0-9_]*\"\\s*\\.\\s*\"([^\"]+)\""),"\"$1\"")

                    // Unicode string prefix (SQL Server N'...'). Do not alter ordinary
                    // identifiers or quoted data.
                    s=s.replace(Regex("(?i)(?<![A-Za-z0-9_])N(?=')"),"")

                    // INSERT variants used by MySQL/SQL Server exports.
                    s=s.replace(Regex("(?i)^\\s*INSERT\\s+IGNORE\\s+INTO\\b"),"INSERT OR IGNORE INTO")
                    s=s.replace(Regex("(?i)^\\s*REPLACE\\s+INTO\\b"),"INSERT OR REPLACE INTO")
                    s=s.replace(Regex("(?is)\\s+ON\\s+DUPLICATE\\s+KEY\\s+UPDATE\\b.*$"),"")

                    // SQL Server/MySQL/PostgreSQL type normalization. These replacements
                    // are performed only outside quoted strings so data such as 'BIT' or
                    // 'datetime' is never modified.
                    val typeRules=listOf(
                        Regex("(?i)\\bNVARCHAR\\s*\\(\\s*(?:MAX|\\d+)\\s*\\)") to "TEXT",
                        Regex("(?i)\\bNCHAR\\s*\\(\\s*\\d+\\s*\\)") to "TEXT",
                        Regex("(?i)\\bVARCHAR\\s*\\(\\s*MAX\\s*\\)") to "TEXT",
                        Regex("(?i)\\b(?:TINYTEXT|MEDIUMTEXT|LONGTEXT|NTEXT)\\b") to "TEXT",
                        Regex("(?i)\\b(?:TINYBLOB|MEDIUMBLOB|LONGBLOB|IMAGE)\\b") to "BLOB",
                        Regex("(?i)\\b(?:DATETIME2?|SMALLDATETIME|TIMESTAMP WITH(?:OUT)? TIME ZONE|TIMESTAMPTZ)\\b") to "TEXT",
                        Regex("(?i)\\bUNIQUEIDENTIFIER\\b") to "TEXT",
                        Regex("(?i)\\bBIT\\b") to "INTEGER",
                        Regex("(?i)\\b(?:MONEY|SMALLMONEY)\\b") to "NUMERIC",
                        Regex("(?i)\\b(?:DECIMAL|NUMERIC)\\s*\\(\\s*\\d+\\s*,\\s*\\d+\\s*\\)") to "NUMERIC",
                        Regex("(?i)\\b(?:MEDIUMINT|BIGINT|INT8|INT4|INT2)\\b") to "INTEGER",
                        Regex("(?i)\\bTINYINT\\s*\\(\\s*1\\s*\\)") to "INTEGER",
                        Regex("(?i)\\bBIGSERIAL\\b") to "INTEGER",
                        Regex("(?i)\\bSERIAL\\b") to "INTEGER",
                        Regex("(?i)\\s+UNSIGNED\\b") to "",
                        Regex("(?i)\\s+IDENTITY(?:\\s*\\(\\s*\\d+\\s*,\\s*\\d+\\s*\\))?") to " AUTOINCREMENT",
                        Regex("(?i)\\s+AUTO_INCREMENT\\b") to " AUTOINCREMENT",
                        Regex("(?i)\\s+CLUSTERED\\b|\\s+NONCLUSTERED\\b") to "",
                        Regex("(?i)\\s+WITH\\s*\\([^)]*\\)") to "",
                        Regex("(?i)\\s+DEFAULT\\s+GETDATE\\s*\\(\\s*\\)") to " DEFAULT CURRENT_TIMESTAMP",
                        Regex("(?i)\\bGETDATE\\s*\\(\\s*\\)") to "CURRENT_TIMESTAMP",
                        Regex("(?i)\\bSYSDATETIME(?:\\s*\\(\\s*\\))?") to "CURRENT_TIMESTAMP",
                        Regex("(?i)\\s+DEFAULT\\s+SYSDATETIME(?:\\s*\\(\\s*\\))?") to " DEFAULT CURRENT_TIMESTAMP",
                        Regex("(?i)\\s+DEFAULT\\s+NEWID\\s*\\(\\s*\\)") to "",
                        Regex("(?i)\\s+DEFAULT\\s+UUID\\s*\\(\\s*\\)") to "",
                        Regex("(?i)\\s+COLLATE\\s+[A-Za-z0-9_]+") to "",
                        Regex("(?i)\\s+CHARACTER\\s+SET\\s+[A-Za-z0-9_]+") to "",
                        Regex("(?i)\\s+CHARSET\\s*=\\s*[A-Za-z0-9_]+") to "",
                        Regex("(?i)\\s+ENGINE\\s*=\\s*[A-Za-z0-9_]+") to ""
                    )
                    for((rule,replacement) in typeRules)s=replaceImportOutsideQuotes(s,rule,replacement)

                    // MySQL table options that may occur after CREATE TABLE (...).
                    s=replaceImportOutsideQuotes(s,Regex("(?is)\\)\\s*(?:ENGINE\\s*=.*|DEFAULT\\s+CHARSET\\s*=.*|CHARSET\\s*=.*)$"),")")

                    // Vendor-specific quoting of the table/schema is now normalized.
                    if(s.startsWith("CREATE TABLE",true)) s=convertCreateTableForSQLite(s)

                    // SQLite has no TRUNCATE TABLE statement.
                    s=s.replace(Regex("(?i)^\\s*TRUNCATE\\s+TABLE\\s+(.+)$"),"DELETE FROM $1")
                    if(s.isNotBlank())converted.add(s.trim())
                }
            }
        }
        return converted.joinToString(";\n") to skipped
    }

    private fun splitImportBatches(sql:String):List<String>{
        val out=mutableListOf<String>();var start=0;var q:Char?=null;var lineStart=true;var i=0
        while(i<sql.length){
            val c=sql[i]
            if((c=='\''||c=='"') && (i==0||sql[i-1]!='\\'))q=if(q==c)null else if(q==null)c else q
            if(q==null&&lineStart){
                val end=sql.indexOf('\n',i).let{if(it<0)sql.length else it}
                val trimmed=sql.substring(i,end).trim()
                if(Regex("(?i)^GO(?:\\s+\\d+)?$").matches(trimmed)){
                    val part=sql.substring(start,i).trim();if(part.isNotBlank())out.add(part)
                    start=if(end<sql.length)end+1 else end;i=start;lineStart=true;continue
                }
            }
            lineStart=c=='\n';i++
        }
        val tail=sql.substring(start).trim();if(tail.isNotBlank())out.add(tail)
        return out
    }

    private fun splitAdjacentImportInserts(s:String):List<String>{
        if(!Regex("(?is)^\\s*INSERT\\b").containsMatchIn(s))return listOf(s)
        val starts=Regex("(?im)^\\s*(?:INSERT|REPLACE)\\b").findAll(s).map{it.range.first}.toList()
        if(starts.size<=1)return listOf(s)
        val out=mutableListOf<String>()
        for(i in starts.indices){val a=starts[i];val b=if(i+1<starts.size)starts[i+1] else s.length;val part=s.substring(a,b).trim();if(part.isNotBlank())out.add(part)}
        return out
    }

    private fun isImportControlBatch(statement:String):Boolean{
        val t=stripSqlComments(statement).trimStart()
        return Regex("(?is)^(?:SET\\b|USE\\b|GO\\b|DELIMITER\\b|LOCK\\s+TABLES\\b|UNLOCK\\s+TABLES\\b|CREATE\\s+DATABASE\\b|DROP\\s+DATABASE\\b|CREATE\\s+SCHEMA\\b|DROP\\s+SCHEMA\\b|BEGIN\\s*(?:TRANSACTION)?\\b|START\\s+TRANSACTION\\b|COMMIT\\b|ROLLBACK\\b)").containsMatchIn(t)
    }

    private fun isUnsupportedImportBatch(statement:String):Boolean{
        val t=stripSqlComments(statement).trimStart()
        return Regex("(?is)^(?:IF\\s+(?:NOT\\s+)?EXISTS\\b|CREATE\\s+(?:UNIQUE\\s+)?(?:CLUSTERED\\s+|NONCLUSTERED\\s+)?INDEX\\b|DROP\\s+INDEX\\b|DROP\\s+TABLE\\b|ALTER\\s+TABLE\\b.*\\b(?:ADD|DROP)\\s+(?:CONSTRAINT|FOREIGN\\s+KEY|PRIMARY\\s+KEY)\\b|CREATE\\s+(?:OR\\s+REPLACE\\s+)?(?:TRIGGER|PROCEDURE|FUNCTION|EVENT|TYPE|SEQUENCE)\\b|DROP\\s+(?:TRIGGER|PROCEDURE|FUNCTION|EVENT|TYPE|SEQUENCE)\\b|CREATE\\s+(?:MATERIALIZED\\s+)?VIEW\\b|DROP\\s+VIEW\\b|GRANT\\b|REVOKE\\b)").containsMatchIn(t)
    }

    private fun replaceImportOutsideQuotes(input:String, regex:Regex, replacement:String):String{
        val out=StringBuilder();var i=0;var lastOutside=0
        while(i<input.length){
            val c=input[i]
            if(c=='\''||c=='"'){
                if(i>lastOutside)out.append(regex.replace(input.substring(lastOutside,i),replacement))
                val quote=c;var j=i+1
                while(j<input.length){
                    if(input[j]==quote){
                        if(j+1<input.length&&input[j+1]==quote){j+=2;continue}
                        j++;break
                    }
                    j++
                }
                out.append(input.substring(i,j));i=j;lastOutside=i;continue
            }
            i++
        }
        if(lastOutside<input.length)out.append(regex.replace(input.substring(lastOutside),replacement))
        return out.toString()
    }

    private fun convertCreateTableForSQLite(statement:String):String{
        val open=statement.indexOf('(');val close=statement.lastIndexOf(')')
        if(open<0||close<=open)return statement
        val head=statement.substring(0,open).trimEnd();val body=statement.substring(open+1,close)
        val parts=splitTopLevelComma(body);val primaryColumns=mutableListOf<String>();val rewritten=mutableListOf<String>()
        for(raw in parts){
            var part=raw.trim();if(part.isBlank())continue
            val pk=Regex("(?is)^\\s*(?:CONSTRAINT\\s+(?:[\"']?[^\"'\\s]+[\"']?)\\s+)?PRIMARY\\s+KEY\\s*(?:CLUSTERED\\s*)?\\(([^)]+)\\)\\s*$").find(part)
            if(pk!=null){primaryColumns.addAll(pk.groupValues[1].split(',').map{it.trim().split(Regex("\\s+"))[0].trim('\"','\'', '[', ']')});continue}
            if(Regex("(?is)^\\s*(?:CONSTRAINT\\s+[^\\s]+\\s+)?(?:FOREIGN\\s+KEY|CHECK\\b)").containsMatchIn(part))continue
            part=Regex("(?is)^\\s*CONSTRAINT\\s+[^\\s]+\\s+").replace(part,"")
            val col=Regex("(?is)^\\s*[\"']?([A-Za-z_][A-Za-z0-9_ ]*)[\"']?\\s+(.+)$").find(part)
            if(col!=null&&Regex("(?i)\\bAUTOINCREMENT\\b").containsMatchIn(part)){
                val name=col.groupValues[1].trim();part="\"${name.replace("\"","\"\"")}\" INTEGER PRIMARY KEY AUTOINCREMENT"
            }else{
                part=part.replace(Regex("(?i)\\bAUTOINCREMENT\\b"),"")
            }
            rewritten.add(part)
        }
        if(primaryColumns.size==1){
            val pkName=primaryColumns[0];val idx=rewritten.indexOfFirst{Regex("(?is)^\\s*[\"']?${Regex.escape(pkName)}[\"']?\\s+").containsMatchIn(it)}
            if(idx>=0&&!Regex("(?i)\\bPRIMARY\\s+KEY\\b").containsMatchIn(rewritten[idx]))rewritten[idx]="\"${pkName.replace("\"","\"\"")}\" INTEGER PRIMARY KEY"
        }else if(primaryColumns.size>1){rewritten.add("PRIMARY KEY (${primaryColumns.joinToString(",") {"\"${it.replace("\"","\"\"")}\""}})")}
        return "$head (\n${rewritten.joinToString(",\n")}\n)"
    }

    private fun splitTopLevelComma(s:String):List<String>{
        val out=mutableListOf<String>();var start=0;var depth=0;var q:Char?=null;var i=0
        while(i<s.length){
            val c=s[i]
            if((c=='\''||c=='"') && (i==0||s[i-1]!='\\')) q=if(q==c)null else if(q==null)c else q
            if(q==null){
                if(c=='(') depth++
                else if(c==')') depth--
                else if(c==','&&depth==0){out.add(s.substring(start,i));start=i+1}
            }
            i++
        }
        if(start<s.length)out.add(s.substring(start))
        return out
    }

    private fun shouldSkipImportStatement(statement:String):Boolean{
        val t=stripSqlComments(statement).trimStart()
        return Regex("""(?is)^(?:IF\s+(?:NOT\s+)?EXISTS\b|CREATE\s+(?:UNIQUE\s+)?(?:CLUSTERED\s+|NONCLUSTERED\s+)?INDEX\b|DROP\s+INDEX\b|DROP\s+TABLE\b|ALTER\s+TABLE\s+.+\s+(?:ADD|DROP)\s+CONSTRAINT\b|CREATE\s+TRIGGER\b|DROP\s+TRIGGER\b)""").containsMatchIn(t)
    }

    private fun stripSqlComments(s:String):String{
        var x=Regex("(?s)/\\*.*?\\*/").replace(s,"")
        x=Regex("(?m)^\\s*--.*$").replace(x,"")
        return x.trim()
    }

    private data class ImportInsert(val table:String,val columns:List<String>,val values:List<String>)

    private fun parseImportInsert(statement:String):ImportInsert?{
        val m=Regex("(?is)^\\s*INSERT\\s+(?:OR\\s+IGNORE\\s+)?INTO\\s+([\\\"A-Za-z_][^\\s(]*)\\s*\\((.*?)\\)\\s*VALUES\\s*\\((.*)\\)\\s*$").find(statement.trim()) ?: return null
        val table=m.groupValues[1].trim().trim('"','`','[',']')
        val cols=splitTopLevelComma(m.groupValues[2]).map{it.trim().trim('"','`','[',']')}
        val vals=splitTopLevelComma(m.groupValues[3]).map{it.trim()}
        if(table.isBlank()||cols.isEmpty()||cols.size!=vals.size)return null
        return ImportInsert(table,cols,vals)
    }

    private fun inferImportType(values:List<String>):String{
        var sawText=false;var sawReal=false;var sawInteger=false
        for(raw in values){
            val v=raw.trim()
            if(v.equals("NULL",true))continue
            if(v.startsWith("'")&&v.endsWith("'")){sawText=true;continue}
            if(v.matches(Regex("[-+]?\\d+"))){sawInteger=true;continue}
            if(v.matches(Regex("[-+]?(?:\\d+\\.\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?"))){sawReal=true;continue}
            sawText=true
        }
        return when{ sawText->"TEXT"; sawReal->"NUMERIC"; sawInteger->"INTEGER"; else->"TEXT" }
    }

    private fun createTablesForDataOnlyImport(database:SQLiteDatabase, statements:List<String>):Int{
        val grouped=linkedMapOf<String,MutableList<ImportInsert>>()
        for(statement in statements){
            checkImportCancelled()
            val parsed=parseImportInsert(statement) ?: continue
            grouped.getOrPut(parsed.table){mutableListOf()}.add(parsed)
        }
        var created=0
        for((table,rows) in grouped){
            checkImportCancelled()
            if(database.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=? LIMIT 1",arrayOf(table)).use{it.moveToFirst()})continue
            val orderedColumns=linkedSetOf<String>()
            for(row in rows)orderedColumns.addAll(row.columns)
            val typeByColumn=linkedMapOf<String,String>()
            for(column in orderedColumns){
                val values=rows.flatMap{row->
                    val idx=row.columns.indexOfFirst{it.equals(column,true)}
                    if(idx>=0)listOf(row.values[idx]) else emptyList()
                }
                typeByColumn[column]=inferImportType(values)
            }
            val idColumn=orderedColumns.firstOrNull{it.equals("id",true)}
            val defs=orderedColumns.joinToString(", ") { column ->
                val name="\"${column.replace("\"","\"\"")}\""
                val pk=if(idColumn!=null&&column.equals(idColumn,true)&&typeByColumn[column]=="INTEGER")" PRIMARY KEY" else ""
                "$name ${typeByColumn[column]}$pk"
            }
            if(defs.isBlank())continue
            database.execSQL("CREATE TABLE \"${table.replace("\"","\"\"")}\" ($defs)")
            created++
        }
        return created
    }

    private fun importSqlScript(sql:String,fileName:String="SQL script"):ImportOutcome{
        if(sql.isBlank())throw Exception("$fileName is empty")
        checkImportCancelled()
        val prepared=prepareSqlForSQLite(sql)
        checkImportCancelled()
        val target=File(filesDir,"Imported_${System.currentTimeMillis()}_${fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")}.db")
        var fresh:SQLiteDatabase?=null
        var count=0
        var statementNumber=0
        var skippedImportStatements=0
        try{
            fresh=SQLiteDatabase.openOrCreateDatabase(target,null)
            fresh.beginTransaction()
            val statements=splitSql(prepared.first).map{stripSqlComments(it).trim()}.filter{it.isNotBlank()}
            val hasCreate=statements.any{Regex("(?is)^CREATE\\s+TABLE\\b").containsMatchIn(it)}
            val hasInsert=statements.any{Regex("(?is)^INSERT\\s+(?:OR\\s+IGNORE\\s+)?INTO\\b").containsMatchIn(it)}
            if(!hasCreate&&hasInsert){checkImportCancelled();createTablesForDataOnlyImport(fresh,statements)}
            for(raw in statements){
                checkImportCancelled()
                val statement=stripLineComments(raw).trim()
                if(statement.isBlank()||isQueryStatement(statement))continue
                if(shouldSkipImportStatement(statement)){skippedImportStatements++;continue}
                statementNumber++
                fresh.execSQL(statement)
                count++
            }
            checkImportCancelled()
            fresh.setTransactionSuccessful();fresh.endTransaction()
            if(!hasUserTables(fresh))throw Exception("No user tables were created")
            val totalSkipped=prepared.second+skippedImportStatements
            val suffix=if(totalSkipped>0)" · skipped $totalSkipped unsupported/dump-control statement(s)" else ""
            return ImportOutcome(fresh,target,fileName.substringBeforeLast('.',fileName),"Imported $fileName · ${databaseSummary(fresh)} · $count statement(s)$suffix").also{fresh=null}
        }catch(e:Exception){
            try{fresh?.endTransaction()}catch(_:Exception){}
            try{fresh?.close()}catch(_:Exception){}
            target.delete()
            if(e is ImportCancelledException)throw e
            throw Exception("Import failed at statement $statementNumber: ${e.message?:"SQL error"}")
        }
    }

    private fun isQueryStatement(s:String)=s.trimStart().let{it.startsWith("SELECT",true)||it.startsWith("WITH",true)||it.startsWith("PRAGMA",true)||it.startsWith("EXPLAIN",true)}
    private fun leadingKeyword(s:String)=Regex("^\\s*([A-Za-z]+)").find(s)?.groupValues?.get(1)?.uppercase(Locale.US)?: "SQL"
    private fun splitSql(s:String):List<String>{
        val out=mutableListOf<String>();var start=0;var q:Char?=null;var lineStart=true;var i=0
        while(i<s.length){
            val c=s[i]
            if((c=='\''||c=='"')&&(i==0||s[i-1]!='\\'))q=if(q==c)null else if(q==null)c else q
            if(q==null){
                if(c==';'){
                    val part=s.substring(start,i).trim();if(part.isNotEmpty())out.add(part)
                    start=i+1;lineStart=true;i++;continue
                }
                if(lineStart){
                    val end=s.indexOf('\n',i).let{if(it<0)s.length else it}
                    val trimmed=s.substring(i,end).trimStart()
                    val isGo=Regex("(?i)^GO(?:\\s+\\d+)?\\s*$").matches(trimmed)
                    val startsStatement=Regex("(?i)^(?:SET\\b|INSERT\\b|CREATE\\b|ALTER\\b|DROP(?!\\s+CONSTRAINT\\b)\\b|UPDATE\\b|DELETE\\b|MERGE\\b|IF\\s+(?:NOT\\s+)?EXISTS\\b)").containsMatchIn(trimmed)
                    if(isGo){
                        val part=s.substring(start,i).trim();if(part.isNotEmpty())out.add(part)
                        start=if(end<s.length)end+1 else end;i=start;lineStart=true;continue
                    }
                    if(i>start && startsStatement && s.substring(start,i).trim().isNotEmpty()){
                        out.add(s.substring(start,i).trim());start=i
                    }
                }
            }
            lineStart=c=='\n';i++
        }
        val tail=s.substring(start).trim();if(tail.isNotEmpty())out.add(tail);return out
    }
    private fun stripLineComments(s:String):String{val sb=StringBuilder();var q:Char?=null;var i=0;while(i<s.length){val c=s[i];if((c=='\''||c=='\"')&&(i==0||s[i-1]!='\\'))q=if(q==c)null else if(q==null)c else q;if(q==null&&c=='-'&&i+1<s.length&&s[i+1]=='-'){while(i<s.length&&s[i]!='\n')i++;continue};if(q==null&&c=='#'&&(i==0||s[i-1]=='\n')){while(i<s.length&&s[i]!='\n')i++;continue};sb.append(c);i++};return sb.toString()}

    private fun runSelectedOrAll(){val a=editor.selectionStart;val z=editor.selectionEnd;val selected=if(a!=z)editor.text.substring(minOf(a,z),maxOf(a,z)).trim() else "";val source=if(selected.isNotEmpty())selected else editor.text.toString();val statements=splitSql(source).filter{stripLineComments(it).isNotBlank()};if(statements.isEmpty()){showError("Nothing to run");return};var ok=0;var err=0;var schemaChanged=false
        for((idx,s) in statements.withIndex()){val label=leadingKeyword(s)+" "+(idx+1)+(if(selected.isNotEmpty())" · selected" else "");val started=System.nanoTime();try{if(isQueryStatement(s)){if(s.trimStart().startsWith("EXPLAIN QUERY PLAN",true)){val rows=planRows(s);addResultTab("Plan ${idx+1}",buildPlanView(rows),false,rows.map{listOf(it.first.toString(),it.second.toString(),it.third)} ,"Plan ${idx+1}")}else{db.rawQuery(s,null).use{c->val built=buildTableView(c);addResultTab("${leadingKeyword(s)} ${idx+1} · ${built.second} rows",built.first,false,built.third,"${leadingKeyword(s)} ${idx+1}")}}}else{db.execSQL(s);if(label.startsWith("CREATE",true)||label.startsWith("DROP",true)||label.startsWith("ALTER",true))schemaChanged=true;val changed=db.rawQuery("SELECT changes()",null).use{c->c.moveToFirst();c.getInt(0)};addResultTab("${leadingKeyword(s)} ${idx+1} · ${changed} changed",buildMessageView("✓ OK — $changed row(s) affected

Execution: ${elapsed(started)} ms"),false,null,"${leadingKeyword(s)} ${idx+1}")};ok++;history.add(0,s.trim());trimHistory()}catch(e:Exception){addResultTab("${leadingKeyword(s)} ${idx+1} · Error",buildMessageView("✕ ${e.message?:"SQL error"}\n\nExecution: ${elapsed(started)} ms\n\nTap Explain Error for a hint."),true,null,"${leadingKeyword(s)} ${idx+1}");err++}}
        while(tabs.size>30) removeResultTab(0); if(tabs.isNotEmpty())selectTab(tabs.lastIndex) else showPlaceholder();savePrefs();status.text=if(err==0)"✓ Ran $ok statement(s)"+if(selected.isNotEmpty())" • selected only" else "" else "✕ $err of ${statements.size} statement(s) failed";status.setTextColor(if(err==0)green else red);if(schemaChanged)refreshSchemaPanel() }
    private fun elapsed(s:Long)=((System.nanoTime()-s)/1_000_000L).toString(); private fun trimHistory(){while(history.size>30)history.removeAt(history.lastIndex)}

    private fun buildTableView(c:Cursor):Triple<View,Int,List<List<String>>>{
        val data=mutableListOf<List<String>>()
        val headers=(0 until c.columnCount).map{c.getColumnName(it)}; data.add(headers)
        while(c.moveToNext()) data.add((0 until c.columnCount).map{if(c.isNull(it) ) "NULL" else c.getString(it)})
        return Triple(buildGrid(data), data.size-1, data)
    }
    private fun buildGrid(data:List<List<String>>):View{
        val table=TableLayout(this); if(data.isEmpty()) return table
        val header=TableRow(this)
        for(i in data[0].indices){val h=cell(data[0][i],true){sortActiveResult(i)};header.addView(h)};table.addView(header)
        for(rowIndex in 1 until min(data.size,1001)){val r=TableRow(this);for(v in data[rowIndex])r.addView(cell(v,false){copyText(v)});table.addView(r)}
        if(data.size==1){val t=TextView(this);t.text="(0 rows)";t.setPadding(16,16,16,16);table.addView(t)} else if(data.size>1001){val t=TextView(this);t.text="… showing first 1000 of ${data.size-1} rows";t.setPadding(16,10,16,10);table.addView(t)}
        val hs=HorizontalScrollView(this);hs.addView(table);val vs=ScrollView(this);vs.isFillViewport=true;vs.addView(hs);return vs
    }
    private fun cell(v:String,head:Boolean,onClick:()->Unit):TextView{val t=TextView(this);t.text=v;t.textSize=12f;t.setTextColor(if(head)Color.rgb(185,181,191)else white);t.setPadding(16,12,16,12);t.setBackgroundColor(if(head) Color.rgb(28,31,39) else Color.rgb(24,26,33));if(head)t.setOnClickListener{onClick()} else t.setOnLongClickListener{onClick();true};return t}
    private fun sortActiveResult(column:Int){if(activeTab<0||tabs[activeTab].csv==null)return;val old=tabs[activeTab].csv!!;if(old.size<2)return;val ascending=!(tabs[activeTab].button.tag as? Boolean ?: false);val sorted=old.drop(1).sortedWith(Comparator<List<String>>{a,b->compareCells(a.getOrElse(column){""},b.getOrElse(column){""})}).let{if(ascending)it else it.reversed()};val data=listOf(old[0])+sorted;tabs[activeTab].button.tag=ascending;tabs[activeTab].button.text=tabs[activeTab].title+" · sort ${if(ascending)"↑" else "↓"}";tabs[activeTab]=tabs[activeTab].copy(view=buildGrid(data),csv=data);selectTab(activeTab)}
    private fun compareCells(a:String,b:String):Int{val da=a.toDoubleOrNull();val db=b.toDoubleOrNull();return if(da!=null&&db!=null)da.compareTo(db) else a.compareTo(b,true)}
    private fun copyText(v:String){(getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("SQL cell",v));Toast.makeText(this,"Cell copied",Toast.LENGTH_SHORT).show()}

    private fun addResultTab(label:String,content:View,isError:Boolean,csv:List<List<String>>?,title:String){
        val wrap=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val btn=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{
            text=label;isAllCaps=false;minHeight=0;minWidth=0;setPadding(12,0,12,0);textSize=11.5f
            maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END;gravity=Gravity.CENTER_VERTICAL;stateListAnimator=null
            contentDescription=label
        }
        val close=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{
            text="×";isAllCaps=false;minHeight=0;minWidth=0;setPadding(0,0,0,0);textSize=15f
            gravity=Gravity.CENTER;contentDescription="Close $label";stateListAnimator=null
        }
        val tabLp=LinearLayout.LayoutParams(-2,38).apply{width=dp(180)}
        val closeLp=LinearLayout.LayoutParams(dp(30),dp(30)).apply{marginStart=dp(4)}
        wrap.addView(btn,tabLp);wrap.addView(close,closeLp)
        val lp=LinearLayout.LayoutParams(-2,38).apply{marginEnd=dp(8);gravity=Gravity.CENTER_VERTICAL}
        wrap.layoutParams=lp;tabStrip.addView(wrap)
        val tab=ResultTab(btn,close,wrap,content,isError,csv,title);tabs.add(tab)
        btn.setOnClickListener{selectTab(tabs.indexOf(tab))};close.setOnClickListener{removeResultTab(tabs.indexOf(tab))}
    }

    private fun removeResultTab(index:Int){
        if(index<0||index>=tabs.size)return
        val wasActive=index==activeTab
        tabStrip.removeView(tabs[index].container);tabs.removeAt(index)
        activeTab=when{tabs.isEmpty()->-1;wasActive->minOf(index,tabs.lastIndex);index<activeTab->activeTab-1;else->activeTab}
        if(activeTab>=0)selectTab(activeTab) else showPlaceholder()
    }

    private fun selectTab(i:Int){
        if(i<0||i>=tabs.size)return
        activeTab=i;resultContainer.removeAllViews();resultContainer.addView(tabs[i].view)
        for((j,t) in tabs.withIndex()){
            val selected=j==i
            t.button.setBackgroundResource(if(selected)R.drawable.button_accent else R.drawable.button_flat)
            t.button.setTextColor(if(selected)Color.WHITE else if(t.isError)red else Color.rgb(185,181,191))
            t.closeButton.setBackgroundResource(if(selected)R.drawable.button_accent else R.drawable.button_flat)
            t.closeButton.setTextColor(if(selected)Color.WHITE else if(t.isError)red else Color.rgb(185,181,191))
        }
    }

    private fun clearResults(){tabStrip.removeAllViews();resultContainer.removeAllViews();tabs.clear();activeTab=-1}
    private fun setupResizeHandle(){
        val handle=resizeHandle
        handle.setOnTouchListener(object:View.OnTouchListener{
            private var startY=0f
            private var startEditor=0
            private var startResults=0
            private var dragging=false
            override fun onTouch(v:View,event:MotionEvent):Boolean{
                when(event.actionMasked){
                    MotionEvent.ACTION_DOWN->{
                        startY=event.rawY
                        startEditor=editorSurface.height
                        startResults=resultArea.height
                        dragging=true
                        v.parent.requestDisallowInterceptTouchEvent(true)
                        v.alpha=1f
                        return true
                    }
                    MotionEvent.ACTION_MOVE->{
                        if(!dragging)return true
                        val total=(startEditor+startResults).coerceAtLeast(1)
                        val delta=(event.rawY-startY).toInt()
                        val minEditor=dp(120)
                        val minResults=dp(150)
                        val newEditor=(startEditor+delta).coerceIn(minEditor,(total-minResults).coerceAtLeast(minEditor))
                        val newResults=total-newEditor
                        (editorSurface.layoutParams as? LinearLayout.LayoutParams)?.let{lp->lp.height=newEditor;lp.weight=0f;editorSurface.layoutParams=lp}
                        (resultArea.layoutParams as? LinearLayout.LayoutParams)?.let{lp->lp.height=newResults;lp.weight=0f;resultArea.layoutParams=lp}
                        editorSurface.requestLayout();resultArea.requestLayout()
                        return true
                    }
                    MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{
                        dragging=false
                        v.parent.requestDisallowInterceptTouchEvent(false)
                        return true
                    }
                }
                return true
            }
        })
    }

    private fun setupWindowDots(){
        findViewById<View>(R.id.windowDot1)?.apply{contentDescription="Toggle database sidebar";setOnClickListener{if(sidebarPanel!=null)toggleSidebar() else showSchema()}}
        findViewById<View>(R.id.windowDot2)?.apply{contentDescription="Toggle SQL focus mode";setOnClickListener{toggleFocusMode()}}
        findViewById<View>(R.id.windowDot3)?.apply{contentDescription="Open command palette";setOnClickListener{showCommandPalette()}}
        updateDotStates()
    }

    private fun showCommandPalette(){
        val anchor=findViewById<View>(R.id.windowDot3) ?: return
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(8),dp(8),dp(8));background=rounded(Color.rgb(20,22,29),1,Color.rgb(58,53,64),16f)}
        val search=EditText(this).apply{hint="Search commands";hintTextColor=Color.rgb(105,108,119);setTextColor(white);textSize=13f;singleLine=true;setPadding(dp(12),0,dp(12),0);background=rounded(Color.rgb(28,30,38),1,Color.rgb(54,56,66),10f)}
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(6),0,0)}
        root.addView(search,LinearLayout.LayoutParams(-1,dp(42)))
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_NEVER;addView(list)}
        root.addView(scroll,LinearLayout.LayoutParams(-1,dp(0),1f))
        var popup:PopupWindow?=null
        val commands=listOf(
            "Database Explorer" to {showSchema()},
            "Query History" to {showHistory()},
            "Snippets" to {showSnippetMenu()},
            "Practice" to {showPractice()},
            "Check Query" to {checkPractice()},
            "Format SQL" to {editor.setText(formatSql(editor.text.toString()));editor.setSelection(editor.length())},
            "Clear Editor" to {editor.setText("")},
            "Export Database" to {exportDatabase()}
        )
        fun render(filter:String){
            list.removeAllViews()
            commands.filter{it.first.contains(filter.trim(),true)}.forEachIndexed{index,pair->
                val row=TextView(this).apply{text=pair.first;textSize=13f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(12),0);background=rounded(Color.rgb(28,30,38),0,Color.TRANSPARENT,10f);isClickable=true;setOnClickListener{popup?.dismiss();pair.second()}}
                list.addView(row,LinearLayout.LayoutParams(-1,dp(42)).apply{if(index>0)topMargin=dp(4)})
            }
            if(list.childCount==0)list.addView(TextView(this).apply{text="No matching commands";textSize=12f;setTextColor(Color.rgb(125,128,139));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(12),0)},LinearLayout.LayoutParams(-1,dp(42)))
        }
        popup=PopupWindow(root,minOf(dp(330),resources.displayMetrics.widthPixels-dp(24)),dp(360),true)
        popup!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));popup!!.isOutsideTouchable=true;popup!!.elevation=dp(14).toFloat();popup!!.inputMethodMode=PopupWindow.INPUT_METHOD_NEEDED
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render(s?.toString().orEmpty())};override fun afterTextChanged(e:Editable?){} })
        render("")
        val loc=IntArray(2);anchor.getLocationOnScreen(loc);val width=minOf(dp(330),resources.displayMetrics.widthPixels-dp(24));val x=(resources.displayMetrics.widthPixels-width-dp(12)).coerceAtLeast(dp(12));val y=loc[1]+anchor.height+dp(8)
        popup!!.showAtLocation(anchor,Gravity.TOP or Gravity.START,x,y)
        search.requestFocus()
        search.postDelayed({(getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)?.showSoftInput(search,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)},120)
    }

    private fun toggleSidebar(){
        val panel=sidebarPanel ?: return
        sidebarOpen=!sidebarOpen
        if(sidebarOpen){
            panel.visibility=View.VISIBLE;panel.alpha=0f;panel.translationX=-dp(18).toFloat();panel.animate().alpha(1f).translationX(0f).setDuration(180).start()
        }else{
            panel.animate().alpha(0f).translationX(-dp(18).toFloat()).setDuration(160).withEndAction{panel.visibility=View.GONE}.start()
        }
        sidebarDivider?.visibility=View.VISIBLE
        updateDotStates()
    }

    private fun toggleFocusMode(){
        focusMode=!focusMode
        val ids=listOf(R.id.workspaceLabel,R.id.workspaceHint)
        ids.forEach{id->findViewById<View>(id)?.visibility=if(focusMode)View.GONE else View.VISIBLE}
        if(sidebarPanel!=null){
            if(focusMode){focusSidebarWasOpen=sidebarOpen;if(sidebarOpen)toggleSidebar()}
            else if(focusSidebarWasOpen&&!sidebarOpen)toggleSidebar()
        }
        updateDotStates()
        showWindowToast(if(focusMode)"Focus mode on" else "Focus mode off")
    }

    private fun updateDotStates(){
        findViewById<View>(R.id.windowDot1)?.alpha=if(sidebarOpen||sidebarPanel==null)1f else .55f
        findViewById<View>(R.id.windowDot2)?.alpha=if(focusMode)1f else .72f
        findViewById<View>(R.id.windowDot3)?.alpha=.82f
    }

    private fun showWindowToast(text:String){Toast.makeText(this,text,Toast.LENGTH_SHORT).show()}

    private fun showPlaceholder(){val t=TextView(this);t.text="Run a query to see results here";t.setTextColor(Color.rgb(104,108,120));t.textSize=13f;t.gravity=Gravity.CENTER;resultContainer.removeAllViews();resultContainer.addView(t)}
    private fun buildMessageView(msg:String):View{val t=TextView(this);t.text=msg;t.textSize=13f;t.setTextColor(Color.rgb(185,181,191));t.setPadding(20,20,20,20);val s=ScrollView(this);s.addView(t);return s}

    private fun schemaText():String{val b=StringBuilder();db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->if(!c.moveToFirst())b.append("No tables yet.\nImport a .db or .sql file,\nor run a CREATE TABLE.")else{do{val n=c.getString(0);b.append(n).append("  ");try{db.rawQuery("SELECT COUNT(*) FROM \""+n.replace("\"","\"\"")+"\"",null).use{r->if(r.moveToFirst())b.append("(").append(r.getLong(0)).append(" rows)")}}catch(_:Exception){};b.append("\n");db.rawQuery("PRAGMA table_info('"+n.replace("'","''")+"')",null).use{p->while(p.moveToNext())b.append("   ").append(p.getString(1)).append("  ").append(p.getString(2).ifBlank{"ANY"}).append("\n")};b.append("\n")}while(c.moveToNext())}};return b.toString().trimEnd()}

    private fun interactiveSchemaView():View{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(6),dp(4),dp(6),dp(10))}
        addDatabaseLibrary(root)
        val divider=View(this).apply{setBackgroundColor(Color.rgb(42,44,53))}
        root.addView(divider,LinearLayout.LayoutParams(-1,dp(1)).apply{topMargin=dp(8);bottomMargin=dp(4)})
        addTreeSection(root,"TABLES","table",true)
        addTreeSection(root,"VIEWS","view",false)
        addTreeSection(root,"INDEXES","index",false)
        return root
    }

    private fun addDatabaseLibrary(root:LinearLayout){
        val sampleLabel=TextView(this).apply{text="SAMPLES";textSize=9f;letterSpacing=.14f;setTextColor(Color.rgb(112,116,129));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(8),dp(6),dp(8),dp(5))}
        root.addView(sampleLabel)
        addDatabaseRow(root,"Parks & Recreation",ensureSamplePath("Parks & Recreation"),true)
        val users=userDatabasePaths()
        if(users.isNotEmpty()){
            root.addView(TextView(this).apply{text="MY DATABASES";textSize=9f;letterSpacing=.14f;setTextColor(Color.rgb(112,116,129));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(8),dp(12),dp(8),dp(5))})
            users.forEach{path->addDatabaseRow(root,databaseLabel(path),path,false)}
        }
    }

    private fun ensureSamplePath(label:String):String{
        val asset=if(label=="Northwind")"Northwind.db" else "Parks_and_Recreation.db"
        val f=File(filesDir,"Sample_${asset.replace(Regex("[^A-Za-z0-9._-]"),"_")}")
        if(!f.exists())assets.open(asset).use{i->f.outputStream().use{o->i.copyTo(o)}}
        return f.path
    }

    private fun addDatabaseRow(parent:LinearLayout,label:String,path:String,sample:Boolean){
        val active=File(path).absolutePath==dbFile.absolutePath
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(44);setPadding(dp(10),0,dp(6),0);background=rounded(if(active)Color.rgb(43,34,42) else Color.TRANSPARENT,if(active)1 else 0,if(active)Color.rgb(95,67,86) else Color.TRANSPARENT,10f);isClickable=true;contentDescription=if(active)"Selected database $label" else "Select database $label"}
        val icon=TextView(this).apply{text=if(sample)"✿" else "●";textSize=11f;setTextColor(if(active)blue else Color.rgb(145,141,154));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(24),dp(40))}
        val nameView=TextView(this).apply{this.text=label;textSize=12f;setTextColor(if(active)white else Color.rgb(196,192,202));setTypeface(null,if(active)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(40),1f)}
        val meta=TextView(this).apply{this.text=if(File(path).exists())databaseSummarySafe(path) else "";textSize=9f;setTextColor(Color.rgb(118,122,134));gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(-2,dp(40))}
        row.addView(icon);row.addView(nameView);row.addView(meta)
        row.setOnClickListener{
            if(active && !sample){showDatabaseActions(label,path);return@setOnClickListener}
            try{
                if(!File(path).exists() && sample){copyBundledDatabase(if(label=="Northwind")"Northwind.db" else "Parks_and_Recreation.db")}
                activateDatabase(path,label)
            }catch(e:Exception){showError("Could not open $label: ${e.message?:"database error"}")}
        }
        parent.addView(row,LinearLayout.LayoutParams(-1,dp(44)).apply{bottomMargin=dp(3)})
    }

    private fun databaseSummarySafe(path:String):String=try{val d=SQLiteDatabase.openDatabase(path,null,SQLiteDatabase.OPEN_READONLY);val r=databaseSummary(d);d.close();r}catch(_:Exception){""}

    private fun showDatabaseActions(label:String,path:String){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(TextView(this).apply{text=databaseSummarySafe(path);textSize=12f;setTextColor(Color.rgb(145,141,154));setPadding(0,0,0,dp(12))})
        val delete=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Delete Database";isAllCaps=false;setTextColor(red)}
        box.addView(delete,LinearLayout.LayoutParams(-1,dp(42)))
        val dialog=cardDialog(label,box);dialogRef=dialog;dialog.setOnDismissListener{if(dialogRef===dialog)dialogRef=null}
        delete.setOnClickListener{
            dialog.dismiss()
            val confirm=cardDialog("Delete $label?",TextView(this).apply{text="This database and its local data will be removed from Project Lily.";textSize=13f;setTextColor(white);setPadding(0,dp(8),0,dp(8))},"Delete"){
                if(File(path).absolutePath==dbFile.absolutePath){
                    db.close();copyBundledDatabase("Parks_and_Recreation.db");prefs.edit().putString("active_db_path",dbFile.path).apply()
                }
                File(path).delete();unregisterUserDatabase(path);refreshSchemaPanel();statusOk("Deleted $label")
            }
            confirm.show()
        }
        dialog.show()
    }

    private fun addTreeSection(root:LinearLayout,title:String,type:String,always:Boolean){
        val names=mutableListOf<String>()
        db.rawQuery("SELECT name FROM sqlite_master WHERE type=? AND name NOT LIKE 'sqlite_%' ORDER BY name",arrayOf(type)).use{c->while(c.moveToNext())names.add(c.getString(0))}
        if(names.isEmpty()&&!always)return
        val section=TextView(this).apply{text=title;textSize=9f;letterSpacing=.14f;setTextColor(Color.rgb(112,116,129));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(8),dp(8),dp(8),dp(6))}
        root.addView(section)
        if(names.isEmpty()){
            root.addView(TextView(this).apply{text="No tables yet";textSize=11f;setTextColor(Color.rgb(130,134,147));setPadding(dp(16),dp(4),dp(8),dp(8))})
            return
        }
        names.forEach{name->addTreeNode(root,name,type)}
    }

    private fun addTreeNode(parent:LinearLayout,name:String,type:String){
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(38);setPadding(dp(4),0,dp(4),0);setBackgroundResource(R.drawable.tree_row)}
        val chevron=TextView(this).apply{text="▸";textSize=18f;setTextColor(blue);gravity=Gravity.CENTER;setPadding(0,0,0,dp(2));layoutParams=LinearLayout.LayoutParams(dp(32),dp(40))}
        val icon=TextView(this).apply{text=if(type=="table")"▦" else if(type=="view")"◫" else "◇";textSize=13f;setTextColor(Color.rgb(166,160,177));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(28),dp(40))}
        val label=TextView(this).apply{text=name;textSize=12f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(40),1f)}
        val meta=TextView(this).apply{this.text=if(type=="table")tableRowCountText(name) else "";textSize=10f;setTextColor(Color.rgb(125,129,141));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-2,dp(40))}
        row.addView(chevron);row.addView(icon);row.addView(label);row.addView(meta)
        val children=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(32),0,0,0)}
        parent.addView(row);parent.addView(children)
        var expanded=false
        fun setExpanded(value:Boolean){expanded=value;chevron.text=if(expanded)"▾" else "▸";children.visibility=if(expanded)View.VISIBLE else View.GONE}
        chevron.setOnClickListener{setExpanded(!expanded)}
        row.setOnClickListener{
            if(type=="table"){
                setExpanded(!expanded)
                showTablePreviewInline(name)
            }else insertSql(name)
        }
        if(type=="table"){
            val columnsRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(36);setPadding(0,0,dp(4),0)}
            val cc=TextView(this).apply{text="▸";textSize=17f;setTextColor(Color.rgb(155,150,168));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(32),dp(36))}
            val ci=TextView(this).apply{text="◇";textSize=12f;setTextColor(Color.rgb(155,150,168));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(28),dp(36))}
            val ct=TextView(this).apply{text="Columns";textSize=11f;setTextColor(Color.rgb(196,192,202));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(0,dp(36),1f)}
            columnsRow.addView(cc);columnsRow.addView(ci);columnsRow.addView(ct);children.addView(columnsRow)
            val columns=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(28),0,0,dp(4))}
            children.addView(columns)
            var columnsExpanded=false
            fun setColumnsExpanded(value:Boolean){columnsExpanded=value;cc.text=if(columnsExpanded)"▾" else "▸";columns.visibility=if(columnsExpanded)View.VISIBLE else View.GONE}
            cc.setOnClickListener{setColumnsExpanded(!columnsExpanded)}
            columnsRow.setOnClickListener{setColumnsExpanded(!columnsExpanded)}
            db.rawQuery("PRAGMA table_info('${name.replace("'","''")}')",null).use{c->while(c.moveToNext()){
                val col=c.getString(1);val typ=c.getString(2).ifBlank{"ANY"};val pk=c.getInt(5)>0
                val cr=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(32);setPadding(0,0,dp(4),0)}
                cr.addView(TextView(this).apply{text="◆";textSize=9f;setTextColor(Color.rgb(150,145,163));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(28),dp(32))})
                cr.addView(TextView(this).apply{text=col;textSize=11f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(32),1f)})
                cr.addView(TextView(this).apply{text=if(pk)"$typ · PK" else typ;textSize=9f;setTextColor(Color.rgb(125,129,141));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-2,dp(32))})
                cr.setOnClickListener{insertSql("\"${col.replace("\"","\"\"")}\"")}
                columns.addView(cr)
            }}
        }
    }

    private fun tableRowCountText(name:String):String=try{db.rawQuery("SELECT COUNT(*) FROM \"${name.replace("\"","\"\"")}\"",null).use{if(it.moveToFirst())"${it.getLong(0)} rows" else ""}}catch(_:Exception){""}

    private fun showTablePreviewInline(table:String){
        dismissAutocomplete()
        val safe=table.replace("\"","\"\"")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10))}
        val title=TextView(this).apply{text=table;textSize=15f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,0,0,4)}
        box.addView(title)
        val meta=TextView(this).apply{textSize=11f;setTextColor(Color.rgb(130,134,147));setPadding(0,0,0,8)}
        val count=try{db.rawQuery("SELECT COUNT(*) FROM \"$safe\"",null).use{c->c.moveToFirst();c.getLong(0)}}catch(_:Exception){0L}
        meta.text="${tableColumnCount(table)} columns  ·  $count rows  ·  first 50 shown"
        box.addView(meta)
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val select=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Insert SELECT *";isAllCaps=false;setOnClickListener{insertSql("SELECT * FROM \"$safe\";")}}
        actions.addView(select)
        box.addView(actions)
        val data=mutableListOf<List<String>>()
        db.rawQuery("SELECT * FROM \"$safe\" LIMIT 50",null).use{c->{data.add((0 until c.columnCount).map{c.getColumnName(it)});while(c.moveToNext())data.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)})}}
        box.addView(buildPreviewGrid(data),LinearLayout.LayoutParams(-1,0,1f))
        resultContainer.removeAllViews();resultContainer.addView(box)
        statusOk("Previewing $table")
    }

    private fun buildPreviewGrid(data:List<List<String>>):View{
        val table=TableLayout(this)
        table.isStretchAllColumns=false
        if(data.isEmpty()) return TextView(this).apply{text="No columns";setPadding(dp(12),dp(12),dp(12),dp(12));setTextColor(white)}
        val header=TableRow(this)
        for(v in data[0]) header.addView(cell(v,true){})
        table.addView(header)
        for(i in 1 until data.size){
            val row=TableRow(this)
            for(v in data[i]) row.addView(cell(v,false){copyText(v)})
            table.addView(row)
        }
        if(data.size==1) table.addView(TextView(this).apply{text="(0 rows)";setPadding(dp(16),dp(16),dp(16),dp(16));setTextColor(white)})
        val hs=HorizontalScrollView(this)
        hs.addView(table)
        val vs=ScrollView(this)
        vs.addView(hs)
        return vs
    }

    private fun tableColumnCount(table:String):Int{var n=0;db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())n++};return n}


    private fun showSchema(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),dp(0));minimumHeight=dp(420)}
        val hint=TextView(this).apply{text="Select a database above. Expand a table to browse columns.";textSize=12f;setTextColor(Color.rgb(128,132,145));setPadding(0,0,0,dp(10))}
        box.addView(hint)
        val import=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Import .db / .sql";isAllCaps=false;setOnClickListener{dismissAutocomplete();pickFile()}}
        box.addView(import,LinearLayout.LayoutParams(-1,dp(42)).apply{bottomMargin=dp(10)})
        val scroll=ScrollView(this);scroll.addView(interactiveSchemaView());box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        cardDialog("Database Explorer",box).show()
    }

    private fun refreshSchemaPanel(){schemaPanel?.let{it.removeAllViews();it.addView(interactiveSchemaView(),LinearLayout.LayoutParams(-1,-2))}}

    private fun firstTable():String{db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 1",null).use{c->if(c.moveToFirst())return c.getString(0)};return "employee_demographics"}
    private fun chooseDatabase(){showSchema()}

    private fun statusOk(s:String){status.text="✓ $s";status.setTextColor(green)};private fun showError(s:String){status.text="✕ $s";status.setTextColor(red)}

    private fun highlight(){if(highlighting)return;highlighting=true;val e=editor.text;val pos=editor.selectionStart;e.getSpans(0,e.length,ForegroundColorSpan::class.java).forEach{e.removeSpan(it)};val text=e.toString();val patterns=listOf(Pattern.compile("(?i)\\b("+keywords.joinToString("|")+")\\b") to blue,Pattern.compile("'(?:''|[^'])*'") to orange,Pattern.compile("--[^\\n]*") to Color.rgb(180,172,160),Pattern.compile("\\b\\d+(?:\\.\\d+)?\\b") to green);for((p,col) in patterns)p.matcher(text).run{while(find())e.setSpan(ForegroundColorSpan(col),start(),end(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)};editor.setSelection(pos.coerceIn(0,e.length));highlighting=false}

    private fun formatSql(s:String):String{var x=s.replace(Regex("\\s+")," ").replace(Regex("\\s*;\\s*"),";\n");val kws=listOf("SELECT","FROM","WHERE","JOIN","LEFT JOIN","RIGHT JOIN","INNER JOIN","ORDER BY","GROUP BY","HAVING","LIMIT","UNION","VALUES","SET");for(k in kws)x=x.replace(Regex("\\s*${k.replace(" ","\\s+")}\\s*",RegexOption.IGNORE_CASE),"\n${k} ");return x.trim().replace(Regex("\\n+"),"\n")}
    private fun toggleComment(){val a=editor.selectionStart;val z=editor.selectionEnd;val s=minOf(a,z);val e=maxOf(a,z);val start=editor.text.lastIndexOf('\n',s-1).let{if(it<0)0 else it+1};val end=editor.text.indexOf('\n',e).let{if(it<0)editor.length() else it};val block=editor.text.substring(start,end);val lines=block.split('\n');val uncomment=lines.filter{it.trimStart().startsWith("--")}.size>lines.size/2;val repl=lines.joinToString("\n"){if(uncomment)it.replaceFirst(Regex("^\\s*--\\s?"),"") else if(it.isBlank())it else "-- $it"};editor.text.replace(start,end,repl);editor.setSelection(start,start+repl.length)}

    private fun showHistory(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(TextView(this).apply{text="Recent queries";textSize=11f;setTextColor(Color.rgb(128,132,145));layoutParams=LinearLayout.LayoutParams(0,dp(32),1f)})
        val clear=TextView(this).apply{text="Clear";textSize=12f;setTextColor(blue);gravity=Gravity.CENTER;setPadding(dp(10),0,dp(10),0);isClickable=true;contentDescription="Clear query history"}
        top.addView(clear,LinearLayout.LayoutParams(dp(64),dp(32)))
        box.addView(top)
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun render(){
            list.removeAllViews()
            if(history.isEmpty()){list.addView(TextView(this).apply{text="No query history yet.\nRun a query and it will appear here.";textSize=12f;setTextColor(Color.rgb(150,146,158));setPadding(dp(8),dp(16),dp(8),dp(16))})}
            else history.forEachIndexed{index,q->
                val row=TextView(this).apply{text=q.replace(Regex("\\s+")," ").trim();textSize=12f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setSingleLine(true);ellipsize=android.text.TextUtils.TruncateAt.END;setPadding(dp(10),0,dp(10),0);background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),10f);isClickable=true;contentDescription="Restore query ${index+1}"}
                row.setOnClickListener{editor.setText(q);editor.setSelection(editor.length());statusOk("Query restored from history");dialogRef?.dismiss()}
                list.addView(row,LinearLayout.LayoutParams(-1,dp(38)).apply{if(index>0)topMargin=dp(5)})
            }
        }
        scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(300)))
        val dialog=cardDialog("Quick History",box);dialogRef=dialog;dialog.setOnDismissListener{if(dialogRef===dialog)dialogRef=null}
        clear.setOnClickListener{
            if(history.isEmpty())return@setOnClickListener
            cardDialog("Clear history?",TextView(this).apply{text="This will remove all saved query history.";textSize=13f;setTextColor(white);setPadding(0,dp(8),0,dp(8))},"Clear"){history.clear();savePrefs();render()}.show()
        }
        render();dialog.show()
    }
    private fun saveSnippetDialog(){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL
        val hint=TextView(this);hint.text="Give this query a short name.";hint.textSize=12f;hint.setTextColor(Color.rgb(127,131,144));box.addView(hint)
        val input=EditText(this);input.hint="e.g. My JOIN practice";input.setSingleLine(true);input.textSize=14f;input.setTextColor(white);input.setPadding(dp(12),0,dp(12),0);input.background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),12f);box.addView(input,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(10)})
        cardDialog("Save snippet",box,"Save"){val name=input.text.toString().trim();if(name.isNotEmpty()){snippets[name]=editor.text.toString();prefs.edit().putString("snippet:$name",editor.text.toString()).apply();statusOk("Snippet saved: $name")}}.show()
        input.requestFocus()
    }
    private fun showSnippetMenu(){
        val names=snippets.keys.toList();val items=if(names.isEmpty())listOf("＋  Save current snippet") else listOf("＋  Save current snippet")+names
        cardListDialog("Snippets",items){i->if(i==0)saveSnippetDialog()else{editor.setText(snippets[names[i-1]]);editor.setSelection(editor.length());statusOk("Snippet loaded")}}
    }

    private fun showExplain(msg:String){
        val lower=msg.lowercase();val hint=when{lower.contains("no such column")->"SQLite cannot find that column. Check spelling, table aliases, and whether the column belongs to the table you are querying.";lower.contains("no such table")->"SQLite cannot find that table. Check the table name and make sure you imported or created the right database.";lower.contains("syntax error")->"SQLite could not parse the SQL. Check commas, parentheses, quotes, keywords, and statement order.";lower.contains("constraint failed")->"A table constraint was violated. Check PRIMARY KEY, UNIQUE, NOT NULL, FOREIGN KEY, or CHECK rules.";lower.contains("datatype mismatch")->"A value does not fit the operation or column type. Check casts and the values being inserted or compared.";lower.contains("ambiguous column")->"More than one table has that column name. Qualify it with a table name or alias, for example e.salary.";else->"Run the statement again and inspect the SQLite message above. Start by checking table names, column names, aliases, commas, quotes, and parentheses."}
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;val icon=TextView(this);icon.text="SQLite error";icon.textSize=12f;icon.setTextColor(red);icon.setTypeface(null,android.graphics.Typeface.BOLD);box.addView(icon);val text=TextView(this);text.text=hint;text.textSize=14f;text.setTextColor(white);text.setPadding(0,dp(8),0,dp(8));box.addView(text);cardDialog("Explain this error",box).show()
    }

    private fun showPractice(){
        val challenges=listOf("Find employees older than 40","Join salary with demographics","Find the highest 3 salaries","Count employees by gender","Show all departments")
        cardListDialog("Practice mode",challenges.mapIndexed{i,s->"${i+1}.  $s"}){which->currentChallenge=which;editor.setText(challengeSql[which]);editor.setSelection(editor.length());statusOk("Challenge loaded — run it, then tap Check")}
    }
    private fun checkPractice(){if(currentChallenge<0){showError("Load a practice challenge first");return};try{val user=editor.text.toString();val expected=challengeSql[currentChallenge];val ur=collectResult(user);val er=collectResult(expected);if(ur==er)statusOk("Practice check passed ✓ — result matches the expected output")else showError("Practice check did not match the expected output. Compare columns, rows, ordering, and filters.")}catch(e:Exception){showError("Practice check error: ${e.message?:"SQL error"}")}}
    private fun collectResult(sql:String):List<List<String>>{val q=splitSql(sql).lastOrNull{isQueryStatement(it)}?:throw Exception("No query found");db.rawQuery(q,null).use{c->val out=mutableListOf<List<String>>();out.add((0 until c.columnCount).map{c.getColumnName(it)});while(c.moveToNext())out.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)});return out}}

    private fun planRows(sql:String):List<Triple<Int,Int,String>>{val out=mutableListOf<Triple<Int,Int,String>>();db.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(Triple(c.getInt(0),c.getInt(1),c.getString(3))) };return out}
    private fun buildPlanView(rows:List<Triple<Int,Int,String>>):View{val t=LinearLayout(this);t.orientation=LinearLayout.VERTICAL;t.setPadding(18,16,18,16);for((id,parent,detail) in rows){val v=TextView(this);v.text=(if(parent==0)"▸ " else "  └─ ")+detail+"  [id=$id parent=$parent]";v.textSize=13f;v.setTextColor(white);v.setPadding(8,8,8,8);t.addView(v)};val s=ScrollView(this);s.addView(t);return s}

    private fun exportDatabase(){val i=Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.type="application/octet-stream";i.putExtra(Intent.EXTRA_TITLE,"ProjectLily-${dbFile.name}");startActivityForResult(i,88)}
    private fun exportCsv(){if(activeTab<0||tabs[activeTab].csv==null){showError("Run a result query first");return};val csv=tabs[activeTab].csv!!.joinToString("\n"){row->row.joinToString(","){csvEscape(it)}};val i=Intent(Intent.ACTION_SEND);i.type="text/csv";i.putExtra(Intent.EXTRA_TEXT,csv);i.putExtra(Intent.EXTRA_TITLE,"query-result.csv");startActivity(Intent.createChooser(i,"Share CSV"))}
    private fun csvEscape(s:String)=if(s.contains(',')||s.contains('"')||s.contains('\n'))"\"${s.replace("\"","\"\"")}\"" else s

    private fun dp(value:Int):Int=(value*resources.displayMetrics.density).roundToInt()

    private fun rounded(fill:Int, stroke:Int, strokeColor:Int, radius:Float):android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply{
            setColor(fill)
            if(stroke>0)setStroke(dp(stroke),strokeColor)
            cornerRadius=dp(radius.toInt()).toFloat()
        }

    private fun insertSql(text:String){
        dismissAutocomplete()
        val start=editor.selectionStart.coerceAtLeast(0)
        val end=editor.selectionEnd.coerceAtLeast(0)
        val a=minOf(start,end).coerceIn(0,editor.length())
        val b=maxOf(start,end).coerceIn(a,editor.length())
        try{
            editor.text.replace(a,b,text)
            editor.setSelection((a+text.length).coerceAtMost(editor.length()))
            editor.requestFocus()
            highlight()
        }catch(e:Exception){showError("Could not insert into editor")}
    }

    private class LoadingDotsView(context:Context):View(context){
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(213,138,175)}
        private var animator:ValueAnimator?=null
        private var phase=0f
        private var complete=false
        init{setLayerType(View.LAYER_TYPE_SOFTWARE,null)}
        override fun onDraw(canvas:Canvas){
            super.onDraw(canvas)
            val centerY=height/2f;val gap=dpLocal(18);val base=dpLocal(5);val cx=width/2f
            for(i in 0..2){
                val distance=(phase-i*0.333f).let{var x=it%1f;if(x<0)x+=1f;x}
                val pulse=if(complete)0f else (1f-kotlin.math.abs(distance-0.5f)*2f).coerceIn(0f,1f)
                val radius=base*(0.72f+0.48f*pulse)
                paint.alpha=(145+110*pulse).toInt().coerceIn(0,255)
                canvas.drawCircle(cx+(i-1)*gap,centerY,radius,paint)
            }
        }
        private fun dpLocal(v:Int)=v*resources.displayMetrics.density
        override fun onDetachedFromWindow(){animator?.cancel();animator=null;super.onDetachedFromWindow()}
        fun start(){
            complete=false;animator?.cancel();animator=ValueAnimator.ofFloat(0f,1f).apply{duration=1150;interpolator=LinearInterpolator();repeatCount=ValueAnimator.INFINITE;addUpdateListener{phase=it.animatedValue as Float;invalidate()};start()}
        }
        fun stop(){animator?.cancel();animator=null;complete=false;invalidate()}
        fun showComplete(){animator?.cancel();animator=null;complete=true;phase=.5f;invalidate()}
        fun showError(){animator?.cancel();animator=null;complete=false;phase=.5f;paint.alpha=210;invalidate()}
    }

    private fun cardDialog(titleText:String, content:View, positiveText:String?=null, positiveAction:(()->Unit)?=null):AlertDialog{
        val outer=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(14),dp(18),dp(16))
            background=rounded(Color.rgb(20,22,29),1,Color.rgb(58,53,64),18f)
        }
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val title=TextView(this).apply{text=titleText;textSize=15f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1}
        titleRow.addView(title,LinearLayout.LayoutParams(0,dp(32),1f))
        val close=TextView(this).apply{text="×";textSize=22f;setTextColor(Color.rgb(145,140,151));gravity=Gravity.CENTER;isClickable=true;contentDescription="Close";setOnClickListener{}}
        titleRow.addView(close,LinearLayout.LayoutParams(dp(32),dp(32)))
        outer.addView(titleRow)
        val divider=View(this).apply{setBackgroundColor(Color.rgb(42,44,53))}
        outer.addView(divider,LinearLayout.LayoutParams(-1,dp(1)).apply{topMargin=dp(8);bottomMargin=dp(12)})
        outer.addView(content,LinearLayout.LayoutParams(-1,0,1f))
        val dialog=AlertDialog.Builder(this).setView(outer).create()
        close.setOnClickListener{dialog.dismiss()}
        positiveText?.let{label->
            val action=Button(ContextThemeWrapper(this,R.style.FlatButton_Accent)).apply{text=label;isAllCaps=false;setOnClickListener{positiveAction?.invoke();dialog.dismiss()}}
            outer.addView(action,LinearLayout.LayoutParams(-1,dp(42)).apply{topMargin=dp(12)})
        }
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setOnShowListener{dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))}
        return dialog
    }

    private fun cardListDialog(title:String, items:List<String>, onPick:(Int)->Unit){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        if(items.isEmpty()){
            box.addView(TextView(this).apply{text="Nothing here yet.";textSize=14f;setTextColor(white);setPadding(0,dp(6),0,dp(10))})
        }else{
            items.forEachIndexed{index,label->
                val row=TextView(this).apply{
                    text=label;textSize=14f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(12),0)
                    background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),10f)
                    isClickable=true
                }
                row.setOnClickListener{onPick(index);dialogRef?.dismiss()}
                box.addView(row,LinearLayout.LayoutParams(-1,dp(44)).apply{if(index>0)topMargin=dp(6)})
            }
        }
        val dialog=cardDialog(title,box)
        dialogRef=dialog
        dialog.setOnDismissListener{if(dialogRef===dialog)dialogRef=null}
        dialog.show()
    }

    private var dialogRef:AlertDialog?=null

    private fun updateAutocomplete(){
        dismissAutocomplete()
        if(!editor.hasFocus() || !::db.isInitialized || !db.isOpen) return
        val cursor=editor.selectionStart
        if(cursor<0 || editor.selectionStart!=editor.selectionEnd) return
        val before=editor.text.substring(0,cursor)
        val tokenMatch=Regex("[A-Za-z_][A-Za-z0-9_]*$").find(before)
        val token=tokenMatch?.value.orEmpty()
        val tokenStart=if(token.isNotEmpty())cursor-token.length else cursor
        val left=before.substring(0,tokenStart)
        val trimmed=left.trimEnd()
        val qualified=Regex("([A-Za-z_][A-Za-z0-9_]*)\\.$").find(trimmed)?.groupValues?.get(1)

        val mode=when{
            qualified!=null -> "qualified"
            token.isEmpty() -> null
            Regex("\\b(?:FROM|JOIN|UPDATE|INTO|TABLE)\\s*$",RegexOption.IGNORE_CASE).containsMatchIn(trimmed) -> "table"
            Regex("\\b(?:SELECT|WHERE|ON|ORDER\\s+BY|GROUP\\s+BY|HAVING|SET|AND|OR)\\s*$",RegexOption.IGNORE_CASE).containsMatchIn(trimmed) -> "column"
            else -> null
        } ?: return

        val suggestions=when(mode){
            "table" -> tableSuggestions(token)
            "qualified" -> qualifiedColumnSuggestions(qualified!!,token)
            else -> columnSuggestions(before,token)
        }.distinct().take(6)
        if(suggestions.isEmpty()) return

        val popup=PopupWindow(this)
        autocompletePopup=popup
        autocompleteTokenStart=tokenStart
        val list=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(3),dp(3),dp(3),dp(3))
            background=rounded(Color.rgb(20,22,29),1,Color.rgb(53,48,58),10f)
        }
        suggestions.forEachIndexed{index,suggestion->
            val row=TextView(this).apply{
                text=suggestion;textSize=13f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(10),0,dp(10),0);isSingleLine=true
                background=rounded(if(index==0)Color.rgb(43,34,42) else Color.rgb(28,30,38),0,Color.TRANSPARENT,6f)
                setOnClickListener{
                    val start=autocompleteTokenStart;val end=editor.selectionStart
                    if(start in 0..end && end<=editor.length()){
                        try{
                            editor.text.replace(start,end,suggestion)
                            editor.setSelection((start+suggestion.length).coerceAtMost(editor.length()))
                        }catch(_:Throwable){}
                    }
                    dismissAutocomplete();editor.requestFocus()
                }
            }
            list.addView(row,LinearLayout.LayoutParams(-1,dp(32)).apply{if(index>0)topMargin=dp(2)})
        }
        popup.contentView=list;popup.width=dp(210);popup.height=dp(6+32*suggestions.size+2*(suggestions.size-1))
        popup.isFocusable=false;popup.isOutsideTouchable=true;popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));popup.elevation=dp(5).toFloat()
        editor.post{positionAutocomplete(popup)}
    }

    private fun tableSuggestions(token:String):List<String>{
        val out=mutableListOf<String>()
        db.rawQuery("SELECT name FROM sqlite_master WHERE (type='table' OR type='view') AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->while(c.moveToNext()){val n=c.getString(0);if(n.startsWith(token,true))out.add(n)}}
        return out
    }

    private fun columnSuggestions(before:String,token:String):List<String>{
        val tables=Regex("\\b(?:FROM|JOIN)\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s+(?:AS\\s+)?([A-Za-z_][A-Za-z0-9_]*))?",RegexOption.IGNORE_CASE).findAll(before)
            .flatMap{sequenceOf(it.groupValues[1],it.groupValues.getOrNull(2).orEmpty())}.filter{it.isNotBlank()}.toList().distinct()
        if(tables.isEmpty())return emptyList()
        return tables.flatMap{tableColumnsFor(it,token)}.distinct()
    }

    private fun qualifiedColumnSuggestions(qualifier:String,token:String):List<String>{
        val direct=tableSuggestions(qualifier).firstOrNull{it.equals(qualifier,true)}
        if(direct!=null)return tableColumnsFor(direct,token)
        val match=Regex("\\b(?:FROM|JOIN)\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s+AS)?\\s+${Regex.escape(qualifier)}\\b",RegexOption.IGNORE_CASE).find(editor.text.substring(0,editor.selectionStart))
        return match?.groupValues?.get(1)?.let{tableColumnsFor(it,token)} ?: emptyList()
    }

    private fun tableColumnsFor(table:String,token:String):List<String>{
        val out=mutableListOf<String>();val safe=table.replace("'","''")
        try{db.rawQuery("PRAGMA table_info('$safe')",null).use{c->while(c.moveToNext()){val n=c.getString(1);if(token.isEmpty()||n.startsWith(token,true))out.add(n)}}}catch(_:Exception){}
        return out
    }

    private fun positionAutocomplete(popup:PopupWindow){
        if(autocompletePopup!==popup || !editor.isShown) return
        val layout=editor.layout ?: return
        val cursor=editor.selectionStart.coerceIn(0,editor.length())
        val line=layout.getLineForOffset(cursor)
        val x=layout.getPrimaryHorizontal(cursor).toInt()-editor.scrollX
        val lineTop=layout.getLineTop(line)-editor.scrollY
        val loc=IntArray(2)
        editor.getLocationOnScreen(loc)
        val popupW=popup.width
        val margin=dp(8)
        val screenW=resources.displayMetrics.widthPixels
        val screenH=resources.displayMetrics.heightPixels
        val px=(loc[0]+x).coerceIn(margin,(screenW-popupW-margin).coerceAtLeast(margin))
        val popupH=popup.height
        var py=loc[1]+lineTop+editor.lineHeight+dp(3)
        if(py+popupH>screenH-margin) py=loc[1]+lineTop-popupH-dp(3)
        py=py.coerceAtLeast(margin)
        try{popup.showAtLocation(editor,Gravity.TOP or Gravity.START,px,py)}catch(_:WindowManager.BadTokenException){dismissAutocomplete()}
    }

    private fun dismissAutocomplete(){
        autocompletePopup?.dismiss()
        autocompletePopup=null
        autocompleteTokenStart=-1
    }

    internal fun shouldKeepAutocompleteVisible():Boolean = suppressAutocompleteDismiss
    internal fun dismissAutocompleteFromEditor(){dismissAutocomplete()}

    override fun onKeyDown(keyCode:Int,event:KeyEvent):Boolean{if((event.isCtrlPressed||event.isMetaPressed)&&keyCode==KeyEvent.KEYCODE_ENTER){runSelectedOrAll();return true};if((event.isCtrlPressed||event.isMetaPressed)&&keyCode==KeyEvent.KEYCODE_SLASH){toggleComment();return true};return super.onKeyDown(keyCode,event)}
    override fun onDestroy(){dismissAutocomplete();if(::db.isInitialized&&db.isOpen)db.close();super.onDestroy()}
}

class LineNumberEditText(context:Context, attrs:android.util.AttributeSet?=null):android.widget.EditText(context,attrs){    override fun onSelectionChanged(selStart:Int,selEnd:Int){
        super.onSelectionChanged(selStart,selEnd)
        (context as? MainActivity)?.let { if(!it.shouldKeepAutocompleteVisible()) it.dismissAutocompleteFromEditor() }
    }

    private val paint=android.graphics.Paint().apply{color=Color.rgb(91,95,108);textSize=36f;typeface=android.graphics.Typeface.MONOSPACE}
    init{
        // SQL editors should not impose a practical line limit. Keep the text vertically
        // scrollable while preserving a fixed-width monospace editor (no surprise wrapping).
        setMaxLines(Int.MAX_VALUE)
        setHorizontallyScrolling(true)
        setVerticalScrollBarEnabled(true)
        overScrollMode=android.view.View.OVER_SCROLL_IF_CONTENT_SCROLLS
        setPadding(58,paddingTop,paddingRight,paddingBottom)
        setBackgroundColor(Color.TRANSPARENT)
        setTextColor(Color.rgb(231,227,233))
        setOnFocusChangeListener{_,_->invalidate()}
        setOnScrollChangeListener{_,_,_,_,_->invalidate()}
    }
    override fun onDraw(canvas:android.graphics.Canvas){
        val lineH=lineHeight.toFloat().coerceAtLeast(1f)
        val current=layout?.getLineForOffset(selectionStart)?:0
        val top=current*lineH-scrollY
        val hi=android.graphics.Paint().apply{color=Color.rgb(39,31,40)}
        canvas.drawRect(0f,top,width.toFloat(),top+lineH,hi)
        val first=(scrollY/lineH).toInt().coerceAtLeast(0)
        val last=((scrollY+height)/lineH).toInt()+1
        paint.textSize=textSize*0.78f
        for(line in first..last){
            val y=(line+1)*lineH-scrollY
            canvas.drawText((line+1).toString(),8f,y,paint)
        }
        super.onDraw(canvas)
    }
}
