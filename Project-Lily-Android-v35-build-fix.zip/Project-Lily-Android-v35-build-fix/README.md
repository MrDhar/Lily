# Project Lily v32

Based on Project Lily v22.

## Workspace fixes
- SQL Server + MySQL `.sql` imports are translated more safely for SQLite, including `IDENTITY_INSERT`, `GO`, bracketed identifiers, identity primary keys, common SQL Server types, and dump-only index/constraint statements.
- Imported databases persist locally as the active working database after app restart.
- Database Explorer is cleaner and more structured; tables are clickable and preview their first 50 rows directly in the main workspace instead of opening a table popup.
- Clicking a column inserts its quoted name into the editor.
- Empty Views/Indexes sections are hidden to reduce clutter.
- Tablet layout now has a real editor/results splitter.
- Project Lily remains immersive fullscreen and keeps the dark Lily/macOS-inspired visual language.

## Workspace redesign (v28)
- Persistent database library: bundled Parks & Recreation remains under Samples; imported SQLite/SQL databases are kept separately under My Databases.
- Active database is highlighted; imported databases can be deleted from their database header/action view. The old Reset database control is removed.
- Database explorer uses a collapsible tree for tables and columns.
- Main three-dot controls are functional: database sidebar, SQL focus mode, and a command palette.
- Dialogs no longer use decorative macOS-style dots.
- The old permanent tools row and Tools button are removed; the third window dot opens a compact searchable command palette.
- Quick History is scrollable, uses compact single-line query previews, and has Clear History.
- Editor/results divider remains directly draggable.

## Import experience (v32)
- Importing runs off the UI thread so Lily returns immediately to a native file-import surface instead of appearing frozen.
- `.db`, `.sqlite`, `.sqlite3`, `.sql`, and `.txt` imports show the appropriate “Importing database” or “Importing SQL” state.
- Loading uses a smooth three-dot Lily-pink ellipsis animation inspired by iOS, with no snake/trail effect.
- Import can be cancelled while a large SQL script is being processed.
- Import failures stay in the same surface with the SQLite/import error plus Retry and Close.
- Successful imports briefly show a completion state before returning to the workspace.
- The tablet-only sidebar chevron is removed because the first window dot is the single sidebar control.
