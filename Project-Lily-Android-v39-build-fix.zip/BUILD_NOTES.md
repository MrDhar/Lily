# Project Lily v38 changes

- Middle window dot now opens a compact macOS/iOS-inspired popover with exactly two actions: Save and CSV.
- Save uses Android ACTION_CREATE_DOCUMENT and saves the current editor contents as a .sql file, letting the user choose the destination in the system file picker.
- CSV uses ACTION_CREATE_DOCUMENT and saves the active result tab as query-result.csv to a user-selected location.
- Removed Export DB and CSV buttons from the result toolbar to avoid duplicate actions.
- Export Database remains available from the Command Palette.
- Explain remains in the result toolbar and is enabled only when the active result tab is an error; it now explains the actual active error rather than the generic status text.
- Compact middle-dot popover is small, anchored under the middle dot, with short rows and no decorative elements.
- Preserved v37 import hardening and compact Command Palette/import UI.
