# Project Lily

Lily is an offline Android SQL editor/database workspace built around SQLite.

## v53 — Full Audit & Stability Pass

This release is based on the latest v52 build and keeps the existing compact Mac/iOS-inspired workspace, large-data processing, virtualized results, streaming import/export, database explorer, table designer, query profiler and SQL IDE features.

Concrete fixes in this audit include:

- Fixed malformed/nested SQLite cursor `use` blocks that could prevent preview/export/JSON work from executing.
- Fixed table CSV export accidentally emitting SQL INSERT data before CSV output.
- Fixed table SQL export cursor/writer structure and typed value handling.
- Fixed table duplication SQL quoting.
- Fixed SQL Server `GO` / `IF EXISTS ... END` batch state handling.
- Fixed query-stop logic to interrupt the active SQLite connection correctly.
- Fixed primary-key-only data editor behavior so it does not issue an invalid empty `UPDATE`.
- Fixed PRAGMA table/index inspection for table names containing apostrophes.
- Added live field synchronization in the Visual Table Designer.
- Fixed query result streaming export nullable query handoff.
- Fixed active-result search matching implementation.
- Preserved safe, bounded result rendering and streaming large-data workflows.
- Kept the import progress dots inside a non-clipping drawing area.

Version: 3.9 / versionCode 39

## Validation

- Source ZIP integrity checked before and after the audit.
- Kotlin compiler used to detect parser and source-level syntax issues. No Kotlin parser errors remain in `MainActivity.kt`.
- Android resource XML files parsed successfully with Python XML parsing.
- All `R.id` references used by `MainActivity.kt` resolve to defined layout IDs.
- Bundled SQLite sample databases pass `PRAGMA integrity_check`.

A full Android Gradle build still requires an Android SDK environment such as GitHub Actions.
