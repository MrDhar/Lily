# Project Lily v55 — Build Repair

v55 is a focused compiler-repair release based on v54. It does not add product features. It fixes the Kotlin/Android API errors reported by the CI build and keeps the existing Lily SQL IDE, large-data processing, import/export, result grid, workspace, database management, profiler, zoom and visual design intact.

Build with the repository's Android workflow / Gradle environment.
