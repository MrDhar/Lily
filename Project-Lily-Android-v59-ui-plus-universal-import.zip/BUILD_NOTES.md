# Project Lily v59 — UI issue pass

Based on v58 Universal SQL Import.

Implemented requested UI changes:
1. Removed **New Query Tab** from the Command Palette. Query tabs are still created with the existing `+` button.
2. On tablet layouts, the **Lily / SQL Editor** branding area is clickable and toggles the database sidebar open/closed.
3. The first macOS-style window dot is now a **Database Switcher** popup. It lists the bundled sample and imported databases and switches the active database without using the sidebar.
4. Dot 2 remains Save / CSV; Dot 3 remains Command Palette.

The SQL import improvements from v58 are retained.

Android Gradle compilation was not run in this environment because the Android SDK/Gradle toolchain is unavailable here. GitHub Actions remains the build check.
