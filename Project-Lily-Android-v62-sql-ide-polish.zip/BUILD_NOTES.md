# Project Lily v61 — Desktop Dark UI Redesign

Base: v60 error-result/universal-SQL-import build.

UI redesign based on the visual structure of MySQL Workbench's desktop SQL editor: a compact macOS-style window chrome, left database navigator, central query editor, result grid/output area, dense neutral toolbar controls, and restrained black/gray surfaces.

Key visual decisions:
- Black/charcoal UI with white/gray typography.
- Pink/mauve retained only for the three traffic-light-style Lily dots.
- Lily logo made monochrome in the workspace UI; launcher icon remains unchanged.
- Query/result active tabs changed from pink to neutral graphite.
- Editor syntax accents changed to grayscale except semantic success/error status colors.
- Tablet layout now reads as a desktop SQL application window.
- Phone layout uses the same compact desktop-inspired chrome while remaining vertically arranged.

Functionality intentionally preserved:
- Universal SQL import and streaming import architecture from v58.
- Error result pages and closable error tabs from v60.
- Query tabs and close buttons.
- Database switcher on first dot.
- Save/CSV on second dot.
- Command palette on third dot.
- Clickable Lily/SQL Editor branding for sidebar toggle.
- Editor, formatting, clear, run, explain, result grids, exports, schema tools, performance/integrity tools.
