# Project Lily — Android v3

Native, offline SQL learning app using the Android SQLite engine.

### Editor improvements
- Context-aware autocomplete:
  - after `FROM`, `JOIN`, `UPDATE`, `INTO`, `TABLE` → table/view names
  - after `SELECT`, `WHERE`, `ON`, `ORDER BY`, `GROUP BY`, `HAVING`, `SET` → column names
  - inside aggregate functions → columns, `*`, `DISTINCT`
  - neutral context → SQL keywords and common functions
- SQL syntax coloring
- Import `.sql`, `.db`, `.sqlite`, `.sqlite3`
- Selected-query execution
- Real SQLite errors/results
- Bundled Parks_and_Recreation database
- No network permission

### Build
Open in Android Studio and Build > Build APK(s).


Branding: **Project Lily**, with a small pixel-art pink lily in the app header/icon treatment.
