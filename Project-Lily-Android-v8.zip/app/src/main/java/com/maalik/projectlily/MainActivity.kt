package com.maalik.projectlily

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.text.*
import android.text.style.ForegroundColorSpan
import android.view.*
import android.widget.*
import java.io.*
import java.util.regex.Pattern

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var status: TextView
    private lateinit var resultScroll: HorizontalScrollView
    private lateinit var resultTable: TableLayout
    private lateinit var db: SQLiteDatabase
    private lateinit var dbFile: File

    private val blue=Color.rgb(178,90,130)      // keywords — lily pink/plum
    private val purple=Color.rgb(139,123,168)   // reserved accent
    private val green=Color.rgb(111,143,113)    // numbers — sage
    private val orange=Color.rgb(180,130,90)    // strings — warm terracotta
    private val red=Color.rgb(192,96,91)        // errors
    private val white=Color.rgb(58,52,47)       // default text — soft charcoal
    private var highlighting=false

    private val keywords = listOf(
        "SELECT","FROM","WHERE","INSERT","INTO","VALUES","UPDATE","SET","DELETE",
        "CREATE","TABLE","DROP","ALTER","JOIN","INNER","LEFT","RIGHT","FULL","ON",
        "GROUP","BY","ORDER","ASC","DESC","HAVING","LIMIT","OFFSET","AS","DISTINCT",
        "AND","OR","NOT","NULL","IS","LIKE","IN","BETWEEN","UNION","ALL","CASE",
        "WHEN","THEN","ELSE","END","COUNT","SUM","AVG","MIN","MAX","PRIMARY","KEY",
        "FOREIGN","REFERENCES","DEFAULT","INDEX","VIEW","WITH","EXISTS"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        editor=findViewById(R.id.editor); status=findViewById(R.id.status)
        resultTable=findViewById(R.id.resultsTable); resultScroll=findViewById(R.id.resultScroll)

        copyBundledDatabase()
        editor.setText("""-- Select a query and tap Run.
SELECT * FROM employee_demographics;

SELECT first_name, salary
FROM employee_salary
ORDER BY salary DESC;""")
        editor.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){ showSuggestions() }
            override fun afterTextChanged(e:Editable?){ highlight() }
        })

        findViewById<Button>(R.id.runButton).setOnClickListener{runSelectedOrAll()}
        findViewById<Button>(R.id.importButton).setOnClickListener{pickFile()}
        findViewById<Button>(R.id.schemaButton).setOnClickListener{showSchema()}
        findViewById<Button>(R.id.resetButton).setOnClickListener{resetDatabase()}
        findViewById<Button>(R.id.clearButton).setOnClickListener{editor.setText("")}
    }

    private fun copyBundledDatabase() {
        dbFile=File(filesDir,"Parks_and_Recreation.db")
        if(!dbFile.exists()) assets.open("Parks_and_Recreation.db").use { i->dbFile.outputStream().use{i.copyTo(it)} }
        db=SQLiteDatabase.openOrCreateDatabase(dbFile,null)
    }

    private fun pickFile() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type="*/*"
        startActivityForResult(i,77)
    }

    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if(req!=77 || res!=RESULT_OK || data?.data==null)return
        try {
            val uri=data.data!!
            val name=uri.lastPathSegment?.lowercase()?:""
            val bytes=contentResolver.openInputStream(uri)!!.use{it.readBytes()}
            if(name.endsWith(".db") || name.endsWith(".sqlite") || name.endsWith(".sqlite3")) {
                db.close(); dbFile.delete(); dbFile.writeBytes(bytes)
                db=SQLiteDatabase.openOrCreateDatabase(dbFile,null)
                status.text="✓ Database imported"
                status.setTextColor(green)
                editor.setText("SELECT * FROM "+firstTable()+";")
            } else {
                val sql=bytes.toString(Charsets.UTF_8)
                // A SQL file is loaded into the editor first, so the learner can inspect
                // it before running it. This avoids destructive imports without consent.
                editor.setText(sql)
                status.text="✓ SQL file loaded — select/run what you want"
                status.setTextColor(green)
            }
        } catch(e:Exception) {
            showError(e.message ?: "Could not open file")
        }
    }

    private fun splitSql(s:String):List<String>{
        val out=mutableListOf<String>(); var start=0; var quote:Char?=null
        for(i in s.indices){
            val c=s[i]
            if((c=='\''||c=='"') && (i==0||s[i-1]!='\\'))
                quote=if(quote==c)null else if(quote==null)c else quote
            if(c==';'&&quote==null){ if(s.substring(start,i).trim().isNotEmpty())out.add(s.substring(start,i).trim());start=i+1 }
        }
        if(s.substring(start).trim().isNotEmpty())out.add(s.substring(start).trim())
        return out
    }

    private fun stripLineComments(s:String):String{
        val sb=StringBuilder(); var quote:Char?=null; var i=0
        while(i<s.length){
            val c=s[i]
            if((c=='\''||c=='"') && (i==0||s[i-1]!='\\'))
                quote=if(quote==c)null else if(quote==null)c else quote
            if(quote==null && c=='-' && i+1<s.length && s[i+1]=='-'){
                while(i<s.length && s[i]!='\n')i++
                continue
            }
            sb.append(c); i++
        }
        return sb.toString()
    }

    private fun runSelectedOrAll(){
        val a=editor.selectionStart; val z=editor.selectionEnd
        val selected=if(a!=z)editor.text.substring(minOf(a,z),maxOf(a,z)).trim() else ""
        val statements=splitSql(if(selected.isNotEmpty())selected else editor.text.toString())
            .filter{stripLineComments(it).isNotBlank()}
        if(statements.isEmpty()){showError("Nothing to run");return}
        clearResults()
        try{
            var count=0
            db.beginTransaction()
            for(s in statements){
                if(s.trimStart().startsWith("SELECT",true)||s.trimStart().startsWith("WITH",true)||s.trimStart().startsWith("PRAGMA",true)){
                    db.rawQuery(s,null).use{renderCursor(it)}
                }else db.execSQL(s)
                count++
            }
            db.setTransactionSuccessful();db.endTransaction()
            status.text="✓ Ran $count statement(s)"+if(selected.isNotEmpty())" • selected only" else ""
            status.setTextColor(green)
        }catch(e:Exception){
            try{db.endTransaction()}catch(_:Exception){}
            showError(e.message?:"SQL error")
        }
    }

    private fun renderCursor(c:android.database.Cursor){
        val h=TableRow(this)
        for(i in 0 until c.columnCount)h.addView(cell(c.getColumnName(i),true))
        resultTable.addView(h)
        var n=0
        while(c.moveToNext()&&n<1000){
            val r=TableRow(this)
            for(i in 0 until c.columnCount)r.addView(cell(if(c.isNull(i))"NULL" else c.getString(i),false))
            resultTable.addView(r);n++
        }
    }

    private fun cell(v:String,head:Boolean):TextView{
        val t=TextView(this);t.text=v;t.textSize=12f
        t.setTextColor(if(head)Color.rgb(122,107,96) else white)
        t.setPadding(16,12,16,12)
        t.setBackgroundColor(if(head)Color.rgb(246,240,235) else Color.WHITE)
        return t
    }
    private fun clearResults(){resultTable.removeAllViews()}

    private fun showSchema(){
        val b=StringBuilder()
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->
            while(c.moveToNext()){
                val n=c.getString(0);b.append("TABLE  ").append(n).append("\n")
                db.rawQuery("PRAGMA table_info('$n')",null).use{p->while(p.moveToNext())b.append("   • ").append(p.getString(1)).append(" ").append(p.getString(2)).append("\n")}
                b.append("\n")
            }
        }
        AlertDialog.Builder(this).setTitle("Database schema").setMessage(b.toString()).setPositiveButton("Close",null).show()
    }

    private fun firstTable():String{
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 1",null).use{c->if(c.moveToFirst())return c.getString(0)}
        return "employee_demographics"
    }

    private fun resetDatabase(){
        db.close();dbFile.delete();copyBundledDatabase();clearResults()
        editor.setText("SELECT * FROM employee_demographics;")
        status.text="Database reset";status.setTextColor(green)
    }

    private fun showError(s:String){
        status.text="✕ $s";status.setTextColor(red)
    }

    private fun currentToken():String{
        val p=editor.selectionStart.coerceAtLeast(0).coerceAtMost(editor.length())
        var i=p-1;while(i>=0 && (editor.text[i].isLetterOrDigit()||editor.text[i]=='_'))i--
        return editor.text.substring(i+1,p)
    }

    private fun showSuggestions(){
        val cursor=editor.selectionStart.coerceAtLeast(0)
        val token=currentToken()
        if(token.isEmpty()) return

        val before=editor.text.substring(0,cursor)
        val upper=before.uppercase()
        val suggestions=linkedSetOf<String>()

        // Context-aware completion, intentionally ordered like a SQL IDE:
        // FROM/JOIN -> tables, SELECT/WHERE/ON/ORDER BY/GROUP BY -> columns,
        // after operators -> NULL/functions/keywords, otherwise SQL keywords.
        val tableNames=mutableListOf<String>()
        db.rawQuery("SELECT name FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->
            while(c.moveToNext()) tableNames.add(c.getString(0))
        }
        val columns=mutableListOf<String>()
        tableNames.forEach{n->
            db.rawQuery("PRAGMA table_info('$n')",null).use{c->while(c.moveToNext())columns.add(c.getString(1))}
        }

        val trimmed=upper.trimEnd()
        val fromContext=Regex("""\b(FROM|JOIN|UPDATE|INTO|TABLE)\s+[A-Z0-9_]*$""").containsMatchIn(trimmed)
        val columnContext=Regex("""\b(SELECT|WHERE|ON|ORDER\s+BY|GROUP\s+BY|HAVING|SET)\s+[^;]*[A-Z0-9_.]*$""").containsMatchIn(trimmed)
        val functionContext=Regex("""\b(COUNT|SUM|AVG|MIN|MAX)\s*\(\s*[A-Z0-9_]*$""").containsMatchIn(trimmed)

        when {
            fromContext -> suggestions.addAll(tableNames)
            functionContext -> { suggestions.addAll(columns); suggestions.addAll(listOf("*","DISTINCT")) }
            columnContext -> suggestions.addAll(columns)
            else -> suggestions.addAll(keywords)
        }

        // Add SQL functions when typing in a neutral context.
        if(!fromContext && !columnContext) suggestions.addAll(listOf("COUNT","SUM","AVG","MIN","MAX","COALESCE","ROUND"))

        val choices=suggestions.filter{it.startsWith(token,true)}.take(10)
        if(choices.isEmpty())return

        val popup=PopupWindow(this)
        val list=ListView(this)
        list.setBackgroundColor(Color.WHITE)
        list.divider=android.graphics.drawable.ColorDrawable(Color.rgb(237,228,220))
        list.dividerHeight=1
        val adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,choices)
        list.adapter=adapter
        list.setOnItemClickListener{_,_,pos,_->
            val v=choices[pos]
            val startPos=(editor.selectionStart-token.length).coerceAtLeast(0)
            editor.text.replace(startPos,editor.selectionStart,v)
            editor.setSelection((startPos+v.length).coerceAtMost(editor.length()))
            popup.dismiss()
        }
        popup.contentView=list
        popup.width=420
        popup.height=(choices.size.coerceAtMost(10)*48).coerceAtLeast(96)
        popup.isFocusable=true
        popup.isOutsideTouchable=true
        val loc=IntArray(2);editor.getLocationOnScreen(loc)
        val line=Math.max(0,editor.layout?.getLineForOffset(editor.selectionStart) ?: 0)
        val y=loc[1]+(editor.layout?.getLineTop(line) ?: 0)+editor.textSize.toInt()+28
        popup.showAtLocation(editor,Gravity.TOP or Gravity.START,loc[0]+24,y)
    }
    private fun highlight(){
        if(highlighting)return
        highlighting=true
        val e=editor.text
        val pos=editor.selectionStart
        e.getSpans(0,e.length,ForegroundColorSpan::class.java).forEach{e.removeSpan(it)}
        val text=e.toString()
        val patterns=listOf(
            Pattern.compile("(?i)\\b("+keywords.joinToString("|")+")\\b") to blue,
            Pattern.compile("'(?:''|[^'])*'") to orange,
            Pattern.compile("--[^\\n]*") to Color.rgb(180,172,160),
            Pattern.compile("\\b\\d+(?:\\.\\d+)?\\b") to green
        )
        for((p,col) in patterns)p.matcher(text).run{
            while(find())e.setSpan(ForegroundColorSpan(col),start(),end(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        editor.setSelection(pos.coerceIn(0,e.length));highlighting=false
    }

    override fun onDestroy(){if(::db.isInitialized&&db.isOpen)db.close();super.onDestroy()}
}
