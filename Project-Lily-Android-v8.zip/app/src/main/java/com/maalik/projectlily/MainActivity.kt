package com.maalik.projectlily

import android.app.*
import android.os.Bundle
import android.content.*
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.text.*
import android.text.style.ForegroundColorSpan
import android.view.*
import android.widget.*
import java.io.*
import java.util.regex.Pattern

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var status: TextView
    private lateinit var resultScroll: HorizontalScrollView
    private lateinit var resultTable: TableLayout
    private lateinit var db: SQLiteDatabase
    private lateinit var dbFile: File

    // Present only on the tablet layout (res/layout-sw600dp). Null on phones — every
    // use of it is guarded, so the same code runs on both layouts.
    private var schemaPanel: TextView? = null

    private val blue=Color.rgb(178,90,130)      // keywords — lily pink/plum
    private val purple=Color.rgb(139,123,168)   // reserved accent
    private val green=Color.rgb(111,143,113)    // numbers — sage
    private val orange=Color.rgb(180,130,90)    // strings — warm terracotta
    private val red=Color.rgb(192,96,91)        // errors
    private val white=Color.rgb(58,52,47)       // default text — soft charcoal
    private var highlighting=false

    private val keywords = listOf(
        "SELECT","FROM","WHERE","INSERT","INTO","VALUES","UPDATE","SET","DELETE",
        "CREATE","TABLE","DROP","ALTER","JOIN","INNER","LEFT","RIGHT","FULL","ON",
        "GROUP","BY","ORDER","ASC","DESC","HAVING","LIMIT","OFFSET","AS","DISTINCT",
        "AND","OR","NOT","NULL","IS","LIKE","IN","BETWEEN","UNION","ALL","CASE",
        "WHEN","THEN","ELSE","END","COUNT","SUM","AVG","MIN","MAX","PRIMARY","KEY",
        "FOREIGN","REFERENCES","DEFAULT","INDEX","VIEW","WITH","EXISTS"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        editor=findViewById(R.id.editor); status=findViewById(R.id.status)
        resultTable=findViewById(R.id.resultsTable); resultScroll=findViewById(R.id.resultScroll)
        schemaPanel=findViewById(R.id.schemaPanel)

        copyBundledDatabase()
        editor.setText("""-- Select a query and tap Run.
SELECT * FROM employee_demographics;

SELECT first_name, salary
FROM employee_salary
ORDER BY salary DESC;""")
        editor.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){}
            override fun afterTextChanged(e:Editable?){ highlight() }
        })

        findViewById<Button>(R.id.runButton).setOnClickListener{runSelectedOrAll()}
        findViewById<Button>(R.id.importButton).setOnClickListener{pickFile()}
        findViewById<Button>(R.id.schemaButton).setOnClickListener{showSchema()}
        findViewById<Button>(R.id.resetButton).setOnClickListener{resetDatabase()}
        findViewById<Button>(R.id.clearButton).setOnClickListener{editor.setText("")}

        refreshSchemaPanel()
    }

    private fun copyBundledDatabase() {
        dbFile=File(filesDir,"Parks_and_Recreation.db")
        if(!dbFile.exists()) assets.open("Parks_and_Recreation.db").use { i->dbFile.outputStream().use{i.copyTo(it)} }
        db=SQLiteDatabase.openOrCreateDatabase(dbFile,null)
    }

    private fun pickFile() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type="*/*"
        startActivityForResult(i,77)
    }

    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if(req!=77 || res!=RESULT_OK || data?.data==null)return
        try {
            val uri=data.data!!
            val name=uri.lastPathSegment?.lowercase()?:""
            val bytes=contentResolver.openInputStream(uri)!!.use{it.readBytes()}
            if(name.endsWith(".db") || name.endsWith(".sqlite") || name.endsWith(".sqlite3")) {
                db.close(); dbFile.delete(); dbFile.writeBytes(bytes)
                db=SQLiteDatabase.openOrCreateDatabase(dbFile,null)
                status.text="✓ Database imported"
                status.setTextColor(green)
                editor.setText("SELECT * FROM "+firstTable()+";")
                refreshSchemaPanel()
            } else {
                importSqlScript(bytes.toString(Charsets.UTF_8))
            }
        } catch(e:Exception) {
            showError(e.message ?: "Could not open file")
        }
    }

    // Imports a .sql file as a real practice database: it's executed against the
    // current database (so CREATE TABLE / INSERT statements actually build your
    // schema and data) and then loaded into the editor so you can see, tweak, and
    // re-run it. If anything fails, the script stays in the editor untouched so
    // you can fix and hit Run yourself — nothing here is a silent no-op.
    private fun importSqlScript(sql:String){
        editor.setText(sql)
        val statements=splitSql(sql).filter{stripLineComments(it).isNotBlank()}
        if(statements.isEmpty()){
            status.text="✓ SQL file loaded"
            status.setTextColor(green)
            return
        }
        try{
            var count=0
            db.beginTransaction()
            for(s in statements){
                if(!(s.trimStart().startsWith("SELECT",true)||s.trimStart().startsWith("WITH",true)||s.trimStart().startsWith("PRAGMA",true)))
                    db.execSQL(s)
                count++
            }
            db.setTransactionSuccessful();db.endTransaction()
            status.text="✓ Imported — $count statement(s) applied to your database"
            status.setTextColor(green)
            refreshSchemaPanel()
        }catch(e:Exception){
            try{db.endTransaction()}catch(_:Exception){}
            showError((e.message?:"SQL error")+" — fix it in the editor and tap Run")
        }
    }

    private fun splitSql(s:String):List<String>{
        val out=mutableListOf<String>(); var start=0; var quote:Char?=null
        for(i in s.indices){
            val c=s[i]
            if((c=='\''||c=='"') && (i==0||s[i-1]!='\\'))
                quote=if(quote==c)null else if(quote==null)c else quote
            if(c==';'&&quote==null){ if(s.substring(start,i).trim().isNotEmpty())out.add(s.substring(start,i).trim());start=i+1 }
        }
        if(s.substring(start).trim().isNotEmpty())out.add(s.substring(start).trim())
        return out
    }

    private fun stripLineComments(s:String):String{
        val sb=StringBuilder(); var quote:Char?=null; var i=0
        while(i<s.length){
            val c=s[i]
            if((c=='\''||c=='"') && (i==0||s[i-1]!='\\'))
                quote=if(quote==c)null else if(quote==null)c else quote
            if(quote==null && c=='-' && i+1<s.length && s[i+1]=='-'){
                while(i<s.length && s[i]!='\n')i++
                continue
            }
            sb.append(c); i++
        }
        return sb.toString()
    }

    private fun runSelectedOrAll(){
        val a=editor.selectionStart; val z=editor.selectionEnd
        val selected=if(a!=z)editor.text.substring(minOf(a,z),maxOf(a,z)).trim() else ""
        val statements=splitSql(if(selected.isNotEmpty())selected else editor.text.toString())
            .filter{stripLineComments(it).isNotBlank()}
        if(statements.isEmpty()){showError("Nothing to run");return}
        clearResults()
        try{
            var count=0
            var schemaChanged=false
            db.beginTransaction()
            for(s in statements){
                val head=s.trimStart()
                if(head.startsWith("SELECT",true)||head.startsWith("WITH",true)||head.startsWith("PRAGMA",true)){
                    db.rawQuery(s,null).use{renderCursor(it)}
                }else{
                    db.execSQL(s)
                    if(head.startsWith("CREATE",true)||head.startsWith("DROP",true)||head.startsWith("ALTER",true)) schemaChanged=true
                }
                count++
            }
            db.setTransactionSuccessful();db.endTransaction()
            status.text="✓ Ran $count statement(s)"+if(selected.isNotEmpty())" • selected only" else ""
            status.setTextColor(green)
            if(schemaChanged) refreshSchemaPanel()
        }catch(e:Exception){
            try{db.endTransaction()}catch(_:Exception){}
            showError(e.message?:"SQL error")
        }
    }

    private fun renderCursor(c:android.database.Cursor){
        val h=TableRow(this)
        for(i in 0 until c.columnCount)h.addView(cell(c.getColumnName(i),true))
        resultTable.addView(h)
        var n=0
        while(c.moveToNext()&&n<1000){
            val r=TableRow(this)
            for(i in 0 until c.columnCount)r.addView(cell(if(c.isNull(i))"NULL" else c.getString(i),false))
            resultTable.addView(r);n++
        }
    }

    private fun cell(v:String,head:Boolean):TextView{
        val t=TextView(this);t.text=v;t.textSize=12f
        t.setTextColor(if(head)Color.rgb(122,107,96) else white)
        t.setPadding(16,12,16,12)
        t.setBackgroundColor(if(head)Color.rgb(246,240,235) else Color.WHITE)
        return t
    }
    private fun clearResults(){resultTable.removeAllViews()}

    private fun schemaText():String{
        val b=StringBuilder()
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use{c->
            if(!c.moveToFirst()) b.append("No tables yet.\nImport a .db or .sql file,\nor run a CREATE TABLE.")
            else{
                c.moveToPrevious()
                while(c.moveToNext()){
                    val n=c.getString(0);b.append(n).append("\n")
                    db.rawQuery("PRAGMA table_info('$n')",null).use{p->while(p.moveToNext())b.append("   ").append(p.getString(1)).append("  ").append(p.getString(2)).append("\n")}
                    b.append("\n")
                }
            }
        }
        return b.toString().trimEnd()
    }

    private fun showSchema(){
        AlertDialog.Builder(this).setTitle("Database schema").setMessage(schemaText()).setPositiveButton("Close",null).show()
    }

    // Keeps the tablet sidebar's live schema view in sync. No-op on phones,
    // where schemaPanel is null and the "Tables" button dialog is used instead.
    private fun refreshSchemaPanel(){
        schemaPanel?.text=schemaText()
    }

    private fun firstTable():String{
        db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 1",null).use{c->if(c.moveToFirst())return c.getString(0)}
        return "employee_demographics"
    }

    private fun resetDatabase(){
        db.close();dbFile.delete();copyBundledDatabase();clearResults()
        editor.setText("SELECT * FROM employee_demographics;")
        status.text="Database reset";status.setTextColor(green)
        refreshSchemaPanel()
    }

    private fun showError(s:String){
        status.text="✕ $s";status.setTextColor(red)
    }

    private fun highlight(){
        if(highlighting)return
        highlighting=true
        val e=editor.text
        val pos=editor.selectionStart
        e.getSpans(0,e.length,ForegroundColorSpan::class.java).forEach{e.removeSpan(it)}
        val text=e.toString()
        val patterns=listOf(
            Pattern.compile("(?i)\\b("+keywords.joinToString("|")+")\\b") to blue,
            Pattern.compile("'(?:''|[^'])*'") to orange,
            Pattern.compile("--[^\\n]*") to Color.rgb(180,172,160),
            Pattern.compile("\\b\\d+(?:\\.\\d+)?\\b") to green
        )
        for((p,col) in patterns)p.matcher(text).run{
            while(find())e.setSpan(ForegroundColorSpan(col),start(),end(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        editor.setSelection(pos.coerceIn(0,e.length));highlighting=false
    }

    override fun onDestroy(){if(::db.isInitialized&&db.isOpen)db.close();super.onDestroy()}
}
