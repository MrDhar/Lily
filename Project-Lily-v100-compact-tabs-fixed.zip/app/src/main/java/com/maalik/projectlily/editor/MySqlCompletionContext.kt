package com.maalik.projectlily

internal enum class MySqlCompletionMode { TABLES, COLUMNS, KEYWORDS, FUNCTIONS, MIXED }

internal data class MySqlCompletionContext(
    val mode: MySqlCompletionMode,
    val token: String,
    val tokenStart: Int,
    val qualifier: String? = null,
    val manual: Boolean = false
)

internal object MySqlCompletionContextParser {
    private val identifier = Regex("[A-Za-z_][A-Za-z0-9_]*$")
    private val qualifier = Regex("([A-Za-z_][A-Za-z0-9_]*)\\.$")

    fun parse(before: String, cursor: Int, manual: Boolean): MySqlCompletionContext? {
        val clean = stripLiteralsAndComments(before)
        val tokenMatch = identifier.find(clean)
        val token = tokenMatch?.value.orEmpty()
        val tokenStart = cursor - token.length
        val prefix = clean.substring(0, tokenStart).trimEnd()
        val q = qualifier.find(prefix)?.groupValues?.getOrNull(1)
        if (q != null) return MySqlCompletionContext(MySqlCompletionMode.COLUMNS, token, tokenStart, q, manual)

        val beforeToken = clean.substring(0, tokenStart).trimEnd()
        val upperPrefix = beforeToken.uppercase()
        val tail = clean.trimEnd().uppercase()

        val tableClause = Regex("(?:^|\\s)(FROM|JOIN|UPDATE|INTO|REFERENCES|DESCRIBE|DESC)\\s+[A-Za-z_][A-Za-z0-9_]*$", RegexOption.IGNORE_CASE)
        val tableBoundary = Regex("(?:^|\\s)(FROM|JOIN|UPDATE|INTO|REFERENCES|DESCRIBE|DESC)\\s*$", RegexOption.IGNORE_CASE)
        if (tableBoundary.containsMatchIn(tail) || tableClause.containsMatchIn(tail)) {
            return MySqlCompletionContext(MySqlCompletionMode.TABLES, token, tokenStart, null, manual)
        }

        val columnBoundary = Regex("(?:^|\\s)(SELECT|WHERE|HAVING|ON|USING|ORDER\\s+BY|GROUP\\s+BY|SET|VALUES|PARTITION\\s+BY)\\s*$", RegexOption.IGNORE_CASE)
        if (columnBoundary.containsMatchIn(tail)) {
            return MySqlCompletionContext(MySqlCompletionMode.COLUMNS, token, tokenStart, null, manual)
        }

        val columnPhrase = Regex("\\b(SELECT|WHERE|HAVING|ON|ORDER\\s+BY|GROUP\\s+BY|SET|VALUES|PARTITION\\s+BY)\\s+[^;]*$", RegexOption.IGNORE_CASE)
        val afterSelect = Regex("\\bSELECT\\b[^;]*$", RegexOption.IGNORE_CASE).containsMatchIn(tail)
        if (columnPhrase.containsMatchIn(tail) || afterSelect) {
            return MySqlCompletionContext(MySqlCompletionMode.MIXED, token, tokenStart, null, manual)
        }

        if (manual) {
            return MySqlCompletionContext(MySqlCompletionMode.MIXED, token, tokenStart, null, manual)
        }

        // Auto-popup starts once the user has begun an identifier. This keeps the
        // editor quiet in prose/comments while still giving MySQL-like completion
        // immediately after a user types a meaningful SQL token.
        if (token.length >= 2) return MySqlCompletionContext(MySqlCompletionMode.MIXED, token, tokenStart, null, false)

        // One-character prefixes are useful after explicit clauses (handled above)
        // but shouldn't make the popup constantly flash during ordinary typing.
        if (upperPrefix.endsWith(".")) return MySqlCompletionContext(MySqlCompletionMode.COLUMNS, token, tokenStart, q, false)
        return null
    }

    private fun stripLiteralsAndComments(s: String): String {
        val out = StringBuilder(s.length)
        var quote: Char? = null
        var lineComment = false
        var blockComment = false
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val n = s.getOrNull(i + 1)
            if (lineComment) {
                if (c == '\n' || c == '\r') { lineComment = false; out.append(c) } else out.append(' ')
                i++; continue
            }
            if (blockComment) {
                if (c == '*' && n == '/') { blockComment = false; out.append("  "); i += 2 } else { out.append(if (c == '\n' || c == '\r') c else ' '); i++ }
                continue
            }
            if (quote != null) {
                if (c == quote) {
                    if (n == quote) { out.append("  "); i += 2; continue }
                    quote = null
                }
                out.append(if (c == '\n' || c == '\r') c else ' '); i++; continue
            }
            if (c == '-' && n == '-') { lineComment = true; out.append("  "); i += 2; continue }
            if (c == '/' && n == '*') { blockComment = true; out.append("  "); i += 2; continue }
            if (c == '\'' || c == '"' || c == '`') { quote = c; out.append(' '); i++; continue }
            out.append(c); i++
        }
        return out.toString()
    }
}
