package com.maalik.projectlily

import android.database.sqlite.SQLiteDatabase
import java.util.Locale

internal class MySqlCompletionEngine {
    data class Suggestion(val text: String, val kind: String, val score: Int)
    private val columnCache = HashMap<String, List<String>>()
    private var databaseIdentity = 0
    private var schemaVersion = -1

    fun complete(db: SQLiteDatabase, context: MySqlCompletionContext, source: String): List<Suggestion> {
        refreshCacheIdentity(db)
        val token = context.token
        val out = mutableListOf<Suggestion>()
        when (context.mode) {
            MySqlCompletionMode.TABLES -> out += tableSuggestions(db, token)
            MySqlCompletionMode.COLUMNS -> out += columnSuggestions(db, token, context.qualifier)
            MySqlCompletionMode.KEYWORDS -> out += keywordSuggestions(token)
            MySqlCompletionMode.FUNCTIONS -> out += functionSuggestions(token)
            MySqlCompletionMode.MIXED -> {
                val resolved = context.qualifier?.let { resolveAlias(source, it) }
                if (resolved != null) out += columnSuggestions(db, token, resolved)
                out += aliasSuggestions(source, token)
                out += columnSuggestions(db, token, null).take(8)
                out += tableSuggestions(db, token).take(5)
                out += keywordSuggestions(token).take(8)
                out += functionSuggestions(token).take(6)
            }
        }
        return out.sortedWith(compareBy<Suggestion>({ it.score }, { kindOrder(it.kind) }, { it.text.lowercase(Locale.US) }))
            .distinctBy { it.text.lowercase(Locale.US) }
            .take(12)
    }

    private fun kindOrder(kind: String): Int = when (kind) {
        "COL" -> 0
        "TABLE" -> 1
        "ALIAS" -> 2
        "FUNC" -> 3
        else -> 4
    }

    private fun tableSuggestions(db: SQLiteDatabase, token: String): List<Suggestion> {
        val out = mutableListOf<Suggestion>()
        val low = token.lowercase(Locale.US)
        db.rawQuery(
            "SELECT name FROM sqlite_master WHERE (type='table' OR type='view') AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val n = c.getString(0)
                if (low.isEmpty() || n.lowercase(Locale.US).startsWith(low)) {
                    out += Suggestion(n, "TABLE", if (n.equals(token, true)) 0 else 2)
                }
            }
        }
        return out
    }

    private fun columnSuggestions(db: SQLiteDatabase, token: String, tableOrAlias: String?): List<Suggestion> {
        val out = mutableListOf<Suggestion>()
        val low = token.lowercase(Locale.US)
        val tables = if (tableOrAlias != null) listOf(tableOrAlias) else tableNames(db)
        val seen = HashSet<String>()
        for (table in tables.take(80)) {
            for (column in columns(db, table)) {
                val key = column.lowercase(Locale.US)
                if (seen.add(key) && (low.isEmpty() || key.startsWith(low))) {
                    out += Suggestion(column, "COL", if (column.equals(token, true)) 0 else 3)
                }
            }
        }
        return out
    }

    private fun aliasSuggestions(source: String, token: String): List<Suggestion> {
        val out = mutableListOf<Suggestion>()
        val pattern = Regex("\\b(?:FROM|JOIN)\\s+[A-Za-z_][A-Za-z0-9_]*(?:\\s+AS)?\\s+([A-Za-z_][A-Za-z0-9_]*)", RegexOption.IGNORE_CASE)
        pattern.findAll(source).forEach { m ->
            val alias = m.groupValues.getOrNull(1).orEmpty()
            if (alias.isNotBlank() && alias.startsWith(token, true)) out += Suggestion(alias, "ALIAS", 2)
        }
        return out
    }

    private fun keywordSuggestions(token: String): List<Suggestion> {
        return MySqlCompletionCatalog.keywords.filter { token.isEmpty() || it.startsWith(token, true) }
            .map { Suggestion(it, "SQL", if (it.equals(token, true)) 0 else 6) }
    }

    private fun functionSuggestions(token: String): List<Suggestion> {
        return MySqlCompletionCatalog.functions.filter { token.isEmpty() || it.substringBefore('(').startsWith(token, true) }
            .map { Suggestion(it, "FUNC", if (it.substringBefore('(').equals(token, true)) 0 else 7) }
    }

    private fun tableNames(db: SQLiteDatabase): List<String> {
        val out = mutableListOf<String>()
        db.rawQuery(
            "SELECT name FROM sqlite_master WHERE (type='table' OR type='view') AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",
            null
        ).use { c -> while (c.moveToNext()) out += c.getString(0) }
        return out
    }

    private fun columns(db: SQLiteDatabase, table: String): List<String> {
        synchronized(columnCache) { columnCache[table]?.let { return it } }
        val out = mutableListOf<String>()
        try {
            db.rawQuery("PRAGMA table_info('${table.replace("'", "''")}')", null).use { c ->
                while (c.moveToNext()) out += c.getString(1)
            }
        } catch (_: Throwable) {
        }
        synchronized(columnCache) { columnCache[table] = out.toList() }
        return out
    }

    private fun resolveAlias(source: String, alias: String): String? {
        val q = Regex.escape(alias)
        val pattern = Regex("\\b(?:FROM|JOIN)\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s+AS)?\\s+$q\\b", RegexOption.IGNORE_CASE)
        return pattern.findAll(source).lastOrNull()?.groupValues?.getOrNull(1)
            ?: if (source.matches(Regex("(?s).*\\b(?:FROM|JOIN)\\s+${Regex.escape(alias)}\\b.*", RegexOption.IGNORE_CASE))) alias else null
    }

    private fun refreshCacheIdentity(db: SQLiteDatabase) {
        val identity = System.identityHashCode(db)
        val version = runCatching {
            db.rawQuery("PRAGMA schema_version", null).use { if (it.moveToFirst()) it.getInt(0) else -1 }
        }.getOrDefault(-1)
        if (identity != databaseIdentity || version != schemaVersion) {
            synchronized(columnCache) { columnCache.clear() }
            databaseIdentity = identity
            schemaVersion = version
        }
    }
}
