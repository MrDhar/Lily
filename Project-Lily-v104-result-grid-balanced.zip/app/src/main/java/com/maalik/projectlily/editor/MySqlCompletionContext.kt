package com.maalik.projectlily

import java.util.Locale

internal enum class MySqlCompletionMode { TABLES, COLUMNS, KEYWORDS, FUNCTIONS, MIXED }

internal data class MySqlCompletionContext(
    val mode: MySqlCompletionMode,
    val token: String,
    val tokenStart: Int,
    val qualifier: String? = null,
    val manual: Boolean = false
)

internal object MySqlCompletionContextParser {
    private val identifier = Regex("[A-Za-z_][A-Za-z0-9_]*$")
    private val qualifier = Regex("([A-Za-z_][A-Za-z0-9_]*)\\.$")

    fun parse(before: String, cursor: Int, manual: Boolean): MySqlCompletionContext? {
        val clean = stripLiteralsAndComments(before)
        val safeCursor = cursor.coerceIn(0, clean.length)
        val left = clean.substring(0, safeCursor)
        val tokenMatch = identifier.find(left)
        val token = tokenMatch?.value.orEmpty()
        val tokenStart = safeCursor - token.length
        val prefix = left.substring(0, tokenStart).trimEnd()
        val trimmed = left.trimEnd()
        val upper = trimmed.uppercase(Locale.US)

        val qualifierMatch = Regex("([A-Za-z_][A-Za-z0-9_]*)\\.$").find(prefix)
        if (qualifierMatch != null) {
            return MySqlCompletionContext(MySqlCompletionMode.COLUMNS, token, tokenStart, qualifierMatch.groupValues[1], manual)
        }

        fun clause(pattern: String): Boolean = Regex(pattern, RegexOption.IGNORE_CASE).containsMatchIn(upper)

        if (clause("(?:^|\\s)(FROM|JOIN|UPDATE|INTO|REFERENCES|DESCRIBE|DESC)\\s*$") ||
            clause("(?:^|\\s)(FROM|JOIN|UPDATE|INTO|REFERENCES|DESCRIBE|DESC)\\s+[A-Za-z_][A-Za-z0-9_]*$")) {
            return MySqlCompletionContext(MySqlCompletionMode.TABLES, token, tokenStart, null, manual)
        }

        if (clause("(?:^|\\s)(SELECT|WHERE|HAVING|ON|ORDER\\s+BY|GROUP\\s+BY|SET|VALUES|PARTITION\\s+BY|RETURNING)\\s*$")) {
            return MySqlCompletionContext(MySqlCompletionMode.COLUMNS, token, tokenStart, null, manual)
        }

        val hasSelectContext = Regex("\\bSELECT\\b[^;]*$", RegexOption.IGNORE_CASE).containsMatchIn(trimmed)
        val hasColumnContext = Regex("\\b(WHERE|HAVING|ON|ORDER\\s+BY|GROUP\\s+BY|SET|VALUES|PARTITION\\s+BY|RETURNING)\\b[^;]*$", RegexOption.IGNORE_CASE).containsMatchIn(trimmed)
        if (hasSelectContext || hasColumnContext) {
            return MySqlCompletionContext(MySqlCompletionMode.MIXED, token, tokenStart, null, manual)
        }

        if (manual) {
            return MySqlCompletionContext(MySqlCompletionMode.MIXED, token, tokenStart, null, true)
        }

        // Real IDE-style behavior: once the user has typed even a single identifier
        // character, offer completion instead of requiring an arbitrary two-character threshold.
        if (token.length >= 1) {
            return MySqlCompletionContext(MySqlCompletionMode.MIXED, token, tokenStart, null, false)
        }

        return null
    }

    private fun stripLiteralsAndComments(s: String): String {
        val out = StringBuilder(s.length)
        var quote: Char? = null
        var lineComment = false
        var blockComment = false
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val n = s.getOrNull(i + 1)
            if (lineComment) {
                if (c == '\n' || c == '\r') { lineComment = false; out.append(c) } else out.append(' ')
                i++; continue
            }
            if (blockComment) {
                if (c == '*' && n == '/') { blockComment = false; out.append("  "); i += 2 } else { out.append(if (c == '\n' || c == '\r') c else ' '); i++ }
                continue
            }
            if (quote != null) {
                if (c == quote) {
                    if (n == quote) { out.append("  "); i += 2; continue }
                    quote = null
                }
                out.append(if (c == '\n' || c == '\r') c else ' '); i++; continue
            }
            if (c == '-' && n == '-') { lineComment = true; out.append("  "); i += 2; continue }
            if (c == '/' && n == '*') { blockComment = true; out.append("  "); i += 2; continue }
            if (c == '\'' || c == '"' || c == '`') { quote = c; out.append(' '); i++; continue }
            out.append(c); i++
        }
        return out.toString()
    }
}
