package com.maalik.projectlily

import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import java.util.Locale

/**
 * Isolated MySQL-style autocomplete controller.
 *
 * The editor remains a normal EditText; this class only observes text/caret state,
 * builds suggestions in the existing background executor, and presents a compact
 * non-focusable popup. It does not intercept normal editor touch events.
 */
class EditorAutocomplete(private val activity: MainActivity) {
    private val editor get() = activity.editorForShortcuts()
    private val engine = MySqlCompletionEngine()
    private var popup: PopupWindow? = null
    private var tokenStart = -1
    private var items: List<MySqlCompletionEngine.Suggestion> = emptyList()
    private var selected = 0
    private var generation = 0
    private var trackingAttached = false
    private var updateRunnable: Runnable? = null
    private var debounceToken = 0

    fun update() {
        attachTrackingIfNeeded()
        scheduleUpdate(manual = false)
    }

    /** Manual completion, used by Ctrl/Cmd+Space without changing the editor path. */
    fun requestManual() {
        attachTrackingIfNeeded()
        scheduleUpdate(manual = true)
    }

    private fun scheduleUpdate(manual: Boolean) {
        // Editor callbacks can arrive several times for one keystroke (text, selection,
        // focus). Coalesce automatic requests so an older lookup cannot repeatedly cancel
        // the newer one or create unnecessary schema work. Manual completion is immediate.
        updateRunnable?.let { editor.removeCallbacks(it) }
        dismiss()
        val delay = if (manual) 0L else 45L
        val token = ++debounceToken
        val task = Runnable {
            if (token != debounceToken) return@Runnable
            updateRunnable = null
            updateInternal(manual)
        }
        updateRunnable = task
        editor.postDelayed(task, delay)
    }

    private fun updateInternal(manual: Boolean) {
        val g = ++generation
        if (!editor.hasFocus() || !activity.hasOpenDatabaseForAutocomplete()) return
        val cursor = editor.selectionStart.coerceIn(0, editor.length())
        if (editor.selectionStart != editor.selectionEnd) return
        val source = editor.text.toString()
        val before = source.substring(0, cursor)
        val context = MySqlCompletionContextParser.parse(before, cursor, manual) ?: return
        val snapshot = source
        val db = activity.databaseForAutocompleteDirect()
        activity.backgroundExecutorForAutocompleteDirect().execute {
            val found = try {
                engine.complete(db, context, source)
            } catch (_: Throwable) {
                emptyList()
            }
            val result = found.distinctBy { it.text.lowercase(Locale.US) }.take(12)
            activity.runOnUiThread {
                if (g != generation || result.isEmpty() || !editor.hasFocus() || editor.windowToken == null) return@runOnUiThread
                if (editor.selectionStart != cursor || editor.selectionEnd != cursor) return@runOnUiThread
                if (editor.text.toString() != snapshot) return@runOnUiThread
                show(result, context.tokenStart)
            }
        }
    }

    private fun attachTrackingIfNeeded() {
        if (trackingAttached) return
        trackingAttached = true
        editor.viewTreeObserver.addOnScrollChangedListener {
            if (popup?.isShowing == true) editor.post { position() }
        }
        editor.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (popup?.isShowing == true) editor.post { position() }
        }
    }

    private fun show(found: List<MySqlCompletionEngine.Suggestion>, start: Int) {
        dismiss()
        items = found
        selected = 0
        tokenStart = start
        val list = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                activity.dpForAutocompleteDirect(3), activity.dpForAutocompleteDirect(3),
                activity.dpForAutocompleteDirect(3), activity.dpForAutocompleteDirect(3)
            )
            background = activity.roundedForAutocompleteDirect(Color.rgb(20, 22, 29), 1, Color.rgb(53, 48, 58), 8f)
        }
        found.forEachIndexed { i, item ->
            val row = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(activity.dpForAutocompleteDirect(5), 0, activity.dpForAutocompleteDirect(7), 0)
                isClickable = true
            }
            fun paint(on: Boolean) {
                row.background = activity.roundedForAutocompleteDirect(
                    if (on) Color.rgb(48, 42, 52) else Color.rgb(28, 30, 38), 0, Color.TRANSPARENT, 5f
                )
            }
            paint(i == 0)
            val badge = TextView(activity).apply {
                text = item.kind
                textSize = 6.7f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.rgb(176, 178, 187))
                gravity = Gravity.CENTER
                setPadding(activity.dpForAutocompleteDirect(4), 0, activity.dpForAutocompleteDirect(4), 0)
                background = activity.roundedForAutocompleteDirect(Color.rgb(39, 40, 47), 0, Color.TRANSPARENT, 4f)
            }
            val label = TextView(activity).apply {
                text = item.text
                textSize = 11.5f
                setTextColor(activity.whiteForAutocompleteDirect())
                gravity = Gravity.CENTER_VERTICAL
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
                setPadding(activity.dpForAutocompleteDirect(7), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, -1, 1f)
            }
            row.addView(badge, LinearLayout.LayoutParams(-2, activity.dpForAutocompleteDirect(18)))
            row.addView(label)
            row.setOnClickListener { selected = i; accept() }
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                row.setOnHoverListener { v, e ->
                    when (e.actionMasked) {
                        android.view.MotionEvent.ACTION_HOVER_ENTER -> {
                            selected = i
                            v.setBackgroundColor(Color.rgb(48, 42, 52))
                        }
                        android.view.MotionEvent.ACTION_HOVER_EXIT -> {
                            if (i != selected) v.setBackgroundColor(Color.rgb(28, 30, 38))
                        }
                    }
                    false
                }
            }
            list.addView(row, LinearLayout.LayoutParams(-1, activity.dpForAutocompleteDirect(27)).apply {
                if (i > 0) topMargin = activity.dpForAutocompleteDirect(2)
            })
        }
        popup = PopupWindow(activity).apply {
            contentView = list
            width = activity.dpForAutocompleteDirect(250)
            height = activity.dpForAutocompleteDirect(6 + 27 * found.size + 2 * (found.size - 1))
            isFocusable = false
            isTouchable = true
            isOutsideTouchable = true
            inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
            softInputMode = android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
            setClippingEnabled(false)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            elevation = activity.dpForAutocompleteDirect(7).toFloat()
        }
        editor.post { position() }
    }

    private fun position() {
        val p = popup ?: return
        if (!editor.isShown || editor.windowToken == null) return
        val layout = editor.layout ?: return
        val pos = editor.selectionStart.coerceIn(0, editor.length())
        val line = layout.getLineForOffset(pos)
        val baseline = layout.getLineBaseline(line)
        val caretX = editor.paddingLeft + layout.getPrimaryHorizontal(pos).toInt()
        val caretY = baseline - editor.scrollY + editor.paddingTop
        val loc = IntArray(2)
        editor.getLocationOnScreen(loc)
        val root = activity.window.decorView
        val rootLoc = IntArray(2)
        root.getLocationOnScreen(rootLoc)
        val sw = root.width.coerceAtLeast(activity.resources.displayMetrics.widthPixels)
        val sh = root.height.coerceAtLeast(activity.resources.displayMetrics.heightPixels)
        val w = p.width
        val h = p.height
        // PopupWindow coordinates are relative to the supplied root/window, not the
        // absolute physical screen. Converting here keeps the completion list visible
        // on immersive tablet layouts and after inset changes.
        var px = loc[0] - rootLoc[0] + caretX
        var py = loc[1] - rootLoc[1] + caretY + activity.dpForAutocompleteDirect(6)
        val margin = activity.dpForAutocompleteDirect(8)
        if (px + w > sw - margin) px = sw - w - margin
        if (px < margin) px = margin
        if (py + h > sh - margin) {
            py = loc[1] - rootLoc[1] + caretY - h - activity.dpForAutocompleteDirect(4)
        }
        if (py < margin) py = margin
        try {
            if (!p.isShowing) {
                p.showAtLocation(root, Gravity.TOP or Gravity.START, px, py)
            } else {
                p.update(px, py, w, h)
            }
        } catch (_: WindowManager.BadTokenException) {
            dismiss()
        } catch (_: IllegalArgumentException) {
            dismiss()
        }
    }

    fun handleNavigationKey(code: Int): Boolean {
        if (popup == null) return false
        return when (code) {
            KeyEvent.KEYCODE_DPAD_DOWN -> { move(1); true }
            KeyEvent.KEYCODE_DPAD_UP -> { move(-1); true }
            KeyEvent.KEYCODE_ESCAPE -> { dismiss(); true }
            KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_ENTER -> { accept(); true }
            else -> false
        }
    }

    private fun move(delta: Int) {
        val list = popup?.contentView as? LinearLayout ?: return
        if (items.isEmpty()) return
        selected = (selected + delta).mod(items.size)
        for (i in 0 until list.childCount) {
            list.getChildAt(i).background = activity.roundedForAutocompleteDirect(
                if (i == selected) Color.rgb(48, 42, 52) else Color.rgb(28, 30, 38),
                0, Color.TRANSPARENT, 5f
            )
        }
    }

    private fun accept() {
        val item = items.getOrNull(selected) ?: return
        val start = tokenStart
        val end = editor.selectionStart
        if (start !in 0..end || end > editor.length()) {
            dismiss(); return
        }
        try {
            editor.text.replace(start, end, item.text)
            val caret = if (item.text.endsWith("()")) {
                (start + item.text.length - 1).coerceAtMost(editor.length())
            } else {
                (start + item.text.length).coerceAtMost(editor.length())
            }
            editor.setSelection(caret)
        } catch (_: Throwable) {
        }
        dismiss()
        editor.requestFocus()
    }

    fun isVisible(): Boolean = popup?.isShowing == true

    fun dismiss() {
        generation++
        debounceToken++
        updateRunnable?.let { editor.removeCallbacks(it) }
        updateRunnable = null
        popup?.dismiss()
        popup = null
        tokenStart = -1
        items = emptyList()
        selected = 0
    }
}
