# Project Lily — v71 Import Reliability

Native offline Android SQLite SQL editor/learning app.

This revision is based on the v69 sidebar-tree source and fixes SQL import compatibility issues without replacing the existing UI architecture:
- escaped double-quoted identifiers such as `\"employees\"`
- SQL Server `[dbo].[Table]` identifiers
- SQL Server `N'Unicode strings'`
- PostgreSQL `public.table` qualifiers
- PostgreSQL `SERIAL PRIMARY KEY` normalization
- MySQL backtick identifiers
- semicolonless INSERT streams and INSERT-only schema inference
- multiline and multi-row INSERT imports

Supported import extensions remain `.sql`, `.txt`, `.db`, `.sqlite`, and `.sqlite3`.
