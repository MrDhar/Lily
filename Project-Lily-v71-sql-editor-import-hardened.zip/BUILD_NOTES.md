# Project Lily v71 — SQL editor polish + import hardening

Base: v70 SQL editor polish/import build.

Changes in this release:
- Active database state uses a neutral graphite selection treatment with a bold database name; no pink selection background.
- Keeps long-press database deletion and adds a compact mouse right-click Delete action for user databases; bundled Parks & Recreation remains protected.
- Editor context menu remains custom and macOS-inspired; mouse pointer styling is retained where Android exposes a pointer.
- Adds a compact Current Statement indicator in the editor toolbar.
- Ctrl/Cmd+Enter executes the statement under the caret; Ctrl/Cmd+Shift+Enter executes the broader script/selection action.
- Keeps the compact lightning Run and secondary Current Statement controls visually distinct.
- Adds lightweight ~150 ms content transitions for query/result tab switches while leaving database/query work off the UI thread.
- Hardens SQL import against control characters and fixes a critical type-normalization bug where INTEGER could be transformed into invalid SQL such as `INTEGER EGER`.
- Numeric type normalization now preserves the whitespace before constraints such as `NULL`/`NOT NULL`.
- Continues flattening common `public`/`dbo` qualifiers for SQLite imports and supports MySQL/SQL Server/PostgreSQL-style INSERT forms.
- Zoom behavior is unchanged except that no zoom percentage toast is shown.

The importer is intentionally SQLite-native: vendor-specific DDL is normalized only where it can be mapped safely, while unsupported dump-control statements are skipped rather than executed.
