# Project Lily — SQL Editor

A compact dark, macOS-inspired SQLite SQL editor for Android with desktop-style database navigation, query tabs, result grids, imports/exports, and lightweight interactions.

## Current release

**v71 — SQL editor polish + import hardening**

- Clear neutral active-database state with bold database name
- Long-press and compact mouse right-click database deletion
- macOS-inspired editor context menu and pointer treatment
- Current-statement execution button and caret statement indicator
- Ctrl/Cmd+Enter for current statement; Ctrl/Cmd+Shift+Enter for broader execution
- Responsive background query/import work
- Lightweight tab/sidebar transitions
- No zoom percentage toast
- Hardened SQL import for common MySQL, PostgreSQL, and SQL Server dump syntax

Build with the repository Android Gradle workflow.
