package com.maalik.projectlily
import android.app.*
import android.animation.ValueAnimator
import android.os.Bundle
import android.os.CancellationSignal
import android.content.*
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.util.JsonReader
import android.util.JsonToken
import org.json.JSONArray
import org.json.JSONObject
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.provider.Settings
import android.text.*
import android.text.style.ForegroundColorSpan
import android.text.style.ClickableSpan
import android.text.Spanned
import android.text.SpannableStringBuilder
import android.text.method.LinkMovementMethod
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import java.io.*
import java.util.LinkedHashMap
import java.util.ArrayDeque
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.min
import kotlin.math.roundToInt
class VirtualResultGridView(
    context: Context,
    private val rows: List<List<String>>,
    private val truncated: Boolean,
    private val onHeaderClick: ((Int) -> Unit)? = null,
    private val onCellClick: ((String) -> Unit)? = null,
    initialZoom: Float = 1f,
    private val onZoomChanged: ((Float) -> Unit)? = null
) : View(context) {
    private val density = resources.displayMetrics.density
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f * density; color = Color.rgb(231,227,233); typeface = android.graphics.Typeface.MONOSPACE }
    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f * density; color = Color.rgb(185,181,191); typeface = android.graphics.Typeface.MONOSPACE }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(48,51,62); strokeWidth = density }
    private val headerBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(28,31,39) }
    private val rowBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(24,26,33) }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f * density; color = Color.rgb(140,136,148) }
    private val baseRowHeight = (34f * density).toInt().coerceAtLeast(28)
    private val baseHeaderHeight = (38f * density).toInt().coerceAtLeast(32)
    private val rowHeight get() = (baseRowHeight * zoom).toInt().coerceAtLeast((24*density).toInt())
    private val headerHeight get() = (baseHeaderHeight * zoom).toInt().coerceAtLeast((28*density).toInt())
    private var scrollXpx = 0f
    private var scrollYpx = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var lastX = 0f
    private var lastY = 0f
    private var colWidths = IntArray(0)
    private var contentWidth = 0
    private var zoom = initialZoom.coerceIn(0.85f,1.30f)
    private val scaleDetector = android.view.ScaleGestureDetector(context, object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){ override fun onScale(d:android.view.ScaleGestureDetector):Boolean{ setZoom(zoom*d.scaleFactor); return true } })
    private var resizingColumn = -1
    private var resizeStartX = 0f
    private var resizeStartWidth = 0
    fun setZoom(value: Float) { zoom = value.coerceIn(0.85f, 1.30f); calculateWidths(); requestLayout(); invalidate(); onZoomChanged?.invoke(zoom) }
    init {
        isFocusable = true
        setBackgroundColor(Color.rgb(15,16,21))
        calculateWidths()
    }
    private fun calculateWidths() {
        if (rows.isEmpty()) return
        val cols = rows.maxOf { it.size }
        colWidths = IntArray(cols)
        for (c in 0 until cols) {
            var maxChars = 8
            val sampleEnd = min(rows.size, 1001)
            for (r in 0 until sampleEnd) maxChars = maxOf(maxChars, rows[r].getOrElse(c) { "" }.length.coerceAtMost(42))
            colWidths[c] = ((maxChars * 7.2f + 28f) * density * zoom).toInt().coerceIn((88*density).toInt(), (360*density).toInt())
        }
        contentWidth = colWidths.sum()
    }
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val desiredRows = rows.size.coerceAtMost(1001) + if (truncated) 1 else 0
        val desiredH = headerHeight + desiredRows * rowHeight
        val h = when (MeasureSpec.getMode(heightMeasureSpec)) {
            MeasureSpec.EXACTLY, MeasureSpec.AT_MOST -> MeasureSpec.getSize(heightMeasureSpec)
            else -> desiredH
        }
        setMeasuredDimension(w, h)
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (rows.isEmpty()) return
        val maxScrollX = (contentWidth - width).coerceAtLeast(0).toFloat()
        val footer = if (truncated) (rowHeight + 12 * density).toInt() else 0
        val contentHeight = headerHeight + (rows.size - 1).coerceAtLeast(0) * rowHeight + footer
        val maxScrollY = (contentHeight - height).coerceAtLeast(0).toFloat()
        scrollXpx = scrollXpx.coerceIn(0f, maxScrollX)
        scrollYpx = scrollYpx.coerceIn(0f, maxScrollY)
        // Body scrolls in both directions. The header is drawn separately so it
        // remains pinned while vertically scrolling, like a desktop data grid.
        canvas.save()
        canvas.clipRect(0f, headerHeight.toFloat(), width.toFloat(), height.toFloat())
        canvas.translate(-scrollXpx, -scrollYpx)
        var x=0f
        for(c in colWidths.indices){
            canvas.drawLine(x + colWidths[c], headerHeight.toFloat(), x + colWidths[c], contentHeight.toFloat(), linePaint)
            x += colWidths[c]
        }
        val firstRow=maxOf(1,1+((scrollYpx-headerHeight).toInt().coerceAtLeast(0)/rowHeight))
        val lastRow=min(rows.size,firstRow+height/rowHeight+4)
        for(r in firstRow until lastRow){
            val top=headerHeight+(r-1)*rowHeight
            if(r%2==0)canvas.drawRect(0f,top.toFloat(),contentWidth.toFloat(),(top+rowHeight).toFloat(),rowBg)
            x=0f
            for(c in colWidths.indices){
                canvas.drawText(ellipsize(rows[r].getOrElse(c){"NULL"},c),x+14*density,top+rowHeight/2f+4*density,textPaint)
                canvas.drawLine(x+colWidths[c],top.toFloat(),x+colWidths[c],(top+rowHeight).toFloat(),linePaint);x+=colWidths[c]
            }
            canvas.drawLine(0f,(top+rowHeight).toFloat(),contentWidth.toFloat(),(top+rowHeight).toFloat(),linePaint)
        }
        if(truncated){
            val footerY=headerHeight+(rows.size-1)*rowHeight
            canvas.drawText("Showing first ${rows.size-1} rows · result continues",14*density,footerY+rowHeight/2f+4*density,hintPaint)
        }
        canvas.restore()
        canvas.save()
        canvas.clipRect(0f,0f,width.toFloat(),headerHeight.toFloat())
        canvas.translate(-scrollXpx,0f)
        canvas.drawRect(0f,0f,contentWidth.toFloat(),headerHeight.toFloat(),headerBg)
        x=0f
        for(c in colWidths.indices){
            canvas.drawText(ellipsize(rows[0].getOrElse(c){""},c),x+14*density,headerHeight/2f+5*density,headerPaint)
            canvas.drawLine(x+colWidths[c],0f,x+colWidths[c],headerHeight.toFloat(),linePaint);x+=colWidths[c]
        }
        canvas.drawLine(0f,headerHeight.toFloat(),contentWidth.toFloat(),headerHeight.toFloat(),linePaint)
        canvas.restore()
    }
    private fun ellipsize(value: String, column: Int): String {
        val maxChars = ((colWidths.getOrElse(column){120} - 28*density*zoom) / (7.2f*density*zoom)).toInt().coerceAtLeast(6)
        return if (value.length > maxChars) value.take(maxChars - 1) + "…" else value
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if(scaleDetector.isInProgress)return true
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y; lastX = event.x; lastY = event.y; moved = false
                val cx = event.x + scrollXpx
                var x = 0f
                for (i in colWidths.indices) {
                    x += colWidths[i]
                    if (kotlin.math.abs(cx - x) <= 10*density) {
                        resizingColumn = i; resizeStartX = cx; resizeStartWidth = colWidths[i]; break
                    }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX; val dy = event.y - lastY
                if (kotlin.math.abs(event.x-downX) > 8*density || kotlin.math.abs(event.y-downY) > 8*density) moved = true
                if (resizingColumn >= 0) {
                    val cx = event.x + scrollXpx
                    colWidths[resizingColumn] = (resizeStartWidth + (cx - resizeStartX)).toInt().coerceIn((88*density).toInt(), (420*density).toInt())
                    contentWidth = colWidths.sum(); invalidate(); return true
                }
                scrollXpx -= dx; scrollYpx -= dy; lastX = event.x; lastY = event.y; invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                if (resizingColumn >= 0) { resizingColumn = -1; performClick(); return true }
                if (!moved) {
                    val cx = downX + scrollXpx; val cy = downY + scrollYpx
                    if (cy < headerHeight && cx >= 0) {
                        var x = 0f
                        for (i in colWidths.indices) { x += colWidths[i]; if (cx <= x) { onHeaderClick?.invoke(i); break } }
                    } else if (cy >= headerHeight && cy < headerHeight + (rows.size-1)*rowHeight) {
                        val row = 1 + ((cy - headerHeight) / rowHeight).toInt()
                        if (row in 1 until rows.size) {
                            var x = 0f
                            for (i in colWidths.indices) { x += colWidths[i]; if (cx <= x) { onCellClick?.invoke(rows[row].getOrElse(i){"NULL"}); break } }
                        }
                    }
                }
                performClick(); return true
            }
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
class LineNumberEditText(context:Context, attrs:android.util.AttributeSet?=null):android.widget.EditText(context,attrs){    override fun onSelectionChanged(selStart:Int,selEnd:Int){
        super.onSelectionChanged(selStart,selEnd)
        (context as? MainActivity)?.let {
            it.onEditorSelectionChanged()
            if(!it.shouldKeepAutocompleteVisible()) it.dismissAutocompleteFromEditor()
        }
    }
    private val paint=android.graphics.Paint().apply{color=Color.rgb(91,95,108);textSize=36f;typeface=android.graphics.Typeface.MONOSPACE}
    init{
        // SQL editors should not impose a practical line limit. Keep the text vertically
        // scrollable while preserving a fixed-width monospace editor (no surprise wrapping).
        setMaxLines(Int.MAX_VALUE)
        setHorizontallyScrolling(true)
        setVerticalScrollBarEnabled(true)
        overScrollMode=android.view.View.OVER_SCROLL_IF_CONTENT_SCROLLS
        setPadding(58,paddingTop,paddingRight,paddingBottom)
        setBackgroundColor(Color.TRANSPARENT)
        setTextColor(Color.rgb(231,227,233))
        setOnFocusChangeListener{_,_->invalidate()}
        setOnScrollChangeListener{_,_,_,_,_->invalidate()}
    }
    override fun onDraw(canvas:android.graphics.Canvas){
        val lineH=lineHeight.toFloat().coerceAtLeast(1f)
        val current=layout?.getLineForOffset(selectionStart)?:0
        val top=current*lineH-scrollY
        val hi=android.graphics.Paint().apply{color=Color.rgb(28,29,32)}
        canvas.drawRect(0f,top,width.toFloat(),top+lineH,hi)
        val first=(scrollY/lineH).toInt().coerceAtLeast(0)
        val last=((scrollY+height)/lineH).toInt()+1
        paint.textSize=textSize*0.78f
        for(line in first..last){
            val y=(line+1)*lineH-scrollY
            canvas.drawText((line+1).toString(),8f,y,paint)
        }
        super.onDraw(canvas)
    }
}
private class LoadingDotsView(context:Context):View(context){
        private val colors=intArrayOf(Color.rgb(190,166,218),Color.rgb(232,157,207),Color.rgb(173,155,220))
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        private var animator:ValueAnimator?=null
        private var phase=0f
        private var complete=false
        init{setLayerType(View.LAYER_TYPE_SOFTWARE,null)}
        override fun onDraw(canvas:Canvas){
            super.onDraw(canvas)
            // Keep every animated circle inside the view bounds; the old fixed 54dp
            // canvas could visually clip a dot at the edge on some densities.
            val centerY=height/2f;val gap=dpLocal(18);val base=dpLocal(5);val side=base*1.28f
            val cx=width/2f
            canvas.save()
            canvas.clipRect(0f,0f,width.toFloat(),height.toFloat())
            for(i in 0..2){
                val distance=(phase-i*0.333f).let{var x=it%1f;if(x<0)x+=1f;x}
                val pulse=if(complete)0f else (1f-kotlin.math.abs(distance-0.5f)*2f).coerceIn(0f,1f)
                val radius=base*(0.72f+0.48f*pulse)
                paint.color=colors[i]
                paint.alpha=(105+150*pulse).toInt().coerceIn(0,255)
                val x=(cx+(i-1)*gap).coerceIn(side,width-side)
                canvas.drawCircle(x,centerY,radius.coerceAtMost(side),paint)
            }
            canvas.restore()
        }
        private fun dpLocal(v:Int)=v*resources.displayMetrics.density
        override fun onDetachedFromWindow(){animator?.cancel();animator=null;super.onDetachedFromWindow()}
        fun start(){
            complete=false;animator?.cancel();animator=ValueAnimator.ofFloat(0f,1f).apply{duration=1150;interpolator=LinearInterpolator();repeatCount=ValueAnimator.INFINITE;addUpdateListener{phase=it.animatedValue as Float;invalidate()};start()}
        }
        fun stop(){animator?.cancel();animator=null;complete=false;invalidate()}
        fun showComplete(){animator?.cancel();animator=null;complete=true;phase=.5f;invalidate()}
        fun showError(){animator?.cancel();animator=null;complete=false;phase=.5f;paint.alpha=210;invalidate()}
    }
class MainActivity : Activity() {
    private var schemaFilter: String = ""
    private var editorZoom = 1.0f
    private var resultZoom = 1.0f
    private var editorBaseSp = 13f
    private var currentStatementIndicator: TextView? = null
    // Android OnContextClickListener supplies only the View, so remember the last
    // mouse position from hover events for accurate desktop-style context menus.
    private var lastEditorPointerX = 0f
    private var lastEditorPointerY = 0f
    private fun applyEditorZoom(z: Float, notify: Boolean = false) {
        editorZoom = z.coerceIn(0.85f, 1.30f)
        editor.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, editorBaseSp * editorZoom)
    }
    private fun applyResultZoom(z: Float, notify: Boolean = false) {
        resultZoom = z.coerceIn(0.85f, 1.30f)
        resultContainer.findVirtualResultGrids().forEach { it.setZoom(resultZoom) }
    }
    private fun View.findVirtualResultGrids(): List<VirtualResultGridView> {
        val out = ArrayList<VirtualResultGridView>()
        fun walk(v: View) {
            if (v is VirtualResultGridView) out.add(v)
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(this); return out
    }
    private lateinit var editor: LineNumberEditText
    private lateinit var scriptTabStrip: LinearLayout
    private lateinit var status: TextView
    private lateinit var tabStrip: LinearLayout
    private lateinit var resultContainer: FrameLayout
    private lateinit var resultArea: View
    private lateinit var editorSurface: View
    private lateinit var resizeHandle: View
    private lateinit var db: SQLiteDatabase
    private lateinit var dbFile: File
    private var schemaPanel: LinearLayout? = null
    private var sidebarPanel: View? = null
    private var sidebarDivider: View? = null
    private var databaseSwitcherPopup: PopupWindow? = null
    private var importBrowserDialog: Dialog? = null
    private var importBrowserList: LinearLayout? = null
    private var importBrowserTitle: TextView? = null
    private var importBrowserPath: TextView? = null
    private val importBrowserStack = ArrayDeque<String>()
    private var importBrowserRoot: Uri? = null
    private var sidebarOpen = true
    private var focusMode = false
    private var focusSidebarWasOpen = false
    private var switchingScriptTab = false
    private data class ScriptTab(var name:String, var text:String, var selection:Int=0, var dirty:Boolean=false)
    private val scriptTabs=mutableListOf<ScriptTab>()
    private var activeScriptTab=0
    @Volatile private var importCancelled = false
    @Volatile private var importInProgress = false
    @Volatile private var queryRunning = false
    @Volatile private var queryCancelled = false
    @Volatile private var activeQueryCancellation: CancellationSignal? = null
    private var importDialog: Dialog? = null
    private var importDots: LoadingDotsView? = null
    private var importCancelButton: Button? = null
    private var importTitleView: TextView? = null
    private var importDetailView: TextView? = null
    private var highlighting = false
    private var autocompletePopup: PopupWindow? = null
    private var autocompleteTokenStart = -1
    private var suppressAutocompleteDismiss = false
    private var currentChallenge = -1
    private var bundledAsset = "Parks_and_Recreation.db"
    private val challengeSql = listOf(
        "SELECT * FROM employee_demographics WHERE age > 40;",
        "SELECT d.first_name, d.last_name, s.salary FROM employee_demographics d JOIN employee_salary s ON d.employee_id=s.employee_id;",
        "SELECT first_name, salary FROM employee_salary ORDER BY salary DESC LIMIT 3;",
        "SELECT gender, COUNT(*) AS total FROM employee_demographics GROUP BY gender;",
        "SELECT * FROM parks_departments ORDER BY department_id;"
    )
    private val prefs by lazy { getSharedPreferences("lily", MODE_PRIVATE) }
    private val history = mutableListOf<String>()
    private val snippets = linkedMapOf<String, String>()
    private val blue=Color.rgb(224,225,227); private val purple=Color.rgb(184,186,190)
    private val green=Color.rgb(143,175,146); private val orange=Color.rgb(190,192,196)
    private val red=Color.rgb(255,107,100); private val white=Color.rgb(231,227,233)
    private val keywords = listOf("SELECT","FROM","WHERE","INSERT","INTO","VALUES","UPDATE","SET","DELETE","CREATE","TABLE","DROP","ALTER","JOIN","INNER","LEFT","RIGHT","FULL","OUTER","CROSS","NATURAL","ON","USING","GROUP","BY","ORDER","ASC","DESC","HAVING","LIMIT","OFFSET","AS","DISTINCT","AND","OR","NOT","NULL","IS","LIKE","GLOB","REGEXP","IN","BETWEEN","ESCAPE","UNION","INTERSECT","EXCEPT","ALL","CASE","WHEN","THEN","ELSE","END","COUNT","SUM","AVG","MIN","MAX","TOTAL","GROUP_CONCAT","OVER","PARTITION","ROWS","RANGE","GROUPS","UNBOUNDED","PRECEDING","FOLLOWING","CURRENT","ROW","ROW_NUMBER","RANK","DENSE_RANK","NTILE","LAG","LEAD","FIRST_VALUE","LAST_VALUE","NTH_VALUE","FILTER","WITH","RECURSIVE","EXISTS","RETURNING","PRIMARY","KEY","FOREIGN","REFERENCES","DEFAULT","UNIQUE","CHECK","CONSTRAINT","AUTOINCREMENT","GENERATED","ALWAYS","STORED","VIRTUAL","WITHOUT","ROWID","STRICT","COLLATE","INDEX","VIEW","TRIGGER","BEFORE","AFTER","INSTEAD","OF","FOR","EACH","BEGIN","CASCADE","RESTRICT","IF","RENAME","COLUMN","TO","ADD","TEMP","TEMPORARY","TRANSACTION","COMMIT","ROLLBACK","SAVEPOINT","RELEASE","ATTACH","DETACH","EXPLAIN","QUERY","PLAN","ANALYZE","VACUUM","PRAGMA","CAST","COALESCE","IFNULL","NULLIF","TRUE","FALSE","CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP")
    data class ResultTab(val button: Button, val closeButton: Button, val container: LinearLayout, val view: View, val isError: Boolean, val csv: List<List<String>>?, val title: String, val errorMessage: String? = null, val query: String? = null)
    private val tabs=mutableListOf<ResultTab>(); private var activeTab=-1; private var pendingCsv:String?=null
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main); enterImmersiveMode()
        editor=findViewById(R.id.editor); scriptTabStrip=findViewById(R.id.scriptTabStrip); editorBaseSp=13f; currentStatementIndicator=findViewById(R.id.currentStatementIndicator); setupScriptTabs(); val editorZoomDetector=android.view.ScaleGestureDetector(this,object:android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){override fun onScale(d:android.view.ScaleGestureDetector):Boolean{applyEditorZoom(editorZoom*d.scaleFactor,false);return true};override fun onScaleEnd(d:android.view.ScaleGestureDetector){}}); editor.setOnTouchListener{_,e->editorZoomDetector.onTouchEvent(e);false}; editor.setOnKeyListener{_,keyCode,event->if(event.action==KeyEvent.ACTION_DOWN&&keyCode==KeyEvent.KEYCODE_ENTER&&(event.isCtrlPressed||event.isMetaPressed)){if(event.isShiftPressed)runSelectedOrAll(false)else runSelectedOrAll(true);true}else false}; status=findViewById(R.id.status); tabStrip=findViewById(R.id.tabStrip); resultContainer=findViewById(R.id.resultContainer); resultArea=findViewById(R.id.resultArea); editorSurface=findViewById(R.id.editorSurface); resizeHandle=findViewById(R.id.resizeHandle); schemaPanel=findViewById(R.id.schemaPanel); sidebarPanel=findViewById(R.id.sidebarPanel); sidebarDivider=findViewById(R.id.sidebarDivider)
        loadPrefs(); openSavedOrBundledDatabase()
        val defaultSql="""-- Select a query and tap Run.
-- Select multiple statements to run only that selection.
SELECT * FROM employee_demographics;
SELECT first_name, salary
FROM employee_salary
ORDER BY salary DESC;"""
        restoreScriptTabs(defaultSql)
        editor.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){if(!switchingScriptTab&&scriptTabs.isNotEmpty()){scriptTabs[activeScriptTab].text=s?.toString().orEmpty();scriptTabs[activeScriptTab].selection=editor.selectionStart.coerceAtLeast(0);scriptTabs[activeScriptTab].dirty=true;renderScriptTabs()};updateAutocomplete()};override fun afterTextChanged(e:Editable?){highlight(); editor.invalidate()}})
        editor.setOnFocusChangeListener{_,hasFocus->if(!hasFocus)dismissAutocomplete()}
        // Keep Lily in control of the desktop-style editor context menu. Android's native selection toolbar (Translate/Cut/Copy/Paste/Share) would otherwise
        // appear beside our custom menu on mouse context-clicks.
        editor.customSelectionActionModeCallback=object:ActionMode.Callback{override fun onCreateActionMode(mode:ActionMode?,menu:Menu?)=false;override fun onPrepareActionMode(mode:ActionMode?,menu:Menu?)=false;override fun onActionItemClicked(mode:ActionMode?,item:MenuItem?)=false;override fun onDestroyActionMode(mode:ActionMode?){}}
        if(android.os.Build.VERSION.SDK_INT>=23)editor.customInsertionActionModeCallback=object:ActionMode.Callback{override fun onCreateActionMode(mode:ActionMode?,menu:Menu?)=false;override fun onPrepareActionMode(mode:ActionMode?,menu:Menu?)=false;override fun onActionItemClicked(mode:ActionMode?,item:MenuItem?)=false;override fun onDestroyActionMode(mode:ActionMode?){}}
        editor.setSelection(editor.length())
        findViewById<ImageButton>(R.id.runButton).setOnClickListener{runSelectedOrAll()}; findViewById<ImageButton>(R.id.runCurrentButton).setOnClickListener{runSelectedOrAll(true)}; findViewById<Button>(R.id.importButton).setOnClickListener{pickFile()}; if(android.os.Build.VERSION.SDK_INT>=23){editor.setOnHoverListener{_,e->if(e.actionMasked==MotionEvent.ACTION_HOVER_MOVE||e.actionMasked==MotionEvent.ACTION_HOVER_ENTER){lastEditorPointerX=e.x;lastEditorPointerY=e.y};false};editor.setOnContextClickListener{v->showEditorContextMenu(v,lastEditorPointerX,lastEditorPointerY);true}}; installMacPointerIcons()
        findViewById<Button>(R.id.formatButton).setOnClickListener{editor.setText(formatSql(editor.text.toString())); editor.setSelection(editor.length())}
        findViewById<ImageButton>(R.id.clearButton).setOnClickListener{clearEditor()};
        findViewById<TextView>(R.id.editorZoomMinus).setOnClickListener{applyEditorZoom(editorZoom-0.05f)};
        findViewById<TextView>(R.id.editorZoomPlus).setOnClickListener{applyEditorZoom(editorZoom+0.05f)};
        findViewById<Button>(R.id.explainButton).setOnClickListener{explainCurrentQuery()};
        findViewById<TextView>(R.id.resultZoomMinus).setOnClickListener{applyResultZoom(resultZoom-0.05f)};
        findViewById<TextView>(R.id.resultZoomPlus).setOnClickListener{applyResultZoom(resultZoom+0.05f)}
        setupResizeHandle(); setupWindowDots(); refreshSchemaPanel(); showPlaceholder()
    }
    private fun enterImmersiveMode(){
        if(android.os.Build.VERSION.SDK_INT>=30){
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let{ controller ->
                controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior=android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }else{
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility=(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        }
    }
    override fun onWindowFocusChanged(hasFocus:Boolean){
        super.onWindowFocusChanged(hasFocus)
        if(hasFocus) enterImmersiveMode()
    }
    private fun loadPrefs(){
        history.addAll(prefs.getStringSet("history", emptySet<String>())!!.toList())
        prefs.all.filterKeys{it.startsWith("snippet:")}.forEach{entry->(entry.value as? String)?.let{snippets[entry.key.removePrefix("snippet:")]=it}}
    }
    private fun savePrefs(){prefs.edit().putStringSet("history",history.take(30).toSet()).apply()}
    private fun userDatabasePaths():MutableList<String>{
        return prefs.getStringSet("user_db_paths", emptySet<String>())?.filter{it.isNotBlank()&&File(it).exists()}?.toMutableList() ?: mutableListOf()
    }
    private fun saveUserDatabasePaths(paths:Collection<String>){prefs.edit().putStringSet("user_db_paths",paths.toSet()).apply()}
    private fun databaseLabel(path:String):String{
        val stored=prefs.getString("db_label_"+path.hashCode(),null)
        if(!stored.isNullOrBlank())return stored
        var n=File(path).name
        n=n.replace(Regex("^Imported_\\d+_"),"")
        return n.substringBeforeLast('.',n).ifBlank{"Database"}
    }
    private fun registerUserDatabase(path:String,label:String){
        val paths=userDatabasePaths();paths.remove(path);paths.add(path);saveUserDatabasePaths(paths)
        prefs.edit().putString("db_label_"+path.hashCode(),label.ifBlank{databaseLabel(path)}).apply()
    }
    private fun unregisterUserDatabase(path:String){
        val paths=userDatabasePaths();paths.remove(path);saveUserDatabasePaths(paths);prefs.edit().remove("db_label_"+path.hashCode()).apply()
    }
    private fun isBundledSample(path:String):Boolean=path.startsWith(filesDir.absolutePath+File.separator+"Sample_")
    private fun configureDatabase(database:SQLiteDatabase){
        // Large-data profile: keep SQLite disk-backed and avoid turning the Android
        // heap into a cache for the database. All pragmas are best-effort because
        // imported databases may come from older SQLite builds.
        try{database.rawQuery("PRAGMA journal_mode=WAL",null).use{if(it.moveToFirst())it.getString(0)}}catch(_:Exception){}
        try{database.execSQL("PRAGMA synchronous=NORMAL")}catch(_:Exception){}
        try{database.execSQL("PRAGMA foreign_keys=ON")}catch(_:Exception){}
        try{database.execSQL("PRAGMA busy_timeout=5000")}catch(_:Exception){}
        try{database.execSQL("PRAGMA temp_store=FILE")}catch(_:Exception){}
        // Negative cache_size means KiB, so this caps SQLite's page cache around 8 MiB.
        // It prevents large databases from consuming the app heap simply by being opened.
        try{database.execSQL("PRAGMA cache_size=-8192")}catch(_:Exception){}
        try{database.execSQL("PRAGMA wal_autocheckpoint=1000")}catch(_:Exception){}
    }
    private fun openSavedOrBundledDatabase(){
        val saved=prefs.getString("active_db_path",null)
        if(!saved.isNullOrBlank()){
            val f=File(saved)
            if(f.exists()){try{dbFile=f;db=SQLiteDatabase.openDatabase(f.path,null,SQLiteDatabase.OPEN_READWRITE);configureDatabase(db);if(!isBundledSample(f.path))registerUserDatabase(f.path,databaseLabel(f.path));return}catch(_:Exception){}}
        }
        val users=userDatabasePaths()
        if(users.isNotEmpty()){
            val f=File(users.first())
            try{dbFile=f;db=SQLiteDatabase.openDatabase(f.path,null,SQLiteDatabase.OPEN_READWRITE);configureDatabase(db);prefs.edit().putString("active_db_path",f.path).apply();return}catch(_:Exception){}
        }
        copyBundledDatabase("Parks_and_Recreation.db")
        prefs.edit().putString("active_db_path",dbFile.path).apply()
    }
    private fun copyBundledDatabase(asset:String){
        val safe=asset.replace(Regex("[^A-Za-z0-9._-]"),"_")
        dbFile=File(filesDir,"Sample_$safe")
        if(!dbFile.exists()) assets.open(asset).use{i->dbFile.outputStream().use{o->i.copyTo(o)}}
        db=SQLiteDatabase.openOrCreateDatabase(dbFile,null);configureDatabase(db)
    }
    private fun activateDatabase(path:String,label:String?=null){
        if(queryRunning){showError("Stop the running query before switching databases");return}
        val target=File(path)
        val opened=SQLiteDatabase.openDatabase(target.path,null,SQLiteDatabase.OPEN_READWRITE);configureDatabase(opened)
        if(::db.isInitialized&&db.isOpen)db.close()
        db=opened;dbFile=target
        prefs.edit().putString("active_db_path",target.path).apply()
        label?.let{prefs.edit().putString("db_label_"+target.path.hashCode(),it).apply()}
        clearResults();showPlaceholder();editor.setText(if(firstTable().isNotBlank())"SELECT * FROM \"${firstTable().replace("\"","\"\"")}\";" else "");editor.setSelection(editor.length());refreshSchemaPanel();statusOk("Using ${databaseLabel(target.path)}")
    }
    private fun pickFile(){
        if(queryRunning){showError("Stop the running query before changing databases or importing data");return}
        showImportBrowser()
    }
    private fun importRootUris():MutableList<Uri>{
        val raw=prefs.getString("import_browser_roots","").orEmpty()
        return raw.split("\n").filter{it.isNotBlank()}.mapNotNull{runCatching{Uri.parse(it)}.getOrNull()}.toMutableList()
    }
    private fun saveImportRoot(uri:Uri){
        val roots=importRootUris(); if(roots.none{it.toString()==uri.toString()})roots.add(uri)
        prefs.edit().putString("import_browser_roots",roots.joinToString("\n"){it.toString()}).apply()
    }
    private fun showImportBrowser(start:Uri?=null){
        importBrowserStack.clear(); importBrowserRoot=start
        val outer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(10));background=rounded(Color.rgb(17,19,25),1,Color.rgb(60,57,66),18f)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val back=TextView(this).apply{text="‹";textSize=25f;setTextColor(white);gravity=Gravity.CENTER;isClickable=true;setPadding(0,0,dp(8),0);contentDescription="Back"}
        importBrowserTitle=TextView(this).apply{text="Import";textSize=15f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL}
        header.addView(back,LinearLayout.LayoutParams(dp(34),dp(34)));header.addView(importBrowserTitle,LinearLayout.LayoutParams(0,dp(34),1f))
        val add=TextView(this).apply{text="＋";textSize=20f;setTextColor(white);gravity=Gravity.CENTER;isClickable=true;contentDescription="Add location";background=rounded(Color.rgb(30,32,40),0,Color.TRANSPARENT,9f)}
        header.addView(add,LinearLayout.LayoutParams(dp(36),dp(34)))
        outer.addView(header)
        importBrowserPath=TextView(this).apply{text="Supported SQL, SQLite, CSV and JSON files";textSize=9.5f;setTextColor(Color.rgb(125,129,141));setPadding(dp(4),dp(2),dp(4),dp(8));ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1}
        outer.addView(importBrowserPath)
        importBrowserList=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_NEVER;addView(importBrowserList)}
        outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val cancel=TextView(this).apply{text="Cancel";textSize=11.5f;setTextColor(Color.rgb(180,177,185));gravity=Gravity.CENTER;isClickable=true;background=rounded(Color.rgb(27,29,36),0,Color.TRANSPARENT,9f)}
        outer.addView(cancel,LinearLayout.LayoutParams(-1,dp(38)).apply{topMargin=dp(8)})
        importBrowserDialog=Dialog(this).apply{setContentView(outer);setCanceledOnTouchOutside(true);setCancelable(true);window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))}
        back.setOnClickListener{if(importBrowserStack.isNotEmpty()){importBrowserStack.removeLast();renderImportBrowser()}else if(importBrowserRoot!=null){importBrowserRoot=null;renderImportBrowser()}else importBrowserDialog?.dismiss()}
        add.setOnClickListener{chooseImportLocation()}
        cancel.setOnClickListener{importBrowserDialog?.dismiss()}
        importBrowserDialog?.setOnShowListener{dialog->dialog.window?.let{w->w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.30f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout(minOf(dp(520),resources.displayMetrics.widthPixels-dp(28)),minOf(dp(650),resources.displayMetrics.heightPixels-dp(70)))};renderImportBrowser();outer.alpha=0f;outer.scaleX=.985f;outer.scaleY=.985f;outer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(android.view.animation.DecelerateInterpolator()).start()}
        importBrowserDialog?.show()
    }
    private fun chooseImportLocation(){
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply{addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)}
        startActivityForResult(i,95)
    }
    private fun renderImportBrowser(){
        val list=importBrowserList?:return;list.removeAllViews()
        val current=importBrowserRoot
        importBrowserTitle?.text=if(current==null)"Import" else "Browse"
        importBrowserPath?.text=if(current==null)"Choose a location or browse a previously granted folder" else "Folder"
        if(current==null){
            addBrowserSection(list,"LOCATIONS")
            importRootUris().forEachIndexed{index,uri->
                addBrowserLocationRow(list,"Location ${index+1}",uri)
            }
            addBrowserActionRow(list,"＋  Add a folder","Give Lily access to a folder once; browsing stays inside Lily."){chooseImportLocation()}
            addBrowserSection(list,"RECENT")
            val recent=userDatabasePaths().asReversed().take(8)
            if(recent.isEmpty()) addBrowserEmpty(list,"No imported files yet") else recent.forEach{path->val f=File(path);if(f.exists())addBrowserFileRow(list,f.name,f.length(),null){startImportFromFile(f)}}
            addBrowserSection(list,"SUPPORTED")
            addBrowserEmpty(list,".sql  ·  .db  ·  .sqlite  ·  .sqlite3  ·  .csv  ·  .tsv  ·  .json")
        }else renderDocumentFolder(list,current,importBrowserStack.lastOrNull())
    }
    private fun addBrowserSection(parent:LinearLayout,text:String){parent.addView(TextView(this).apply{text=text;textSize=9f;letterSpacing=.15f;setTextColor(Color.rgb(105,109,122));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(6),dp(10),dp(6),dp(6))})}
    private fun addBrowserEmpty(parent:LinearLayout,text:String){parent.addView(TextView(this).apply{text=text;textSize=10.5f;setTextColor(Color.rgb(125,129,141));setPadding(dp(10),dp(8),dp(10),dp(10))})}
    private fun browserRowBase():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(46);setPadding(dp(9),0,dp(9),0);background=rounded(Color.rgb(24,26,33),1,Color.rgb(43,45,54),10f);isClickable=true}
    private fun addBrowserLocationRow(parent:LinearLayout,label:String,uri:Uri){val row=browserRowBase();row.addView(TextView(this).apply{text="▰";textSize=12f;setTextColor(blue);gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(30),dp(44))});row.addView(TextView(this).apply{text=label;textSize=12f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(0,dp(44),1f)});row.addView(TextView(this).apply{text="›";textSize=20f;setTextColor(Color.rgb(125,129,141));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(24),dp(44))});row.setOnClickListener{importBrowserRoot=uri;importBrowserStack.clear();renderImportBrowser()};parent.addView(row,LinearLayout.LayoutParams(-1,dp(46)).apply{bottomMargin=dp(5)})}
    private fun addBrowserActionRow(parent:LinearLayout,label:String,action:()->Unit){val row=browserRowBase();row.addView(TextView(this).apply{text=label;textSize=11.5f;setTextColor(Color.rgb(190,188,196));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(10),0);layoutParams=LinearLayout.LayoutParams(0,dp(44),1f)});row.setOnClickListener{action()};parent.addView(row,LinearLayout.LayoutParams(-1,dp(46)).apply{bottomMargin=dp(5)})}
    private fun addBrowserFileRow(parent:LinearLayout,name:String,size:Long,uri:Uri?,action:()->Unit){val row=browserRowBase();row.addView(TextView(this).apply{text="▤";textSize=12f;setTextColor(Color.rgb(166,160,177));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(30),dp(44))});val mid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL};mid.addView(TextView(this).apply{text=name;textSize=11.5f;setTextColor(white);maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END});mid.addView(TextView(this).apply{text=humanBytes(size);textSize=8.5f;setTextColor(Color.rgb(112,116,129))});row.addView(mid,LinearLayout.LayoutParams(0,dp(44),1f));row.addView(TextView(this).apply{text="›";textSize=20f;setTextColor(Color.rgb(125,129,141));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(24),dp(44))});row.setOnClickListener{action()};parent.addView(row,LinearLayout.LayoutParams(-1,dp(46)).apply{bottomMargin=dp(5)})}
    private fun renderDocumentFolder(parent:LinearLayout,treeUri:Uri,documentId:String?){
        val childrenUri=runCatching{val id=documentId ?: android.provider.DocumentsContract.getTreeDocumentId(treeUri);android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri,id)}.getOrNull()
        if(childrenUri==null){addBrowserEmpty(parent,"This folder is unavailable");return}
        val dirs=mutableListOf<Pair<String,Uri>>();val files=mutableListOf<Triple<String,Uri,Long>>()
        try{contentResolver.query(childrenUri,arrayOf(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE,android.provider.DocumentsContract.Document.COLUMN_SIZE),null,null,"${android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME} COLLATE NOCASE ASC")?.use{c->val idCol=c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID);val nameCol=c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME);val mimeCol=c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE);val sizeCol=c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_SIZE);while(c.moveToNext()){val id=c.getString(idCol);val name=c.getString(nameCol)?:"Unnamed";val mime=c.getString(mimeCol)?:"";val child=android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri,id);if(mime==android.provider.DocumentsContract.Document.MIME_TYPE_DIR)dirs.add(name to child) else if(isSupportedImportName(name))files.add(Triple(name,child,if(sizeCol>=0&&!c.isNull(sizeCol))c.getLong(sizeCol) else 0L))}}}catch(e:Exception){addBrowserEmpty(parent,"Could not read this folder: ${e.message?:"access denied"}");return}
        addBrowserSection(parent,"FOLDERS");if(dirs.isEmpty())addBrowserEmpty(parent,"No folders") else dirs.forEach{(name,uri)->val row=browserRowBase();row.addView(TextView(this).apply{text="▰";textSize=12f;setTextColor(Color.rgb(155,150,168));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(30),dp(44))});row.addView(TextView(this).apply{text=name;textSize=11.5f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(44),1f)});row.addView(TextView(this).apply{text="›";textSize=20f;setTextColor(Color.rgb(125,129,141));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(24),dp(44))});row.setOnClickListener{importBrowserStack.addLast(android.provider.DocumentsContract.getDocumentId(uri));renderImportBrowser()};parent.addView(row,LinearLayout.LayoutParams(-1,dp(46)).apply{bottomMargin=dp(5)})}
        addBrowserSection(parent,"FILES");if(files.isEmpty())addBrowserEmpty(parent,"No supported files in this folder") else files.forEach{(name,uri,size)->addBrowserFileRow(parent,name,size,uri){try{takePersistableRead(uri);importBrowserDialog?.dismiss();startImport(uri,name)}catch(e:Exception){showError("Could not open $name: ${e.message?:"file error"}")}}}
    }
    private fun isSupportedImportName(name:String):Boolean{name.lowercase(Locale.US);val n=name.lowercase(Locale.US);return n.endsWith(".sql")||n.endsWith(".db")||n.endsWith(".sqlite")||n.endsWith(".sqlite3")||n.endsWith(".csv")||n.endsWith(".tsv")||n.endsWith(".json")||n.endsWith(".ndjson")||n.endsWith(".jsonl")}
    private fun takePersistableRead(uri:Uri){try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}}
    private fun startImportFromFile(file:File){importBrowserDialog?.dismiss();Thread{try{val copy=File(cacheDir,"lily-import-${System.currentTimeMillis()}-${file.name}");file.inputStream().use{input->copy.outputStream().use{output->input.copyTo(output)}};runOnUiThread{startImport(Uri.fromFile(copy),file.name)}}catch(e:Exception){runOnUiThread{showError("Could not open ${file.name}: ${e.message?:"file error"}")}}}.start()}

    private fun displayName(uri:Uri):String{
        var name:String?=null
        try{contentResolver.query(uri,arrayOf("_display_name"),null,null,null)?.use{c->if(c.moveToFirst())name=c.getString(0)}}catch(_:Exception){}
        return name ?: (uri.lastPathSegment ?: "import.sql").substringAfterLast('/').ifBlank{"import.sql"}
    }
    override fun onActivityResult(req:Int,res:Int,data:Intent?){
        super.onActivityResult(req,res,data)
        if(req==88&&res==RESULT_OK&&data?.data!=null){
            val sourcePath=pendingDatabaseExportPath;pendingDatabaseExportPath=null
            try{
                if(sourcePath.isNullOrBlank())throw Exception("Export source is no longer available")
                val source=File(sourcePath)
                if(!source.exists())throw Exception("Database file no longer exists")
                contentResolver.openOutputStream(data.data!!)?.use{out->source.inputStream().use{input->input.copyTo(out,1024*1024)}}?:throw Exception("Could not open export destination")
                statusOk("Database exported")
            }catch(e:Exception){showError(e.message?:"Export failed")}
            return
        }
        if(req==90||req==91){
            if(res==RESULT_OK&&data?.data!=null){
                val q=if(activeTab>=0)tabs[activeTab].query else null
                if(q.isNullOrBlank())showError("The active result cannot be exported as a stream")
                else streamExportResult(data.data!!,if(req==90)"csv" else "json",q!!)
            }
            pendingCsv=null;return
        }
        if(req==92&&res==RESULT_OK&&data?.data!=null){
            pendingTableSqlExport?.let{streamTableSqlExport(data.data!!,it)}
            pendingTableSqlExport=null
            return
        }
        if(req==93&&res==RESULT_OK&&data?.data!=null){
            pendingTableCsvExport?.let{streamTableCsvExport(data.data!!,it)}
            pendingTableCsvExport=null
            return
        }
        if(req==94&&res==RESULT_OK&&data?.data!=null){
            if(pendingDatabaseSqlExport){streamDatabaseSqlExport(data.data!!);pendingDatabaseSqlExport=false}
            return
        }
        if(req==89&&res==RESULT_OK&&data?.data!=null){
            try{contentResolver.openOutputStream(data.data!!).use{out->out!!.bufferedWriter().use{w->w.write(editor.text.toString())}};statusOk("SQL saved")}catch(e:Exception){showError(e.message?:"Save failed")}
            return
        }
        if(req==95){
            if(res==RESULT_OK&&data?.data!=null){
                val uri=data.data!!;try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)}catch(_:Exception){takePersistableRead(uri)};saveImportRoot(uri);importBrowserStack.clear();importBrowserRoot=uri;importBrowserStack.clear();renderImportBrowser()
            }
            return
        }
        if(req!=77||res!=RESULT_OK||data?.data==null)return
        val uri=data.data!!
        try{contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
        val fileName=displayName(uri)
        startImport(uri,fileName)
    }
    private data class ImportOutcome(val database:SQLiteDatabase,val target:File,val label:String,val status:String)
    private class ImportCancelledException:Exception("Import cancelled")
    private fun showImportProgress(title:String,fileName:String){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(4),dp(4),dp(4),dp(2))}
        importTitleView=TextView(this).apply{text=title;textSize=14f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(white);setPadding(0,dp(4),0,dp(2))}
        importDetailView=TextView(this).apply{text=fileName;textSize=11f;setTextColor(Color.rgb(145,141,154));setPadding(0,dp(2),0,dp(8));maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END}
        importDots=LoadingDotsView(this).apply{layoutParams=LinearLayout.LayoutParams(dp(92),dp(32)).apply{gravity=android.view.Gravity.CENTER_HORIZONTAL};setPadding(0,0,0,0)}
        importCancelButton=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Cancel";isAllCaps=false;setOnClickListener{importCancelled=true;text="Stopping…";isEnabled=false}}
        box.addView(importTitleView);box.addView(importDetailView);box.addView(importDots);box.addView(importCancelButton,LinearLayout.LayoutParams(-1,dp(38)).apply{topMargin=dp(6)})
        importDialog=cardDialog("",box).apply{setCanceledOnTouchOutside(false);setCancelable(false)}
        importDialog?.show()
        importDots?.post{if(importInProgress)importDots?.start()}
    }
    private fun closeImportDialog(){importDots?.stop();importDialog?.dismiss();importDialog=null;importDots=null;importCancelButton=null;importTitleView=null;importDetailView=null}
    private fun finishImportedDatabase(outcome:ImportOutcome){
        closeImportDialog()
        try{if(::db.isInitialized&&db.isOpen)db.close()}catch(_:Exception){}
        db=outcome.database;dbFile=outcome.target;configureDatabase(db)
        val paths=userDatabasePaths();paths.add(outcome.target.path);saveUserDatabasePaths(paths)
        prefs.edit().putString("active_db_path",outcome.target.path).putString("db_label_${outcome.target.path.hashCode()}",outcome.label).apply()
        clearResults();showPlaceholder();refreshSchemaPanel();val first=firstTable();editor.setText(if(first.isNotBlank())"SELECT * FROM \"${first.replace("\"","\"\"")}\";" else "");editor.setSelection(editor.length())
        importInProgress=false;statusOk(outcome.status)
    }
    private fun showImportCancelled(){closeImportDialog();importInProgress=false;statusOk("Import cancelled — active database was unchanged")}
    private fun showImportFailure(message:String,uri:Uri,fileName:String){closeImportDialog();importInProgress=false;val detail=TextView(this).apply{setText("$message\n\n$fileName");textSize=12f;setTextColor(white);setPadding(0,dp(8),0,dp(8));setTextIsSelectable(true)};cardDialog("Import failed",detail).show()}
    private fun startImport(uri:Uri,fileName:String){
        if(importInProgress)return
        val name=fileName.lowercase(Locale.US)
        val title=when{
            name.endsWith(".db")||name.endsWith(".sqlite")||name.endsWith(".sqlite3")->"Importing database"
            name.endsWith(".csv")||name.endsWith(".tsv")->"Importing data"
            name.endsWith(".json")||name.endsWith(".ndjson")||name.endsWith(".jsonl")->"Importing JSON"
            else->"Importing SQL"
        }
        showImportProgress(title,fileName)
        importCancelled=false
        importInProgress=true
        Thread {
            try{
                checkImportCancelled()
                val outcome=when{
                    name.endsWith(".db")||name.endsWith(".sqlite")||name.endsWith(".sqlite3")->contentResolver.openInputStream(uri)?.use{importDatabaseStream(it,fileName)} ?: throw Exception("Could not read the selected file")
                    name.endsWith(".sql")||name.endsWith(".txt")->importSqlStream(uri,fileName)
                    name.endsWith(".csv")||name.endsWith(".tsv")->importDelimitedStream(uri,fileName,if(name.endsWith(".tsv"))'\t' else ',')
                    name.endsWith(".json")||name.endsWith(".ndjson")||name.endsWith(".jsonl")->importJsonStream(uri,fileName)
                    else->{
                        throw Exception("Unsupported file. Choose .sql, .txt, .csv, .tsv, .json, .ndjson, .jsonl, .db, .sqlite, or .sqlite3.")
                    }
                }
                checkImportCancelled()
                runOnUiThread{if(!isFinishing && !isDestroyed)finishImportedDatabase(outcome) else {try{outcome.database.close()}catch(_:Exception){};outcome.target.delete();importInProgress=false}}
            }catch(_:ImportCancelledException){
                runOnUiThread{if(!isFinishing && !isDestroyed)showImportCancelled() else {importInProgress=false}}
            }catch(e:OutOfMemoryError){
                runOnUiThread{if(!isFinishing && !isDestroyed)showImportFailure("Import ran out of memory. Large imports use streaming mode; this file may contain a format that requires too much in-memory parsing.",uri,fileName) else {importInProgress=false}}
            }catch(e:Exception){
                runOnUiThread{if(!isFinishing && !isDestroyed)showImportFailure(e.message?:"Could not read/import the selected file",uri,fileName) else {importInProgress=false}}
            }
        }.start()
    }
    private data class ParsedInsert(val table:String,val columns:List<String>,val values:List<String>)
    private fun hasUserTables(database:SQLiteDatabase):Boolean = try {
        database.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' LIMIT 1",null).use{it.moveToFirst()}
    } catch(_:Exception){ false }
    private fun databaseSummary(database:SQLiteDatabase):String = try {
        val tables=database.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata'",null).use{if(it.moveToFirst())it.getInt(0)else 0}
        val views=database.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='view' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata'",null).use{if(it.moveToFirst())it.getInt(0)else 0}
        buildString { append(tables).append(if(tables==1)" table" else " tables"); if(views>0)append(" · ").append(views).append(if(views==1)" view" else " views") }
    } catch(_:Exception){ "SQLite database" }
    private fun inferImportType(values:List<String>):String = inferTabularType(values)
    private fun stripLeadingSqlComments(sql:String):String{
        var s=sql.removePrefix("\uFEFF").trimStart()
        while(true){
            s=when{
                s.startsWith("/*")-> { val end=s.indexOf("*/",2); if(end<0) return s else s.substring(end+2).trimStart() }
                s.startsWith("--")-> { val end=s.indexOf('\n'); if(end<0) return "" else s.substring(end+1).trimStart() }
                s.startsWith("#")-> { val end=s.indexOf('\n'); if(end<0) return "" else s.substring(end+1).trimStart() }
                else->return s
            }
        }
    }
    private fun shouldSkipImportStatement(sql:String):Boolean {
        val s=stripLeadingSqlComments(sql).trim().removeSuffix(";").trimStart()
        if(s.isBlank())return true
        val u=s.uppercase(Locale.US)
        return when {
            u.startsWith("SET ") ||
            u.startsWith("LOCK TABLES") || u.startsWith("UNLOCK TABLES") ||
            u.startsWith("ALTER TABLE") && u.contains("DISABLE KEYS") || u.startsWith("ALTER TABLE") && u.contains("ENABLE KEYS") ||
            u.startsWith("SET ANSI_") || u.startsWith("SET QUOTED_IDENTIFIER") || u.startsWith("SET ANSI_NULLS") ||
            u.startsWith("SET NOCOUNT") || u.startsWith("SET XACT_ABORT") || u.startsWith("SET CONCAT_NULL_YIELDS_NULL") ||
            u.startsWith("SET IDENTITY_INSERT") -> true
            u.startsWith("USE ") || u.startsWith("GO") || u.startsWith("DELIMITER ") -> true
            u.startsWith("CREATE DATABASE") || u.startsWith("DROP DATABASE") ||
            u.startsWith("CREATE SCHEMA") || u.startsWith("DROP SCHEMA") -> true
            u.startsWith("CREATE INDEX") || u.startsWith("CREATE UNIQUE INDEX") || u.startsWith("CREATE CLUSTERED INDEX") ||
            u.startsWith("CREATE NONCLUSTERED INDEX") || u.startsWith("DROP INDEX") -> true
            u.startsWith("CREATE TRIGGER") || u.startsWith("DROP TRIGGER") || u.startsWith("ALTER TABLE") && (u.contains(" ADD CONSTRAINT") || u.contains(" DROP CONSTRAINT")) -> true
            u.startsWith("IF EXISTS") || u.startsWith("IF NOT EXISTS") && !u.contains("CREATE TABLE") && !u.contains("CREATE VIEW") -> true
            u.startsWith("START TRANSACTION") || u.startsWith("BEGIN TRANSACTION") || u=="BEGIN" || u=="COMMIT" || u=="ROLLBACK" ||
            u.startsWith("SAVEPOINT ") || u.startsWith("RELEASE SAVEPOINT") || u.startsWith("SET AUTOCOMMIT") -> true
            u.startsWith("EXEC ") || u.startsWith("EXECUTE ") -> true
            u.startsWith("GRANT ") || u.startsWith("REVOKE ") -> true
            u.contains("SYS.SYSREFERENCES") || u.contains("SYS.SYSOBJECTS") || u.contains("SYS.SYSINDEXES") -> true
            u.startsWith("ALTER TABLE") && u.contains("FOREIGN KEY") -> true
            else -> false
        }
    }
    private fun prepareSqlForSQLite(raw:String):Pair<String,Int>{
        var s=raw.removePrefix("\uFEFF").replace("\r\n","\n").replace("\r","\n").trim()
        if(s.isBlank())return "" to 0
        s=s.replace("\u0000","").replace("\u001A","").replace("\u200B","").replace("\u200C","").replace("\u200D","").replace("\uFEFF","").replace('\u00A0',' ').trim()
        if(shouldSkipImportStatement(s)) return "" to 1
        // Normalize common vendor INSERT spellings before classification.
        s=replaceOutsideSingleQuotes(s,Regex("""(?i)^\s*INSERT\s+(?!(?:INTO\b|OR\s+(?:IGNORE|REPLACE)\s+INTO\b))(?=(?:\[[^\]]+\]\.)?\[[^\]]+\]|(?:[A-Za-z_][A-Za-z0-9$]*\.)?[A-Za-z_][A-Za-z0-9$]*)""")){"INSERT INTO "}
        s=replaceOutsideSingleQuotes(s,Regex("""(?i)^\s*INSERT\s+INTO\s+ONLY\s+""")){"INSERT INTO "}
        val executable=stripLeadingSqlComments(s)
        val isInsert=Regex("""(?is)^\s*(?:INSERT|REPLACE)(?:\s+OR\s+(?:IGNORE|REPLACE))?\s+INTO\b""").containsMatchIn(executable)
        val isCreate=Regex("""(?is)^\s*CREATE\s+(?:TEMP(?:ORARY)?\s+)?TABLE(?:\s+IF\s+NOT\s+EXISTS)?\b""").containsMatchIn(executable)
        // Identifier quoting is safe only outside SQL string literals. This preserves
        // values such as '[dbo].[Customer]' or 'varchar(20)' inside INSERT data.
        s=replaceOutsideSingleQuotes(s, Regex("\\[([^\\]]+)\\]\\.\\[([^\\]]+)\\]")){m->"\\\"${m.groupValues[2].replace("\\\"","\\\"\\\"")}\\\""}
        s=replaceOutsideSingleQuotes(s, Regex("\\[([^\\]]+)\\]")){m->"\\\"${m.groupValues[1].replace("\\\"","\\\"\\\"")}\\\""}
        s=replaceOutsideSingleQuotes(s, Regex("`([^`]+)`")){m->"\\\"${m.groupValues[1].replace("\\\"","\\\"\\\"")}\\\""}
        // Imported workspaces use one SQLite schema, so flatten common source qualifiers
        // for both DDL and DML (CREATE public.t and INSERT INTO public.t).
        s=replaceOutsideSingleQuotes(s, Regex("""(?i)(?:\"(?:public|dbo)\"|\b(?:public|dbo))\s*\.""")){""}
        if(isCreate){
            // Vendor data-type and DDL option normalization is intentionally limited
            // to CREATE TABLE statements so INSERT payloads are never rewritten.
            val typePatterns=linkedMapOf(
                "(?i)\\b(?:nvarchar|varchar|nchar|char|sysname)\\s*\\(\\s*max\\s*\\)" to "TEXT",
                "(?i)\\b(?:nvarchar|varchar|nchar|char|sysname)\\s*\\(\\s*\\d+\\s*\\)" to "TEXT",
                "(?i)\\b(?:nvarchar|varchar|nchar|char|sysname)\\b" to "TEXT",
                "(?i)\\b(?:datetime2|datetimeoffset|smalldatetime|datetime|date|time)\\b" to "TEXT",
                "(?i)\\b(?:uniqueidentifier)\\b" to "TEXT",
                "(?i)\\b(?:varbinary|binary|image)\\s*\\(\\s*max\\s*\\)" to "BLOB",
                "(?i)\\b(?:varbinary|binary)\\s*\\(\\s*\\d+\\s*\\)" to "BLOB",
                "(?i)\\b(?:decimal|numeric|money|smallmoney|float|real|double(?:\\s+precision)?)\\b(?:\\s*\\(\\s*\\d+\\s*(?:,\\s*\\d+\\s*)?\\))?" to "REAL",
                "(?i)\\b(?:bigint|smallint|mediumint|tinyint|integer|int|bit)\\b(?:\\s*\\(\\s*\\d+\\s*\\))?" to "INTEGER ",
                "(?i)\\b(?:text|tinytext|mediumtext|longtext|clob)\\b" to "TEXT",
                "(?i)\\b(?:blob|tinyblob|mediumblob|longblob)\\b" to "BLOB",
                "(?i)\\b(?:boolean|bool)\\b" to "INTEGER",
                "(?i)\\b(?:json|jsonb|uuid|xml|tsvector)\\b" to "TEXT",
                "(?i)\\b(?:timestamp(?:\\s+with(?:out)?\\s+time\\s+zone)?|timestamptz|time(?:\\s+with(?:out)?\\s+time\\s+zone)?)\\b" to "TEXT",
                "(?i)\\b(?:serial|bigserial)\\b" to "INTEGER",
                "(?i)\\bUNSIGNED\\b" to "",
                "(?i)\\bIDENTITY\\s*\\(\\s*\\d+\\s*,\\s*\\d+\\s*\\)" to "",
                "(?i)\\bIDENTITY\\b" to ""
            )
            for((pattern,repl) in typePatterns)s=replaceOutsideSingleQuotes(s,Regex(pattern)){repl}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bPRIMARY\\s+KEY\\s+CLUSTERED\\b")){"PRIMARY KEY"}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bPRIMARY\\s+KEY\\s+NONCLUSTERED\\b")){"PRIMARY KEY"}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bAUTO_INCREMENT\\b")){"AUTOINCREMENT"}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bDEFAULT\\s+GETDATE\\s*\\(\\s*\\)")){"DEFAULT CURRENT_TIMESTAMP"}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bON\\s+UPDATE\\s+CURRENT_TIMESTAMP")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bENGINE\\s*=\\s*[A-Za-z0-9_]+")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bDEFAULT\\s+CHARSET\\s*=\\s*[A-Za-z0-9_]+")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bCOLLATE\\s+[A-Za-z0-9_]+")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bROW_FORMAT\\s*=\\s*[A-Za-z0-9_]+")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bWITH\\s*\\([^)]*\\)")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\b(?:public|dbo)\\s*\\.")){""}
            s=replaceOutsideSingleQuotes(s,Regex("""(?is)([\"`]?[_A-Za-z][_A-Za-z0-9$]*[\"`]?)\s+INTEGER\s+PRIMARY\s+KEY\s*(?!AUTOINCREMENT)""")){m->m.groupValues[1]+" INTEGER PRIMARY KEY AUTOINCREMENT"}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bCLUSTERED\\b")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bNONCLUSTERED\\b")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bCONSTRAINT\\s+[\\\"`\\[]?[^\\s\\\"`\\]]+[\\\"`\\]]?\\s+")){""}
            s=replaceOutsideSingleQuotes(s,Regex("(?is),\\s*(?:(?:UNIQUE\\s+)?(?:FULLTEXT\\s+|SPATIAL\\s+)?KEY)\\s+[\\\"`\\[]?[^\\s\\\"`\\]]+[\\\"`\\]]?\\s*\\([^)]*\\)")){""}
            // SQLite requires AUTOINCREMENT to be part of an INTEGER PRIMARY KEY.
            // Normalize common MySQL/SQL Server forms such as id INTEGER NOT NULL AUTOINCREMENT
            // and remove the duplicate table-level PRIMARY KEY for that same column.
            val auto=Regex("(?is)([\"`]?[_A-Za-z][_A-Za-z0-9$]*[\"`]?)\\s+INTEGER(?:\\s+NOT\\s+NULL)?(?:\\s+PRIMARY\\s+KEY)?\\s+AUTOINCREMENT\\b")
            val autoNames=mutableListOf<String>()
            s=replaceOutsideSingleQuotes(s,auto){m->autoNames.add(m.groupValues[1].trim('\"','`'));m.groupValues[1]+" INTEGER PRIMARY KEY AUTOINCREMENT"}
            for(name in autoNames){
                val duplicatePk=Regex("(?is),\\s*PRIMARY\\s+KEY\\s*\\(\\s*[\"`]?"+Regex.escape(name)+"[\"`]?\\s*\\)\\s*(?=,|\\))")
                s=replaceOutsideSingleQuotes(s,duplicatePk){""}
            }
        } else if(isInsert){
            // Data statements get only transformations that affect SQL syntax, never
            // quoted payload text. SQL Server's Unicode N'...' prefix is harmless in SQLite
            // after removing the prefix; PostgreSQL casts are also removed here.
            s=replaceOutsideSingleQuotes(s,Regex("(?i)\\bN(?=')")){""}
            s=replaceOutsideSingleQuotes(s,Regex("::[A-Za-z_][A-Za-z0-9_]*(?:\\s*\\(\\s*\\d+(?:\\s*,\\s*\\d+)?\\s*\\))?")){""}
        }
        return s.trim() to 0
    }
    private fun replaceOutsideSingleQuotes(source:String, regex:Regex, replacement:(MatchResult)->String):String{
        val out=StringBuilder(source.length);var cursor=0
        while(cursor<source.length){
            val quoteStart=source.indexOf('\'',cursor)
            if(quoteStart<0){out.append(regex.replace(source.substring(cursor)){replacement(it)});break}
            if(quoteStart>cursor)out.append(regex.replace(source.substring(cursor,quoteStart)){replacement(it)})
            var i=quoteStart;out.append(source[i]);i++
            while(i<source.length){
                out.append(source[i])
                if(source[i]=='\''){
                    if(i+1<source.length&&source[i+1]=='\''){out.append(source[i+1]);i+=2;continue}
                    i++;break
                }
                i++
            }
            cursor=i
        }
        return out.toString()
    }
    private fun parseImportInsert(sql:String):ParsedInsert?{
        // Parse INSERT statements structurally instead of relying on one large regex.
        // This is deliberately tolerant of SQL Server/MySQL/PostgreSQL dump spelling:
        //   INSERT INTO [dbo].[Customer] ([Id], [Name])VALUES(...)
        //   INSERT IGNORE INTO `Customer` (`Id`,`Name`) VALUES (...)
        //   INSERT INTO "Customer" ("Id","Name") VALUES (...)
        var s=stripLeadingSqlComments(sql).trim().removeSuffix(";").trim()
        if(s.isBlank())return null
        val prefix=Regex("(?is)^INSERT\\s+(?:(?:LOW_PRIORITY|HIGH_PRIORITY|IGNORE)\\s+)*(?:OR\\s+(?:IGNORE|REPLACE)\\s+)?INTO\\s+").find(s) ?: return null
        var i=prefix.range.last+1
        fun skipWs(){while(i<s.length&&s[i].isWhitespace())i++}
        fun readIdentifier():String?{
            skipWs();if(i>=s.length)return null
            val start=i
            val c=s[i]
            if(c=='['){
                i++;val b=i;while(i<s.length&&s[i]!=']')i++;if(i>=s.length)return null
                val out=s.substring(b,i);i++;return out
            }
            if(c=='`'||c=='"'){
                val q=c;i++;val out=StringBuilder()
                while(i<s.length){val ch=s[i];if(ch==q){if(i+1<s.length&&s[i+1]==q){out.append(q);i+=2;continue};i++;return out.toString()};out.append(ch);i++}
                return null
            }
            while(i<s.length&&(s[i].isLetterOrDigit()||s[i]=='_'||s[i]=='$'))i++
            return if(i>start)s.substring(start,i) else null
        }
        val first=readIdentifier() ?: return null
        skipWs()
        var table=first
        if(i<s.length&&s[i]=='.'){
            i++;val second=readIdentifier() ?: return null;table=second
        }
        skipWs()
        var columns=emptyList<String>()
        if(i<s.length&&s[i]=='('){
            val tuple=extractBalanced(s,i) ?: return null
            columns=splitTopLevelComma(tuple).map{it.trim().trim('`','"','[',']')}.filter{it.isNotBlank()}
            i += tuple.length+2 // opening '(' + inner text + closing ')'
        }
        skipWs()
        val valuesMatch=Regex("(?is)^VALUES\\b").find(s,i) ?: return null
        i=valuesMatch.range.last+1
        val valuesPart=s.substring(i).trim()
        val firstTupleStart=valuesPart.indexOf('(')
        if(firstTupleStart<0)return null
        val tuple=extractBalanced(valuesPart,firstTupleStart) ?: return null
        val values=splitTopLevelComma(tuple).map{normalizeImportLiteral(it.trim())}
        val cols=if(columns.isNotEmpty())columns else values.indices.map{"column_${it+1}"}
        if(cols.size!=values.size)return null
        return ParsedInsert(table,cols,values)
    }

    private fun splitTopLevelComma(s:String):List<String>{
        val out=mutableListOf<String>();var q:Char?=null;var depth=0;var start=0;var i=0
        while(i<s.length){val c=s[i];if(q!=null){if(c==q){if(i+1<s.length&&s[i+1]==q){i+=2;continue};q=null};i++;continue};if(c=='\''||c=='"'||c=='`'){q=c;i++;continue};when(c){'('->depth++;')'->if(depth>0)depth--;','->if(depth==0){out.add(s.substring(start,i));start=i+1}};i++}
        out.add(s.substring(start));return out
    }
    private fun extractBalanced(s:String,start:Int):String?{if(start !in s.indices||s[start]!='(')return null;var depth=0;var q:Char?=null;var i=start;while(i<s.length){val c=s[i];if(q!=null){if(c==q){if(i+1<s.length&&s[i+1]==q){i+=2;continue};q=null};i++;continue};if(c=='\''||c=='"'||c=='`'){q=c;i++;continue};if(c=='(')depth++;if(c==')'){depth--;if(depth==0)return s.substring(start+1,i)};i++};return null}
    private fun normalizeImportLiteral(v:String):String{val t=v.trim();return when{t.matches(Regex("(?i)^N'.*'$"))->t.substring(1);t.equals("NULL",true)->"";else->t.trim('`')}}
    private fun checkImportCancelled(){if(importCancelled)throw ImportCancelledException()}
    private fun copyStreamToFile(input:InputStream,target:File){
        target.parentFile?.mkdirs()
        input.buffered(1024*1024).use{src->FileOutputStream(target).use{rawOut->BufferedOutputStream(rawOut,1024*1024).use{out->
            val buffer=ByteArray(1024*1024);var total=0L;var lastUi=0L;while(true){checkImportCancelled();val n=src.read(buffer);if(n<0)break;out.write(buffer,0,n);total+=n;if(total-lastUi>=64L*1024L*1024L){lastUi=total;val text="Streaming from disk · ${humanBytes(total)} processed";runOnUiThread{if(importInProgress)importDetailView?.text=text}}};out.flush();rawOut.fd.sync()
        }}}
    }
    private fun importDatabaseStream(input:InputStream,fileName:String):ImportOutcome{
        checkImportCancelled()
        val target=File(filesDir,"Imported_${System.currentTimeMillis()}_${fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")}")
        try{copyStreamToFile(input,target)}catch(e:Exception){target.delete();throw e}
        val opened=try{SQLiteDatabase.openDatabase(target.path,null,SQLiteDatabase.OPEN_READWRITE)}catch(e:Exception){target.delete();throw Exception("Could not open SQLite database: ${e.message?:"invalid database"}")}
        try{configureDatabase(opened)}catch(_:Exception){}
        try{
            if(!hasUserTables(opened))throw Exception("The database opened successfully but contains no user tables")
            checkImportCancelled()
            return ImportOutcome(opened,target,fileName.substringBeforeLast('.',fileName),"Imported database: $fileName · ${humanBytes(target.length())}")
        }catch(e:Exception){opened.close();target.delete();throw e}
    }
    private data class StreamTableSpec(val columns:LinkedHashSet<String> = linkedSetOf(), val samples:LinkedHashMap<String,MutableList<String>> = linkedMapOf())
    private fun importSqlStream(uri:Uri,fileName:String):ImportOutcome{
        // First pass is only used for INSERT-only dumps: it builds a tiny schema sample,
        // never the whole dataset. A second pass streams the actual rows into SQLite.
        var hasCreate=false;var hasInsert=false
        val specs=linkedMapOf<String,StreamTableSpec>()
        contentResolver.openInputStream(uri)?.use{input->streamSqlStatements(input){raw->
            checkImportCancelled();val normalized=prepareSqlForSQLite(raw).first;for(piece in splitSql(normalized)){
                val st=piece.trim();if(st.isBlank()||shouldSkipImportStatement(st)||isQueryStatement(st))continue
                if(Regex("(?is)^CREATE\\s+TABLE\\b").containsMatchIn(st))hasCreate=true
                if(Regex("(?is)^INSERT\\s+(?:OR\\s+(?:IGNORE|REPLACE)\\s+)?INTO\\b").containsMatchIn(st)){hasInsert=true;val row=parseImportInsert(st);if(row!=null){val spec=specs.getOrPut(row.table){StreamTableSpec()};row.columns.forEachIndexed{idx,col->spec.columns.add(col);val list=spec.samples.getOrPut(col){mutableListOf()};if(list.size<32)list.add(row.values[idx])}}}
            }
        }} ?: throw Exception("Could not read $fileName")
        return importSqlStreamSecondPass(uri,fileName,hasCreate,hasInsert,specs)
    }
    private fun importSqlStreamSecondPass(uri:Uri,fileName:String,hasCreate:Boolean,hasInsert:Boolean,specs:LinkedHashMap<String,StreamTableSpec>):ImportOutcome{
        if(!hasCreate && !hasInsert)throw Exception("No CREATE TABLE or INSERT statements were found")
        val target=File(filesDir,"Imported_${System.currentTimeMillis()}_${fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")}.db")
        var fresh:SQLiteDatabase?=null;var statements=0;var skipped=0;var rows=0L;var inTransaction=false
        try{
            fresh=SQLiteDatabase.openOrCreateDatabase(target,null);configureDatabase(fresh)
            fresh.beginTransaction();inTransaction=true
            if(!hasCreate&&hasInsert){
                for((table,spec) in specs){checkImportCancelled();val defs=spec.columns.joinToString(", "){col->
                    val type=inferImportType(spec.samples[col].orEmpty());val pk=if(col.equals("id",true)&&type=="INTEGER")" PRIMARY KEY" else "";"\"${col.replace("\"","\"\"")}\" $type$pk"}
                    if(defs.isNotBlank())fresh.execSQL("CREATE TABLE \"${table.replace("\"","\"\"")}\" ($defs)")
                }
            }
            val commitEvery=5000;var sinceCommit=0
            streamSqlStatements(contentResolver.openInputStream(uri)?:throw Exception("Could not reopen $fileName")){raw->
                checkImportCancelled();val prepared=prepareSqlForSQLite(raw);skipped+=prepared.second
                for(piece in splitSql(prepared.first)){
                    checkImportCancelled();var st=piece.trim();if(st.isBlank()||isQueryStatement(st))continue
                    if(shouldSkipImportStatement(st)){skipped++;continue}
                    if(!hasCreate&&hasInsert){val parsed=parseImportInsert(st);if(parsed==null)continue}
                    try{fresh!!.execSQL(st)}catch(first:Exception){val retry=st.trim().removeSuffix(";").trim();if(retry!=st&&retry.isNotBlank())fresh!!.execSQL(retry)else throw first};statements++;if(st.startsWith("INSERT",true)||st.startsWith("REPLACE",true))rows++;sinceCommit++
                    if(sinceCommit>=commitEvery){fresh!!.setTransactionSuccessful();fresh!!.endTransaction();inTransaction=false;fresh!!.beginTransaction();inTransaction=true;sinceCommit=0}
                }
            }
            checkImportCancelled();if(inTransaction){fresh.setTransactionSuccessful();fresh.endTransaction();inTransaction=false}
            if(!hasUserTables(fresh)){
                if(hasInsert && specs.isNotEmpty()) throw Exception("SQL data was detected and ${specs.size} table schema(s) were inferred, but SQLite created no user tables. Import was rolled back.")
                throw Exception("No user tables were created")
            }
            val suffix=if(skipped>0)" · skipped $skipped unsupported/dump-control statement(s)" else ""
            return ImportOutcome(fresh,target,fileName.substringBeforeLast('.',fileName),"Imported $fileName · ${humanBytes(target.length())} · $statements statement(s) · $rows row inserts$suffix").also{fresh=null}
        }catch(e:Exception){
            try{if(inTransaction)fresh?.endTransaction()}catch(_:Exception){};try{fresh?.close()}catch(_:Exception){};target.delete();if(e is ImportCancelledException)throw e;throw Exception("Import failed after $statements statement(s): ${e.message?:"SQL error"}")
        }
    }
    private fun openSqlReader(input:InputStream):Reader{
        val push=java.io.PushbackInputStream(java.io.BufferedInputStream(input,64*1024),3);val b=ByteArray(3);var n=0
        while(n<3){val v=push.read();if(v<0)break;b[n++]=v.toByte()}
        if(n>=3&&(b[0].toInt() and 255)==0xEF&&(b[1].toInt() and 255)==0xBB&&(b[2].toInt() and 255)==0xBF)return InputStreamReader(push,Charsets.UTF_8)
        if(n>=2&&(b[0].toInt() and 255)==0xFF&&(b[1].toInt() and 255)==0xFE){if(n>2)push.unread(b,2,n-2);return InputStreamReader(push,Charsets.UTF_16LE)}
        if(n>=2&&(b[0].toInt() and 255)==0xFE&&(b[1].toInt() and 255)==0xFF){if(n>2)push.unread(b,2,n-2);return InputStreamReader(push,Charsets.UTF_16BE)}
        push.unread(b,0,n);return InputStreamReader(push,Charsets.UTF_8)
    }
    private fun streamSqlStatements(input:InputStream,onStatement:(String)->Unit){
        openSqlReader(input).buffered().use{r->
            val current=StringBuilder(16*1024);var quote:Char?=null;var bracket=false;var backtick=false;var protectGoBatch=false;var parenDepth=0
            fun flush(){if(current.isNotBlank()){onStatement(current.toString());current.setLength(0)}}
            fun startsNewStatement(line:String):Boolean{
                val t=line.trimStart()
                return Regex("(?i)^(?:INSERT(?:\\s+OR\\s+(?:IGNORE|REPLACE))?\\s+(?:INTO\\s+)?(?:\\[[^\\]]+\\]|[A-Za-z_])|REPLACE\\s+INTO|UPDATE\\s+|DELETE\\s+FROM|TRUNCATE\\s+TABLE|CREATE\\s+(?:TEMP(?:ORARY)?\\s+)?(?:TABLE|VIEW)|DROP\\s+(?:TABLE|VIEW)|ALTER\\s+TABLE|SET\\s+|USE\\s+|IF\\s+|GO(?:\\s+\\d+)?\\s*$)").containsMatchIn(t)
            }
            while(true){
                checkImportCancelled()
                val line=r.readLine()?:break
                val trimmed=line.trim()
                if(quote==null&&!bracket&&!backtick&&(trimmed.equals("GO",true)||trimmed.matches(Regex("(?i)^GO\\s+\\d+$")))){flush();protectGoBatch=false;continue}
                if(quote==null&&!bracket&&!backtick&&parenDepth==0&&current.isNotBlank()&&!protectGoBatch&&startsNewStatement(line)){flush()}
                if(quote==null&&!bracket&&!backtick&&trimmed.startsWith("IF ",true)&&Regex("(?is)^IF\\s+(?:NOT\\s+)?EXISTS\\b").containsMatchIn(trimmed))protectGoBatch=true
                var i=0
                while(i<line.length){
                    val c=line[i];val next=if(i+1<line.length)line[i+1] else '\u0000'
                    if(quote!=null){current.append(c);if(c==quote){if(next==quote){current.append(next);i+=2;continue};quote=null};i++;continue}
                    if(bracket){current.append(c);if(c==']'){if(next==']'){current.append(next);i+=2;continue};bracket=false};i++;continue}
                    if(backtick){current.append(c);if(c=='`'){if(next=='`'){current.append(next);i+=2;continue};backtick=false};i++;continue}
                    if(c=='\''||c=='"'){current.append(c);quote=c;i++;continue}
                    if(c=='`'){current.append(c);backtick=true;i++;continue}
                    if(c=='['){current.append(c);bracket=true;i++;continue}
                    if(c=='(')parenDepth++
                    if(c==')'&&parenDepth>0)parenDepth--
                    if(c==';'&&parenDepth==0&&!protectGoBatch){current.append(c);flush();i++;continue}
                    current.append(c);i++
                }
                current.append('\n')
                if(quote==null&&!bracket&&!backtick&&parenDepth==0&&!protectGoBatch){
                    val t=trimmed
                    // Keep INSERT statements open across following VALUES/tuple lines.
                    // A new top-level statement is detected before its line is appended.
                    if(Regex("(?i)^(?:SET\\s+IDENTITY_INSERT|SET\\s+ANSI_|SET\\s+NOCOUNT|USE\\s+)").containsMatchIn(t))flush()
                }
                if(quote==null&&!bracket&&!backtick&&protectGoBatch&&trimmed.matches(Regex("(?i)^END\\s*;?$"))){flush();protectGoBatch=false}
            }
            flush()
        }
    }
    private data class TabularSample(val headers:List<String>, val rows:List<List<String>>)
    private fun safeTableName(fileName:String):String{
        val base=fileName.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_]+"),"_").trim('_').ifBlank{"ImportedData"}
        return if(base.firstOrNull()?.isDigit()==true) "T_$base" else base
    }
    private fun inferTabularType(values:List<String>):String{
        val nonBlank=values.filter{it.isNotBlank()}
        if(nonBlank.isEmpty())return "TEXT"
        if(nonBlank.all{it.matches(Regex("[-+]?\\d+"))})return "INTEGER"
        if(nonBlank.all{it.matches(Regex("[-+]?(?:\\d+\\.\\d+|\\d+\\.?)"))})return "REAL"
        return "TEXT"
    }
    private fun parseDelimitedRecord(reader:Reader, delimiter:Char):String?{
        val out=StringBuilder(256);var inQuotes=false;var sawAny=false
        while(true){
            val code=reader.read()
            if(code<0)return if(sawAny)out.toString() else null
            sawAny=true;val ch=code.toChar()
            if(ch=='"'){
                out.append(ch)
                if(inQuotes){
                    reader.mark(1)
                    val next=reader.read()
                    if(next=='"'.code){out.append(next.toChar())}else{if(next>=0)reader.reset();inQuotes=false}
                }else inQuotes=true
            }else if((ch=='\n'||ch=='\r')&&!inQuotes){
                if(ch=='\r'){reader.mark(1);val next=reader.read();if(next!='\n'.code&&next>=0)reader.reset()}
                return out.toString()
            }else out.append(ch)
        }
    }
    private fun parseCsvLine(line:String, delimiter:Char):List<String>{
        val out=mutableListOf<String>();val cur=StringBuilder();var quoted=false;var i=0
        while(i<line.length){
            val ch=line[i]
            if(ch=='"'){
                if(quoted&&i+1<line.length&&line[i+1]=='"'){cur.append('"');i+=2;continue}
                quoted=!quoted
            }else if(ch==delimiter&&!quoted){out.add(cur.toString());cur.setLength(0)}else cur.append(ch)
            i++
        }
        out.add(cur.toString());return out
    }
    private fun readDelimitedSample(uri:Uri,delimiter:Char):TabularSample{
        contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use{r->
            val first=parseDelimitedRecord(r,delimiter) ?: throw Exception("The file is empty")
            val headers0=parseCsvLine(first,delimiter).mapIndexed{idx,v->v.trim().ifBlank{"column_${idx+1}"}}
            val headers=headers0.mapIndexed{idx,h->if(headers0.indexOf(h)==idx)h else "${h}_$idx"}
            val rows=mutableListOf<List<String>>()
            while(rows.size<1000){checkImportCancelled();val record=parseDelimitedRecord(r,delimiter)?:break;if(record.isBlank())continue;rows.add(parseCsvLine(record,delimiter))}
            if(headers.isEmpty())throw Exception("No columns were found")
            return TabularSample(headers,rows)
        } ?: throw Exception("Could not read input file")
    }
    private fun importDelimitedStream(uri:Uri,fileName:String,delimiter:Char):ImportOutcome{
        val sample=readDelimitedSample(uri,delimiter);val target=File(filesDir,"Imported_${System.currentTimeMillis()}_${fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")}.db")
        var fresh:SQLiteDatabase?=null;var rows=0L;var skipped=0L;var inTx=false
        try{
            fresh=SQLiteDatabase.openOrCreateDatabase(target,null);configureDatabase(fresh)
            val table=safeTableName(fileName);val defs=sample.headers.mapIndexed{i,h->"\"${h.replace("\"","\"\"")}\" ${inferTabularType(sample.rows.mapNotNull{it.getOrNull(i)})}"}.joinToString(", ")
            fresh.execSQL("CREATE TABLE \"${table.replace("\"","\"\"")}\" ($defs)")
            val placeholders=sample.headers.joinToString(", "){"?"};val sql="INSERT INTO \"${table.replace("\"","\"\"")}\" (${sample.headers.joinToString(", "){"\"${it.replace("\"","\"\"")}\""}}) VALUES ($placeholders)"
            fresh.beginTransaction();inTx=true
            val statement=fresh.compileStatement(sql);var batch=0
            contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use{r->
                parseDelimitedRecord(r,delimiter) // header
                while(true){checkImportCancelled();val record=parseDelimitedRecord(r,delimiter)?:break;if(record.isBlank())continue
                    val vals=parseCsvLine(record,delimiter)
                    if(vals.size>sample.headers.size){skipped++;continue}
                    for(i in sample.headers.indices){if(i<vals.size)statement.bindString(i+1,vals[i]) else statement.bindNull(i+1)}
                    statement.executeInsert();rows++;batch++
                    if(batch>=5000){fresh.setTransactionSuccessful();fresh.endTransaction();inTx=false;fresh.beginTransaction();inTx=true;batch=0}
                    if(rows%5000L==0L)runOnUiThread{if(importInProgress)importDetailView?.text="$rows rows processed"}
                }
            } ?: throw Exception("Could not reopen $fileName")
            checkImportCancelled();if(inTx){fresh.setTransactionSuccessful();fresh.endTransaction();inTx=false}
            return ImportOutcome(fresh,target,table,"Imported $fileName · ${humanBytes(target.length())} · $rows rows"+(if(skipped>0)" · skipped $skipped malformed row(s)" else "")).also{fresh=null}
        }catch(e:Exception){try{if(inTx)fresh?.endTransaction()}catch(_:Exception){};try{fresh?.close()}catch(_:Exception){};target.delete();throw e}
    }
    private fun jsonScalar(reader:JsonReader):String{
        return when(reader.peek()){
            JsonToken.NULL->{reader.nextNull();""}
            JsonToken.BOOLEAN->reader.nextBoolean().toString()
            JsonToken.NUMBER->reader.nextString()
            JsonToken.STRING->reader.nextString()
            else->{reader.skipValue();""}
        }
    }
    private fun readJsonObject(reader:JsonReader):LinkedHashMap<String,String>{
        val map=LinkedHashMap<String,String>();reader.beginObject()
        while(reader.hasNext()){val key=reader.nextName();map[key]=jsonScalar(reader)}
        reader.endObject();return map
    }
    private fun openJsonReader(uri:Uri):JsonReader{
        val input=contentResolver.openInputStream(uri)?:throw Exception("Could not read JSON file")
        return JsonReader(InputStreamReader(input,Charsets.UTF_8)).apply{isLenient=true}
    }
    private fun importJsonStream(uri:Uri,fileName:String):ImportOutcome{
        val firstNonSpace=contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use{r->
            var c:Int;do{c=r.read()}while(c>=0&&c.toChar().isWhitespace());c
        } ?: throw Exception("Could not read $fileName")
        val array=firstNonSpace== '['.code
        val sample=LinkedHashMap<String,MutableList<String>>()
        runCatching{openJsonReader(uri).use{jr->if(array)jr.beginArray();var n=0;while((array&&jr.peek()!=JsonToken.END_ARRAY)||(!array&&jr.peek()!=JsonToken.END_DOCUMENT)){val obj=readJsonObject(jr);for((k,v) in obj){sample.getOrPut(k){mutableListOf()}.let{if(it.size<100)it.add(v)}};n++;if(n>=1000)break;if(!array&&jr.peek()==JsonToken.END_DOCUMENT)break};if(array)jr.endArray()}}.getOrElse{throw Exception("Invalid JSON/NDJSON: ${it.message?:("parse error")}")}
        if(sample.isEmpty())throw Exception("No JSON objects were found")
        val headers=sample.keys.toList();val target=File(filesDir,"Imported_${System.currentTimeMillis()}_${fileName.replace(Regex("[^A-Za-z0-9._-]"),"_")}.db");var fresh:SQLiteDatabase?=null;var rows=0L;var inTx=false
        try{
            fresh=SQLiteDatabase.openOrCreateDatabase(target,null);configureDatabase(fresh);val table=safeTableName(fileName)
            val defs=headers.map{h->"\"${h.replace("\"","\"\"")}\" ${inferTabularType(sample[h].orEmpty())}"}.joinToString(", ");fresh.execSQL("CREATE TABLE \"${table.replace("\"","\"\"")}\" ($defs)")
            val sql="INSERT INTO \"${table.replace("\"","\"\"")}\" (${headers.joinToString(", "){"\"${it.replace("\"","\"\"")}\""}}) VALUES (${headers.joinToString(", "){"?"}})";val st=fresh.compileStatement(sql)
            fresh.beginTransaction();inTx=true
            openJsonReader(uri).use{jr->
                if(array)jr.beginArray()
                while((array&&jr.peek()!=JsonToken.END_ARRAY)||(!array&&jr.peek()!=JsonToken.END_DOCUMENT)){
                    checkImportCancelled()
                    val obj=readJsonObject(jr)
                    for((i,h) in headers.withIndex()){
                        val v=obj[h]
                        if(v==null)st.bindNull(i+1) else st.bindString(i+1,v)
                    }
                    st.executeInsert();rows++
                    if(rows%5000L==0L){
                        fresh!!.setTransactionSuccessful();fresh!!.endTransaction();inTx=false;fresh!!.beginTransaction();inTx=true
                        runOnUiThread{if(importInProgress)importDetailView?.text="$rows JSON rows processed"}
                    }
                }
                if(array)jr.endArray()
            }
            checkImportCancelled();if(inTx){fresh.setTransactionSuccessful();fresh.endTransaction();inTx=false}
            return ImportOutcome(fresh,target,table,"Imported $fileName · ${humanBytes(target.length())} · $rows JSON rows").also{fresh=null}
        }catch(e:Exception){try{if(inTx)fresh?.endTransaction()}catch(_:Exception){};try{fresh?.close()}catch(_:Exception){};target.delete();throw e}
    }
    private fun humanBytes(bytes:Long):String{
        if(bytes<1024)return "$bytes B";if(bytes<1024*1024)return "${bytes/1024} KB";if(bytes<1024*1024*1024)return String.format(Locale.US,"%.1f MB",bytes/1024.0/1024.0);return String.format(Locale.US,"%.2f GB",bytes/1024.0/1024.0/1024.0)
    }
    private fun isQueryStatement(s:String)=s.trimStart().let{it.startsWith("SELECT",true)||it.startsWith("WITH",true)||it.startsWith("PRAGMA",true)||it.startsWith("EXPLAIN",true)||it.startsWith("SHOW",true)||it.startsWith("DESCRIBE",true)||it.startsWith("DESC",true)}
    private fun leadingKeyword(s:String)=Regex("^\\s*([A-Za-z]+)").find(s)?.groupValues?.get(1)?.uppercase(Locale.US)?: "SQL"
    private fun splitSql(s:String):List<String>{
        val out=mutableListOf<String>();val current=StringBuilder();var quote:Char?=null;var bracket=false;var backtick=false;var lineComment=false;var blockComment=false;var i=0
        fun emit(){val part=current.toString().trim();if(part.isNotBlank())out.add(part);current.setLength(0)}
        while(i<s.length){
            val c=s[i];val next=if(i+1<s.length)s[i+1] else '\u0000'
            if(lineComment){current.append(c);if(c=='\n')lineComment=false;i++;continue}
            if(blockComment){current.append(c);if(c=='*'&&next=='/'){current.append(next);i+=2;blockComment=false}else i++;continue}
            if(quote!=null){
                current.append(c)
                if(c==quote){
                    if(next==quote){current.append(next);i+=2;continue}
                    quote=null
                } else if(c=='\\' && next==quote){current.append(next);i+=2;continue}
                i++;continue
            }
            if(bracket){current.append(c);if(c==']'){if(next==']'){current.append(next);i+=2;continue};bracket=false};i++;continue}
            if(backtick){current.append(c);if(c=='`'){if(next=='`'){current.append(next);i+=2;continue};backtick=false};i++;continue}
            if(c=='-'&&next=='-'){current.append(c).append(next);i+=2;lineComment=true;continue}
            if(c=='/'&&next=='*'){current.append(c).append(next);i+=2;blockComment=true;continue}
            if(c=='\''){current.append(c);quote='\'';i++;continue}
            if(c=='"'){current.append(c);quote='\"';i++;continue}
            if(c=='`'){current.append(c);backtick=true;i++;continue}
            if(c=='['){current.append(c);bracket=true;i++;continue}
            if(c==';'){current.append(c);emit();i++;continue}
            current.append(c);i++
        }
        emit()
        // SQL Server batch separators are handled as standalone lines after regular splitting.
        val batches=mutableListOf<String>();for(part in out){val lines=part.lines();var buf=StringBuilder();for(line in lines){if(Regex("(?i)^\\s*GO(?:\\s+\\d+)?\\s*$").matches(line)){if(buf.isNotBlank()){batches.add(buf.toString().trim());buf=StringBuilder()}}else{buf.append(line).append('\n')}};if(buf.isNotBlank())batches.add(buf.toString().trim())}
        return batches
    }
    private fun stripLineComments(s:String):String{
        val out=StringBuilder();var quote:Char?=null;var bracket=false;var backtick=false;var i=0
        while(i<s.length){val c=s[i];val next=if(i+1<s.length)s[i+1] else '\u0000'
            if(quote!=null){out.append(c);if(c==quote){if(next==quote){out.append(next);i+=2;continue};quote=null};i++;continue}
            if(bracket){out.append(c);if(c==']'){if(next==']'){out.append(next);i+=2;continue};bracket=false};i++;continue}
            if(backtick){out.append(c);if(c=='`'){if(next=='`'){out.append(next);i+=2;continue};backtick=false};i++;continue}
            if(c=='\''||c=='"'){out.append(c);quote=c;i++;continue};if(c=='`'){out.append(c);backtick=true;i++;continue};if(c=='['){out.append(c);bracket=true;i++;continue}
            if(c=='-'&&next=='-'){while(i<s.length&&s[i]!='\n')i++;continue};if(c=='#'&&(i==0||s[i-1]=='\n')){while(i<s.length&&s[i]!='\n')i++;continue};out.append(c);i++}
        return out.toString()
    }
    private fun mysqlIdentifierToSqlite(sql:String):String{
        var s=sql.trim().removeSuffix(";").trim()
        val leading=stripLeadingSqlComments(s).trim()
        if(leading.matches(Regex("(?is)^SHOW\\s+TABLES\\s*$"))){
            return "SELECT name AS Tables FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name"
        }
        if(leading.matches(Regex("(?is)^SHOW\\s+DATABASES\\s*$"))){
            return "SELECT 'Local SQLite' AS \"Database\""
        }
        var m=Regex("(?is)^SHOW\\s+COLUMNS\\s+FROM\\s+(.+)$").find(leading)
        if(m!=null){
            val table=m.groupValues[1].trim().trim('`','"','[',']').substringAfterLast('.').trim('`','"','[',']')
            val safe=table.replace("'","''")
            return "PRAGMA table_info('$safe')"
        }
        m=Regex("(?is)^DESCRIBE\\s+(.+)$").find(leading) ?: Regex("(?is)^DESC\\s+(.+)$").find(leading)
        if(m!=null){
            val table=m.groupValues[1].trim().trim('`','"','[',']').substringAfterLast('.').trim('`','"','[',']')
            val safe=table.replace("'","''")
            return "PRAGMA table_info('$safe')"
        }
        m=Regex("(?is)^SHOW\\s+INDEX(?:ES)?\\s+FROM\\s+(.+)$").find(leading)
        if(m!=null){
            val table=m.groupValues[1].trim().trim('`','"','[',']').substringAfterLast('.').trim('`','"','[',']')
            val safe=table.replace("'","''")
            return "PRAGMA index_list('$safe')"
        }
        m=Regex("(?is)^SHOW\\s+CREATE\\s+TABLE\\s+(.+)$").find(leading)
        if(m!=null){
            val table=m.groupValues[1].trim().trim('`','"','[',']').substringAfterLast('.').trim('`','"','[',']')
            return "SELECT name, sql FROM sqlite_master WHERE type='table' AND name='${table.replace("'","''")}'"
        }
        // MySQL uses LIMIT offset, count; SQLite uses LIMIT count OFFSET offset.
        s=replaceOutsideSingleQuotes(s, Regex("(?i)\\bLIMIT\\s+(\\d+)\\s*,\\s*(\\d+)")){m2->"LIMIT ${m2.groupValues[2]} OFFSET ${m2.groupValues[1]}"}
        // Common MySQL date helpers that have direct SQLite equivalents.
        s=replaceOutsideSingleQuotes(s, Regex("(?i)\\bNOW\\s*\\(\\s*\\)")){"CURRENT_TIMESTAMP"}
        s=replaceOutsideSingleQuotes(s, Regex("(?i)\\bCURDATE\\s*\\(\\s*\\)")){"CURRENT_DATE"}
        s=replaceOutsideSingleQuotes(s, Regex("(?i)\\bCURTIME\\s*\\(\\s*\\)")){"CURRENT_TIME"}
        s=replaceOutsideSingleQuotes(s, Regex("(?i)\\bIF\\s*\\(([^(),]+),([^(),]+),([^()]+)\\)")){m2->"CASE WHEN ${m2.groupValues[1]} THEN ${m2.groupValues[2]} ELSE ${m2.groupValues[3]} END"}
        s=replaceOutsideSingleQuotes(s, Regex("(?is)MATCH\\s*\\(([^)]*)\\)\\s+AGAINST\\s*\\(\\s*'([^']*)'[^)]*\\)")){m2->
            val columns=m2.groupValues[1].split(',').map{it.trim()}.filter{it.isNotBlank()}
            val terms=m2.groupValues[2].replace("+"," ").replace("-"," ").split(Regex("\\s+")).map{it.trim()}.filter{it.isNotBlank()}
            if(columns.isEmpty()||terms.isEmpty())"1=1" else terms.joinToString(" AND "){term->"("+columns.joinToString(" OR "){col->"$col LIKE '%${term.replace("'","''")}%"+"'"}+ ")"}
        }
        s=replaceOutsideSingleQuotes(s, Regex("(?is)DATE_FORMAT\\s*\\(\\s*([^,]+?)\\s*,\\s*'([^']+)'\\s*\\)")){m2->
            val fmt=m2.groupValues[2].replace("%i","%M").replace("%s","%S")
            "strftime('$fmt', ${m2.groupValues[1].trim()})"
        }
        s=replaceOutsideSingleQuotes(s, Regex("(?is)CONCAT\\s*\\(\\s*([^,()]+)\\s*,\\s*([^,()]+)\\s*\\)")){m2->"(${m2.groupValues[1].trim()} || ${m2.groupValues[2].trim()})"}
        // Imported databases are flattened into one local SQLite schema, so remove
        s=replaceOutsideSingleQuotes(s, Regex("`([^`]+)`")){m2->"\"${m2.groupValues[1].replace("\"","\"\"")}\""}
        // MySQL's INSERT IGNORE maps directly to SQLite's conflict behavior.
        s=s.replace(Regex("(?i)^INSERT\\s+IGNORE\\s+INTO"), "INSERT OR IGNORE INTO")
        return s.trim()
    }
    private fun runCompatibleSql(sql:String):String{
        val cleaned=stripLeadingSqlComments(sql).trim().removeSuffix(";").trim()
        if(cleaned.matches(Regex("(?is)^(USE|SET|LOCK\\s+TABLES|UNLOCK\\s+TABLES|DELIMITER)\\b.*$"))) return ""
        return mysqlIdentifierToSqlite(sql)
    }
    private fun currentStatementAtCursor():String?{
        val text=editor.text.toString();if(text.isBlank())return null
        val cursor=editor.selectionStart.coerceIn(0,text.length)
        var start=0;var quote:Char?=null;var bracket=false;var backtick=false;var lineComment=false;var blockComment=false;var i=0
        while(i<text.length){
            val c=text[i];val next=if(i+1<text.length)text[i+1] else '\u0000'
            if(lineComment){if(c=='\n')lineComment=false;i++;continue}
            if(blockComment){if(c=='*'&&next=='/'){blockComment=false;i+=2}else i++;continue}
            if(quote!=null){if(c==quote){if(next==quote){i+=2;continue};quote=null};i++;continue}
            if(bracket){if(c==']'){if(next==']'){i+=2;continue};bracket=false};i++;continue}
            if(backtick){if(c=='`'){if(next=='`'){i+=2;continue};backtick=false};i++;continue}
            if(c=='-'&&next=='-'){lineComment=true;i+=2;continue}
            if(c=='/'&&next=='*'){blockComment=true;i+=2;continue}
            if(c=='\''||c=='"'){quote=c;i++;continue}
            if(c=='`'){backtick=true;i++;continue}
            if(c=='['){bracket=true;i++;continue}
            if(c==';'){
                val end=i+1
                if(cursor>=start&&cursor<=end){val part=text.substring(start,end).trim();return part.ifBlank{null}}
                start=end
            }
            i++
        }
        return if(cursor>=start)text.substring(start).trim().ifBlank{null}else null
    }
    fun onEditorSelectionChanged(){updateCurrentStatementIndicator()}
    private fun currentStatementNumberAtCursor():Int?{
        val text=editor.text.toString();if(text.isBlank())return null
        val cursor=editor.selectionStart.coerceIn(0,text.length)
        var statement=1;var saw=false;var quote:Char?=null;var bracket=false;var backtick=false;var lineComment=false;var blockComment=false;var i=0
        while(i<cursor){val c=text[i];val next=if(i+1<text.length)text[i+1] else '\u0000'
            if(lineComment){if(c=='\n')lineComment=false;i++;continue}
            if(blockComment){if(c=='*'&&next=='/'){blockComment=false;i+=2}else i++;continue}
            if(quote!=null){if(c==quote){if(next==quote){i+=2;continue};quote=null};i++;continue}
            if(bracket){if(c==']'){if(next==']'){i+=2;continue};bracket=false};i++;continue}
            if(backtick){if(c=='`'){if(next=='`'){i+=2;continue};backtick=false};i++;continue}
            if(c=='-'&&next=='-'){lineComment=true;i+=2;continue}
            if(c=='/'&&next=='*'){blockComment=true;i+=2;continue}
            if(c=='\''||c=='"'){quote=c;saw=true;i++;continue}
            if(c=='`'){backtick=true;saw=true;i++;continue}
            if(c=='['){bracket=true;saw=true;i++;continue}
            if(c==';'){if(saw)statement++;saw=false;i++;continue}
            if(!c.isWhitespace())saw=true
            i++
        }
        return if(saw)statement else null
    }
    private fun updateCurrentStatementIndicator(){currentStatementIndicator?.let{v->val n=currentStatementNumberAtCursor();v.text=if(n!=null)"Statement $n" else "No statement";v.alpha=if(n!=null)1f else .55f}}
    private fun animateContentSwap(view:View){view.animate().cancel();view.alpha=.82f;view.translationY=dp(2).toFloat();view.animate().alpha(1f).translationY(0f).setDuration(150).setInterpolator(android.view.animation.DecelerateInterpolator()).start()}
    private fun runSelectedOrAll(currentOnly:Boolean=false){
        if(queryRunning){queryCancelled=true;activeQueryCancellation?.cancel();status.text="Stopping query…";return}
        val a=editor.selectionStart;val z=editor.selectionEnd;val selected=if(a!=z)editor.text.substring(minOf(a,z),maxOf(a,z)).trim() else "";val current=currentStatementAtCursor();val source=when{currentOnly->current.orEmpty();selected.isNotEmpty()->selected;else->editor.text.toString()};val statements=splitSql(source).filter{stripLineComments(it).isNotBlank()};if(statements.isEmpty()){showError(if(currentOnly)"No SQL statement at the cursor" else "Nothing to run");return}
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        queryRunning=true;queryCancelled=false;val cancellation=CancellationSignal();activeQueryCancellation=cancellation;status.text=if(currentOnly)"Running current statement…" else "Running ${statements.size} statement(s)…";status.setTextColor(Color.rgb(170,165,178))
        Thread{var ok=0;var err=0;var schemaChanged=false
            for((idx,s) in statements.withIndex()){if(queryCancelled)break;val label=leadingKeyword(s)+" "+(idx+1)+(if(currentOnly)" · current" else if(selected.isNotEmpty())" · selected" else "");val started=System.nanoTime();try{
                val compatible=runCompatibleSql(s)
                if(compatible.isBlank() && s.trimStart().matches(Regex("(?is)^(USE|SET|LOCK\\s+TABLES|UNLOCK\\s+TABLES|DELIMITER)\\b.*"))){
                    runOnUiThread{if(!queryCancelled)addResultTab("${leadingKeyword(s)} ${idx+1} · OK",buildMessageView("✓ MySQL session/dump directive accepted for the local SQLite workspace\n\nExecution: ${elapsed(started)} ms"),false,null,"${leadingKeyword(s)} ${idx+1}",query=s)}
                } else if(isQueryStatement(s)){
                    if(compatible.trimStart().startsWith("EXPLAIN QUERY PLAN",true)){val rows=planRows(compatible);val csv=rows.map{listOf(it.first.toString(),it.second.toString(),it.third)};runOnUiThread{if(!queryCancelled)addResultTab("Plan ${idx+1}",buildPlanView(rows),false,csv,"Plan ${idx+1}",query=s)}}
                    else{executionDb.rawQuery(compatible,null,cancellation).use{c->val data=readCursorRows(c);runOnUiThread{if(!queryCancelled)addResultTab("${leadingKeyword(s)} ${idx+1} · ${data.second}${if(data.third)"+" else ""} rows",buildGrid(data.first,data.third),false,data.first,"${leadingKeyword(s)} ${idx+1}",query=s)}}}
                }
                else{executionDb.execSQL(compatible);if(label.startsWith("CREATE",true)||label.startsWith("DROP",true)||label.startsWith("ALTER",true))schemaChanged=true;val changed=executionDb.rawQuery("SELECT changes()",null).use{c->c.moveToFirst();c.getInt(0)};val message="✓ OK — $changed row(s) affected\n\nExecution: ${elapsed(started)} ms";runOnUiThread{if(!queryCancelled)addResultTab("${leadingKeyword(s)} ${idx+1} · ${changed} changed",buildMessageView(message),false,null,"${leadingKeyword(s)} ${idx+1}",query=s)}};ok++;history.add(0,s.trim());trimHistory()
            }catch(e:Exception){if(queryCancelled)break;val msg=e.message?:"SQL error";val location=lineColumnFor(editor.text.toString(),s);val elapsedMs=elapsed(started);runOnUiThread{if(!queryCancelled)addResultTab("${leadingKeyword(s)} ${idx+1} · Error",buildErrorView(msg,location,elapsedMs,s),true,null,"${leadingKeyword(s)} ${idx+1}",msg,query=s)};err++}}
            runOnUiThread{queryRunning=false;activeQueryCancellation=null;if(queryCancelled){queryCancelled=false;status.text="Query stopped";status.setTextColor(Color.rgb(190,185,195))}else{while(tabs.size>30)removeResultTab(0);if(tabs.isNotEmpty())selectTab(tabs.lastIndex)else showPlaceholder();savePrefs();status.text=if(err==0)"✓ Ran $ok statement(s)"+when{currentOnly->" • current statement";selected.isNotEmpty()->" • selected only";else->""} else "✕ $err of ${statements.size} statement(s) failed";status.setTextColor(if(err==0)green else red);if(schemaChanged)refreshSchemaPanel()}}
        }.start()
    }
    private fun lineColumnFor(sql:String,fragment:String):String{
        val idx=sql.indexOf(fragment.trim()).let{if(it<0)0 else it};val line=sql.substring(0,idx).count{it=='\n'}+1;val last=sql.lastIndexOf('\n',idx-1);val col=idx-(if(last<0)-1 else last);return "line $line, column $col"
    }
    private fun elapsed(s:Long)=((System.nanoTime()-s)/1_000_000L).toString(); private fun trimHistory(){while(history.size>30)history.removeAt(history.lastIndex)}
    private fun readCursorRows(c:Cursor):Triple<List<List<String>>,Int,Boolean>{
        val data=mutableListOf<List<String>>();data.add((0 until c.columnCount).map{c.getColumnName(it)})
        var count=0;var truncated=false
        while(count<1000&&c.moveToNext()){data.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)});count++}
        if(count==1000&&c.moveToNext())truncated=true
        return Triple(data,count,truncated)
    }
    private fun buildTableView(c:Cursor):Triple<View,Int,List<List<String>>>{val r=readCursorRows(c);return Triple(buildGrid(r.first,r.third),r.second,r.first)}
    private fun buildGrid(data:List<List<String>>,truncated:Boolean=false):View{
        if(data.isEmpty()) return TextView(this).apply{text="No columns";setPadding(dp(16),dp(16),dp(16),dp(16));setTextColor(white)}
        return VirtualResultGridView(this, data, truncated, { column -> sortActiveResult(column) }, { value -> copyText(value) }, resultZoom) { resultZoom = it }
    }
    private fun cell(v:String,head:Boolean,onClick:()->Unit):TextView{val t=TextView(this);t.text=v;t.textSize=12f;t.setTextColor(if(head)Color.rgb(185,181,191)else white);t.setPadding(16,12,16,12);t.setBackgroundColor(if(head) Color.rgb(28,31,39) else Color.rgb(24,26,33));if(head)t.setOnClickListener{onClick()} else t.setOnLongClickListener{onClick();true};return t}
    private fun sortActiveResult(column:Int){if(activeTab<0||tabs[activeTab].csv==null)return;val old=tabs[activeTab].csv!!;if(old.size<2)return;val ascending=!(tabs[activeTab].button.tag as? Boolean ?: false);val sorted=old.drop(1).sortedWith(Comparator<List<String>>{a,b->compareCells(a.getOrElse(column){""},b.getOrElse(column){""})}).let{if(ascending)it else it.reversed()};val data=listOf(old[0])+sorted;tabs[activeTab].button.tag=ascending;tabs[activeTab].button.text=tabs[activeTab].title+" · sort ${if(ascending)"↑" else "↓"}";tabs[activeTab]=tabs[activeTab].copy(view=buildGrid(data),csv=data);selectTab(activeTab)}
    private fun compareCells(a:String,b:String):Int{val da=a.toDoubleOrNull();val db=b.toDoubleOrNull();return if(da!=null&&db!=null)da.compareTo(db) else a.compareTo(b,true)}
    private fun copyText(v:String){(getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("SQL cell",v));Toast.makeText(this,"Cell copied",Toast.LENGTH_SHORT).show()}
    private fun addResultTab(label:String,content:View,isError:Boolean,csv:List<List<String>>?,title:String,query:String?=null){
        val wrap=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(4),0,dp(4),0);background=rounded(Color.rgb(25,26,29),1,Color.rgb(49,51,56),12f);clipChildren=false;clipToPadding=false}
        val btn=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{
            text=label;isAllCaps=false;minHeight=0;minWidth=0;setPadding(dp(8),0,dp(4),0);textSize=11f
            maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END;gravity=Gravity.CENTER_VERTICAL;stateListAnimator=null
            background=ColorDrawable(Color.TRANSPARENT);contentDescription=label
        }
        val close=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{
            text="×";isAllCaps=false;minHeight=0;minWidth=0;setPadding(0,0,0,0);textSize=14f
            gravity=Gravity.CENTER;contentDescription="Close $label";stateListAnimator=null;background=ColorDrawable(Color.TRANSPARENT)
        }
        wrap.addView(btn,LinearLayout.LayoutParams(0,dp(30),1f));wrap.addView(close,LinearLayout.LayoutParams(dp(28),dp(30)))
        val lp=LinearLayout.LayoutParams(dp(174),dp(34)).apply{marginEnd=dp(6);gravity=Gravity.CENTER_VERTICAL}
        tabStrip.addView(wrap,lp)
        val tab=ResultTab(btn,close,wrap,content,isError,csv,title,query=query);tabs.add(tab)
        btn.setOnClickListener{val i=tabs.indexOfFirst{it.container===wrap};if(i>=0)selectTab(i)};close.setOnClickListener{val i=tabs.indexOfFirst{it.container===wrap};if(i>=0)removeResultTab(i)}
    }
    private fun addResultTab(label:String,content:View,isError:Boolean,csv:List<List<String>>?,title:String,errorMessage:String,query:String?=null){
        val before=tabs.size
        addResultTab(label,content,isError,csv,title,query)
        if(tabs.size>before){
            val index=tabs.lastIndex
            tabs[index]=tabs[index].copy(errorMessage=errorMessage)
        }
    }
    private fun removeResultTab(index:Int){
        if(index<0||index>=tabs.size)return
        val wasActive=index==activeTab
        tabStrip.removeView(tabs[index].container);tabs.removeAt(index)
        activeTab=when{tabs.isEmpty()->-1;wasActive->minOf(index,tabs.lastIndex);index<activeTab->activeTab-1;else->activeTab}
        if(activeTab>=0)selectTab(activeTab) else showPlaceholder()
    }
    private fun selectTab(i:Int){
        if(i<0||i>=tabs.size)return
        activeTab=i;resultContainer.removeAllViews();resultContainer.addView(tabs[i].view);animateContentSwap(resultContainer)
        for((j,t) in tabs.withIndex()){
            val selected=j==i
            t.container.background=rounded(if(selected)Color.rgb(52,54,59) else Color.rgb(25,26,29),1,if(selected)Color.rgb(52,54,59) else Color.rgb(49,51,56),12f)
            t.button.setBackgroundColor(Color.TRANSPARENT)
            t.closeButton.setBackgroundColor(Color.TRANSPARENT)
            t.button.setTextColor(if(selected)Color.WHITE else if(t.isError)red else Color.rgb(185,181,191))
            t.closeButton.setTextColor(if(selected)Color.WHITE else if(t.isError)red else Color.rgb(151,153,158))
        }
        findViewById<Button>(R.id.explainButton)?.apply{isEnabled=editor.text.toString().trim().isNotBlank();alpha=if(isEnabled)1f else .45f}
    }
    private fun clearResults(){tabStrip.removeAllViews();resultContainer.removeAllViews();tabs.clear();activeTab=-1;findViewById<Button>(R.id.explainButton)?.apply{isEnabled=editor.text.toString().trim().isNotBlank();alpha=if(isEnabled)1f else .45f}}
    private fun setupResizeHandle(){
        val handle=resizeHandle
        handle.setOnTouchListener(object:View.OnTouchListener{
            private var startY=0f
            private var startEditor=0
            private var startResults=0
            private var dragging=false
            override fun onTouch(v:View,event:MotionEvent):Boolean{
                when(event.actionMasked){
                    MotionEvent.ACTION_DOWN->{
                        startY=event.rawY
                        startEditor=editorSurface.height
                        startResults=resultArea.height
                        dragging=true
                        v.parent.requestDisallowInterceptTouchEvent(true)
                        v.alpha=1f
                        return true
                    }
                    MotionEvent.ACTION_MOVE->{
                        if(!dragging)return true
                        val total=(startEditor+startResults).coerceAtLeast(1)
                        val delta=(event.rawY-startY).toInt()
                        val minEditor=dp(120)
                        val minResults=dp(150)
                        val newEditor=(startEditor+delta).coerceIn(minEditor,(total-minResults).coerceAtLeast(minEditor))
                        val newResults=total-newEditor
                        (editorSurface.layoutParams as? LinearLayout.LayoutParams)?.let{lp->lp.height=newEditor;lp.weight=0f;editorSurface.layoutParams=lp}
                        (resultArea.layoutParams as? LinearLayout.LayoutParams)?.let{lp->lp.height=newResults;lp.weight=0f;resultArea.layoutParams=lp}
                        editorSurface.requestLayout();resultArea.requestLayout()
                        return true
                    }
                    MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{
                        dragging=false
                        v.parent.requestDisallowInterceptTouchEvent(false)
                        return true
                    }
                }
                return true
            }
        })
    }
    private fun renderScriptTabs(){
        if(!::scriptTabStrip.isInitialized)return
        scriptTabStrip.removeAllViews()
        scriptTabs.forEachIndexed{index,tab->
            val selected=index==activeScriptTab
            val label=(if(tab.dirty)"● " else "")+tab.name
            val wrap=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(4),0,dp(4),0);background=rounded(if(selected)Color.rgb(52,54,59) else Color.rgb(25,26,29),1,if(selected)Color.rgb(52,54,59) else Color.rgb(49,51,56),12f)}
            val b=TextView(this).apply{
                text=label;setTextColor(if(selected)Color.WHITE else Color.rgb(198,199,202));textSize=11f;gravity=Gravity.CENTER_VERTICAL;maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END
                setPadding(dp(7),0,dp(4),0);contentDescription="${tab.name}${if(tab.dirty)" unsaved" else ""}";isClickable=true
                setOnClickListener{switchScriptTab(index)}
                setOnLongClickListener{
                    cardListDialog("Query · ${tab.name}",listOf("Rename")){renameScriptTab(index)}; true
                }
            }
            val close=TextView(this).apply{
                text="×";setTextColor(if(selected)Color.WHITE else Color.rgb(151,153,158));textSize=14f;gravity=Gravity.CENTER;setPadding(0,0,0,0);isClickable=true;contentDescription="Close ${tab.name}"
                setOnClickListener{closeScriptTab(index)}
            }
            wrap.addView(b,LinearLayout.LayoutParams(0,dp(30),1f));wrap.addView(close,LinearLayout.LayoutParams(dp(28),dp(30)))
            wrap.setOnLongClickListener{cardListDialog("Query · ${tab.name}",listOf("Rename")){renameScriptTab(index)};true}
            scriptTabStrip.addView(wrap,LinearLayout.LayoutParams(dp(156),dp(32)).apply{marginEnd=dp(5)})
        }
        val add=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="+";isAllCaps=false;minHeight=0;minWidth=0;setPadding(0,0,0,0);textSize=15f;contentDescription="New query tab";stateListAnimator=null;setOnClickListener{newScriptTab()}}
        scriptTabStrip.addView(add,LinearLayout.LayoutParams(dp(38),dp(32)))
    }
    private fun setupScriptTabs(){ if(::scriptTabStrip.isInitialized)renderScriptTabs() }
    private fun draftDir():File=File(filesDir,"lily_drafts").apply{if(!exists())mkdirs()}
    private fun restoreScriptTabs(defaultSql:String){
        scriptTabs.clear();var restored=false
        val encoded=prefs.getString("script_tabs_json",null)
        if(!encoded.isNullOrBlank()){
            runCatching{
                val arr=JSONArray(encoded)
                for(i in 0 until arr.length()){
                    val o=arr.getJSONObject(i);val draft=File(draftDir(),"query_$i.sql")
                    val text=if(draft.exists())draft.readText(Charsets.UTF_8) else ""
                    scriptTabs.add(ScriptTab(o.optString("name","Query ${i+1}"),text,o.optInt("selection",0),o.optBoolean("dirty",false)))
                }
                restored=scriptTabs.isNotEmpty()
            }.getOrElse{scriptTabs.clear()}
        }
        if(!restored)scriptTabs.add(ScriptTab("Query 1",defaultSql,defaultSql.length,false))
        activeScriptTab=prefs.getInt("active_script_tab",0).coerceIn(0,scriptTabs.lastIndex)
        switchingScriptTab=true;editor.setText(scriptTabs[activeScriptTab].text);editor.setSelection(scriptTabs[activeScriptTab].selection.coerceIn(0,editor.length()));switchingScriptTab=false
        renderScriptTabs()
    }
    private fun saveScriptTabs(){
        if(scriptTabs.isEmpty())return
        runCatching{
            val dir=draftDir();val arr=JSONArray()
            scriptTabs.forEachIndexed{i,t->{ File(dir,"query_$i.sql").writeText(t.text,Charsets.UTF_8); arr.put(JSONObject().apply{put("name",t.name);put("selection",t.selection.coerceAtLeast(0));put("dirty",t.dirty)}) }}
            dir.listFiles()?.filter{it.name.startsWith("query_")&&it.name.endsWith(".sql")&&it.name.removePrefix("query_").removeSuffix(".sql").toIntOrNull()?.let{n->n>=scriptTabs.size}==true}?.forEach{it.delete()}
            prefs.edit().putString("script_tabs_json",arr.toString()).putInt("active_script_tab",activeScriptTab.coerceAtLeast(0)).apply()
        }
    }
    private fun persistCurrentScript(){if(scriptTabs.isNotEmpty()&&activeScriptTab in scriptTabs.indices){scriptTabs[activeScriptTab].text=editor.text.toString();scriptTabs[activeScriptTab].selection=editor.selectionStart.coerceAtLeast(0);saveScriptTabs()}}
    private fun newScriptTab(){persistCurrentScript();val n=(scriptTabs.size+1);scriptTabs.add(ScriptTab("Query $n","",0,false));saveScriptTabs();switchScriptTab(scriptTabs.lastIndex)}
    private fun switchScriptTab(index:Int){if(index !in scriptTabs.indices)return;persistCurrentScript();activeScriptTab=index;switchingScriptTab=true;editor.setText(scriptTabs[index].text);editor.setSelection(scriptTabs[index].selection.coerceIn(0,editor.length()));switchingScriptTab=false;renderScriptTabs();highlight();updateAutocomplete();updateCurrentStatementIndicator();animateContentSwap(editor);editor.requestFocus()}
    private fun closeScriptTab(index:Int){if(scriptTabs.size==1){showWindowToast("Keep at least one query tab");return};val wasActive=index==activeScriptTab;scriptTabs.removeAt(index);if(wasActive)activeScriptTab=index.coerceAtMost(scriptTabs.lastIndex);else if(index<activeScriptTab)activeScriptTab--;switchingScriptTab=true;editor.setText(scriptTabs[activeScriptTab].text);editor.setSelection(scriptTabs[activeScriptTab].selection.coerceIn(0,editor.length()));switchingScriptTab=false;saveScriptTabs();renderScriptTabs();highlight();updateAutocomplete();updateCurrentStatementIndicator();animateContentSwap(editor)}
    private fun renameScriptTab(index:Int){val input=EditText(this).apply{setSingleLine(true);setText(scriptTabs[index].name);setTextColor(white);setHintTextColor(Color.rgb(105,108,119));background=rounded(Color.rgb(28,30,38),1,Color.rgb(54,56,66),9f);setPadding(dp(10),0,dp(10),0)};cardDialog("Rename query",input,"Rename"){val n=input.text.toString().trim();if(n.isNotBlank()){scriptTabs[index].name=n;saveScriptTabs();renderScriptTabs()}}.show()}
    private fun setupWindowDots(){
        findViewById<View>(R.id.windowDot1)?.apply{contentDescription="Toggle database sidebar";setOnClickListener{toggleSidebar()}}
        findViewById<View>(R.id.windowDot2)?.apply{contentDescription="Save SQL or export CSV";setOnClickListener{showEditorActions()}}
        findViewById<View>(R.id.windowDot3)?.apply{contentDescription="Open command palette";setOnClickListener{showCommandPalette()}}
        updateDotStates()
    }
    private fun showDatabaseSwitcher(){
        val anchor=findViewById<View>(R.id.windowDot1) ?: return
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(7),dp(7),dp(7),dp(7));background=rounded(Color.rgb(20,22,29),1,Color.rgb(58,53,64),14f)}
        val title=TextView(this).apply{text="Database Switcher";textSize=12f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(9),0,dp(9),0)}
        root.addView(title,LinearLayout.LayoutParams(-1,dp(30)))
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_NEVER}
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        scroll.addView(list)
        databaseTreePaths().forEach{(label,path)->addDatabaseTreeNode(list,label,path,label=="Parks & Recreation")}
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        databaseSwitcherPopup=PopupWindow(root,minOf(dp(300),resources.displayMetrics.widthPixels-dp(20)),minOf(dp(430),resources.displayMetrics.heightPixels-dp(90)),true)
        databaseSwitcherPopup!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));databaseSwitcherPopup!!.isOutsideTouchable=true;databaseSwitcherPopup!!.elevation=dp(18).toFloat()
        val loc=IntArray(2);anchor.getLocationOnScreen(loc);val width=minOf(dp(300),resources.displayMetrics.widthPixels-dp(20));val x=(loc[0]+anchor.width-dp(6)).coerceIn(dp(10),resources.displayMetrics.widthPixels-width-dp(10));val y=(loc[1]+anchor.height+dp(7)).coerceAtMost(resources.displayMetrics.heightPixels-minOf(dp(430),resources.displayMetrics.heightPixels-dp(90))-dp(10))
        databaseSwitcherPopup!!.showAtLocation(anchor,Gravity.TOP or Gravity.START,x,y);animatePopupIn(root)
    }
    private fun showEditorActions(){
        val anchor=findViewById<View>(R.id.windowDot2) ?: return
        var popup:PopupWindow?=null
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(5),dp(5),dp(5),dp(5));background=rounded(Color.rgb(20,22,29),1,Color.rgb(58,53,64),12f)}
        val save=TextView(this).apply{text="Save";textSize=12f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(12),0);background=rounded(Color.rgb(28,30,38),0,Color.TRANSPARENT,9f);isClickable=true;setOnClickListener{popup?.dismiss();saveEditorAsFile()}}
        val csv=TextView(this).apply{text="CSV";textSize=12f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(12),0);background=rounded(Color.rgb(28,30,38),0,Color.TRANSPARENT,9f);isClickable=true;setOnClickListener{popup?.dismiss();exportCsv()}}
        root.addView(save,LinearLayout.LayoutParams(dp(148),dp(32)))
        root.addView(csv,LinearLayout.LayoutParams(dp(148),dp(32)).apply{topMargin=dp(3)})
        popup=PopupWindow(root,dp(158),dp(74),true)
        popup!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));popup!!.isOutsideTouchable=true;popup!!.elevation=dp(18).toFloat()
        val loc=IntArray(2);anchor.getLocationOnScreen(loc);val x=(loc[0]+anchor.width-dp(158)+dp(5)).coerceIn(dp(10),resources.displayMetrics.widthPixels-dp(168));val y=(loc[1]+anchor.height+dp(6)).coerceAtMost(resources.displayMetrics.heightPixels-dp(90))
        popup!!.showAtLocation(anchor,Gravity.TOP or Gravity.START,x,y);animatePopupIn(root)
    }
    private fun saveEditorAsFile(){
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/sql";putExtra(Intent.EXTRA_TITLE,"query.sql")}
        startActivityForResult(i,89)
    }
    private fun showCommandPalette(){
        val anchor=findViewById<View>(R.id.windowDot3) ?: return
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(7),dp(7),dp(7),dp(7));background=rounded(Color.rgb(20,22,29),1,Color.rgb(58,53,64),14f)}
        val search=EditText(this).apply{hint="Search commands";setHintTextColor(Color.rgb(105,108,119));setTextColor(white);textSize=13f;setSingleLine(true);setPadding(dp(12),0,dp(12),0);background=rounded(Color.rgb(28,30,38),1,Color.rgb(54,56,66),10f)}
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(6),0,0)}
        root.addView(search,LinearLayout.LayoutParams(-1,dp(36)))
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_NEVER;addView(list)}
        root.addView(scroll,LinearLayout.LayoutParams(-1,dp(0),1f))
        var popup:PopupWindow?=null
        val commands=listOf(
            "Schema Inspector" to {showSchemaInspector()},
            "Table Designer" to {showTableDesignerChooser()},
            "Data Editor" to {showDataEditorChooser()},
            "Query History" to {showHistory()},
            "Saved Snippets" to {showSnippetMenu()},
            "Practice" to {showPractice()},
            "Check Query" to {checkPractice()},
            "Profile Active Query" to {profileActiveQuery()},
            "Index Advisor" to {showIndexAdvisor()},
            "Go to Definition" to {goToDefinition()},
            "Search Active Result" to {searchActiveResult()},
            "Find & Replace" to {showFindReplace()},
            "Go to Line" to {showGoToLine()},
            "Format SQL" to {editor.setText(formatSql(editor.text.toString()));editor.setSelection(editor.length())},
            "Comment / Uncomment" to {toggleComment()},
            "Export Database" to {exportDatabase()},
            "Export Database as SQL" to {exportDatabaseSql()},
            "Export Result as JSON" to {exportJson()},
            "Optimize Database" to {optimizeDatabase()},
            "Database Performance" to {databasePerformanceInfo()},
            "Database Integrity Check" to {checkDatabaseIntegrity()},
            "Rename Query Tab" to {if(scriptTabs.isNotEmpty())renameScriptTab(activeScriptTab)}
        )
        fun render(filter:String){
            list.removeAllViews()
            commands.filter{it.first.contains(filter.trim(),true)}.forEachIndexed{index,pair->
                val row=TextView(this).apply{text=pair.first;textSize=12f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(10),0);background=rounded(Color.rgb(28,30,38),0,Color.TRANSPARENT,9f);isClickable=true;setOnClickListener{popup?.dismiss();pair.second()}}
                list.addView(row,LinearLayout.LayoutParams(-1,dp(32)).apply{if(index>0)topMargin=dp(3)})
            }
            if(list.childCount==0)list.addView(TextView(this).apply{text="No matching commands";textSize=12f;setTextColor(Color.rgb(125,128,139));gravity=Gravity.CENTER_VERTICAL;setPadding(dp(12),0,dp(12),0)},LinearLayout.LayoutParams(-1,dp(42)))
        }
        popup=PopupWindow(root,minOf(dp(258),resources.displayMetrics.widthPixels-dp(20)),dp(250),true)
        popup!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));popup!!.isOutsideTouchable=true;popup!!.elevation=dp(18).toFloat();popup!!.inputMethodMode=PopupWindow.INPUT_METHOD_NEEDED
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render(s?.toString().orEmpty())};override fun afterTextChanged(e:Editable?){} })
        render("")
        val loc=IntArray(2);anchor.getLocationOnScreen(loc);val width=minOf(dp(258),resources.displayMetrics.widthPixels-dp(20));val x=(resources.displayMetrics.widthPixels-width-dp(10)).coerceAtLeast(dp(10));val y=(loc[1]+anchor.height+dp(6)).coerceAtMost(resources.displayMetrics.heightPixels-dp(262))
        popup!!.showAtLocation(anchor,Gravity.TOP or Gravity.START,x,y)
        search.requestFocus()
        search.postDelayed({(getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)?.showSoftInput(search,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)},120)
    }
    private fun toggleSidebar(){
        val panel=sidebarPanel ?: return
        sidebarOpen=!sidebarOpen
        if(sidebarOpen){
            panel.visibility=View.VISIBLE;panel.alpha=0f;panel.translationX=-dp(18).toFloat();panel.animate().alpha(1f).translationX(0f).setDuration(180).start()
        }else{
            panel.animate().alpha(0f).translationX(-dp(18).toFloat()).setDuration(160).withEndAction{panel.visibility=View.GONE}.start()
        }
        sidebarDivider?.visibility=View.VISIBLE
        updateDotStates()
    }
    private fun toggleFocusMode(){
        focusMode=!focusMode
        val ids=listOf(R.id.workspaceLabel,R.id.workspaceHint)
        ids.forEach{id->findViewById<View>(id)?.visibility=if(focusMode)View.GONE else View.VISIBLE}
        if(sidebarPanel!=null){
            if(focusMode){focusSidebarWasOpen=sidebarOpen;if(sidebarOpen)toggleSidebar()}
            else if(focusSidebarWasOpen&&!sidebarOpen)toggleSidebar()
        }
        updateDotStates()
        showWindowToast(if(focusMode)"Focus mode on" else "Focus mode off")
    }
    private fun updateDotStates(){
        findViewById<View>(R.id.windowDot1)?.alpha=.82f
        findViewById<View>(R.id.windowDot2)?.alpha=.82f
        findViewById<View>(R.id.windowDot3)?.alpha=.82f
    }
    private fun showWindowToast(text:String){Toast.makeText(this,text,Toast.LENGTH_SHORT).show()}
    private fun showPlaceholder(){findViewById<Button>(R.id.explainButton)?.apply{isEnabled=editor.text.toString().trim().isNotBlank();alpha=if(isEnabled)1f else .45f};val t=TextView(this);t.text="Run a query to see results here";t.setTextColor(Color.rgb(104,108,120));t.textSize=13f;t.gravity=Gravity.CENTER;resultContainer.removeAllViews();resultContainer.addView(t)}
    private fun buildMessageView(msg:String):View{val t=TextView(this);t.text=msg;t.textSize=13f;t.setTextColor(Color.rgb(185,181,191));t.setPadding(20,20,20,20);val s=ScrollView(this);s.addView(t);return s}
    private fun buildErrorView(message:String,location:String,executionMs:String,sql:String):View{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(16),dp(18),dp(20))}
        val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val icon=TextView(this).apply{text="✕";textSize=24f;setTextColor(red);setPadding(0,0,dp(10),0)}
        val title=TextView(this).apply{text="Query failed";textSize=17f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(white)}
        header.addView(icon,LinearLayout.LayoutParams(dp(34),dp(40)));header.addView(title,LinearLayout.LayoutParams(0,dp(40),1f))
        root.addView(header)
        val rule=View(this).apply{setBackgroundColor(Color.rgb(48,50,60))};root.addView(rule,LinearLayout.LayoutParams(-1,dp(1)).apply{topMargin=dp(8);bottomMargin=dp(14)})
        val label=TextView(this).apply{text="SQLITE_ERROR";textSize=11f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(red)};root.addView(label)
        val error=TextView(this).apply{text=message;textSize=15f;setTextColor(white);setPadding(0,dp(7),0,dp(14));setTextIsSelectable(true)};root.addView(error)
        val meta=TextView(this).apply{text="$location\nExecution: $executionMs ms";textSize=12f;setTextColor(Color.rgb(155,151,164));setPadding(0,0,0,dp(14))};root.addView(meta)
        val qLabel=TextView(this).apply{text="STATEMENT";textSize=10f;setTypeface(null,android.graphics.Typeface.BOLD);setTextColor(Color.rgb(150,145,158))};root.addView(qLabel)
        val q=TextView(this).apply{text=sql.trim();textSize=12f;typeface=android.graphics.Typeface.MONOSPACE;setTextColor(Color.rgb(205,201,210));setPadding(dp(12),dp(10),dp(12),dp(10));background=rounded(Color.rgb(24,26,33),1,Color.rgb(45,47,57),8f);setTextIsSelectable(true);maxLines=8;ellipsize=android.text.TextUtils.TruncateAt.END};root.addView(q,LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{topMargin=dp(6)})
        val explain=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Explain Error";isAllCaps=false;minHeight=0;minWidth=0;setPadding(dp(14),0,dp(14),0);textSize=12f;stateListAnimator=null;setOnClickListener{showExplain(message)}}
        root.addView(explain,LinearLayout.LayoutParams(-2,dp(36)).apply{gravity=Gravity.END;topMargin=dp(14)})
        val scroll=ScrollView(this);scroll.addView(root);return scroll
    }
    private fun schemaText():String{val b=StringBuilder();db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",null).use{c->if(!c.moveToFirst())b.append("No tables yet.\nImport a .db or .sql file,\nor run a CREATE TABLE.")else{do{val n=c.getString(0);b.append(n).append("  ");try{db.rawQuery("SELECT COUNT(*) FROM \""+n.replace("\"","\"\"")+"\"",null).use{r->if(r.moveToFirst())b.append("(").append(r.getLong(0)).append(" rows)")}}catch(_:Exception){};b.append("\n");db.rawQuery("PRAGMA table_info('"+n.replace("'","''")+"')",null).use{p->while(p.moveToNext())b.append("   ").append(p.getString(1)).append("  ").append(p.getString(2).ifBlank{"ANY"}).append("\n")};b.append("\n")}while(c.moveToNext())}};return b.toString().trimEnd()}
    private fun interactiveSchemaView():View{
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(6),dp(4),dp(6),dp(10))}
        val search=EditText(this).apply{hint="Search databases, tables, columns…";setSingleLine(true);setTextColor(white);setHintTextColor(Color.rgb(100,104,116));textSize=11f;background=rounded(Color.rgb(24,26,33),1,Color.rgb(45,47,57),9f);setPadding(dp(10),0,dp(10),0)}
        root.addView(search,LinearLayout.LayoutParams(-1,dp(38)).apply{bottomMargin=dp(6)})
        root.addView(View(this).apply{setBackgroundColor(Color.rgb(42,44,53))},LinearLayout.LayoutParams(-1,dp(1)).apply{bottomMargin=dp(4)})
        root.addView(TextView(this).apply{text="DATABASES";textSize=9f;letterSpacing=.14f;setTextColor(Color.rgb(112,116,129));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(8),dp(6),dp(8),dp(5))})
        databaseTreePaths().forEach{(label,path)->addDatabaseTreeNode(root,label,path,label=="Parks & Recreation")}
        fun filterView(v:View,q:String):Boolean{val tag=v.tag?.toString();val own=tag?.startsWith("schema:")==true&&tag.removePrefix("schema:").contains(q,true);if(v is ViewGroup){var child=false;for(i in 0 until v.childCount)child=filterView(v.getChildAt(i),q)||child;if(tag?.startsWith("schema:")==true)v.visibility=if(q.isBlank()||own||child)View.VISIBLE else View.GONE;return own||child};if(tag?.startsWith("schema:")==true)v.visibility=if(q.isBlank()||own)View.VISIBLE else View.GONE;return own}
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){filterView(root,s?.toString()?.trim().orEmpty())};override fun afterTextChanged(e:Editable?) {}})
        return root
    }
    private fun databaseTreePaths():List<Pair<String,String>>{val out=mutableListOf<Pair<String,String>>();out.add("Parks & Recreation" to ensureSamplePath("Parks & Recreation"));userDatabasePaths().forEach{out.add(databaseLabel(it) to it)};return out}
    private fun addDatabaseTreeNode(parent:LinearLayout,label:String,path:String,sample:Boolean){
        val active=File(path).absolutePath==dbFile.absolutePath
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(40);setPadding(dp(4),0,dp(4),0);background=if(active)rounded(Color.rgb(34,35,42),1,Color.rgb(66,68,77),9f) else ColorDrawable(Color.TRANSPARENT);tag="schema:$label";isClickable=true;contentDescription=if(active)"Selected database $label" else "Database $label"}
        val chevron=TextView(this).apply{text="▸";textSize=17f;setTextColor(blue);gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(28),dp(40))}
        val icon=TextView(this).apply{text="▰";textSize=12f;setTextColor(if(active)blue else Color.rgb(150,145,163));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(24),dp(40))}
        val name=TextView(this).apply{this.text=label;textSize=12f;setTextColor(white);setTypeface(null,if(active)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(40),1f)}
        val meta=TextView(this).apply{this.text=if(active)"active · ${databaseSummarySafe(path)}" else databaseSummarySafe(path);textSize=9f;setTextColor(if(active)Color.rgb(157,154,166) else Color.rgb(118,122,134));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-2,dp(40))}
        row.addView(chevron);row.addView(icon);row.addView(name);row.addView(meta);parent.addView(row)
        val children=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(18),0,0,0);tag="schema:${label}_contents"};parent.addView(children)
        var expanded=false
        fun loadChildren(){children.removeAllViews();if(!File(path).exists()&&sample)runCatching{copyBundledDatabase("Parks_and_Recreation.db")};val opened=try{SQLiteDatabase.openDatabase(path,null,SQLiteDatabase.OPEN_READONLY)}catch(_:Exception){null};if(opened==null){children.addView(TextView(this).apply{text="Unable to open database";textSize=10f;setTextColor(red);setPadding(dp(14),dp(7),0,dp(7))});return};val names=mutableListOf<String>();opened.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",null).use{c->while(c.moveToNext())names.add(c.getString(0))};if(names.isEmpty())children.addView(TextView(this).apply{text="No user tables";textSize=10f;setTextColor(Color.rgb(125,129,141));setPadding(dp(14),dp(7),0,dp(7))}) else {children.addView(TextView(this).apply{text="TABLES";textSize=9f;letterSpacing=.12f;setTextColor(Color.rgb(105,109,122));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(8),dp(7),0,dp(4))});names.forEach{addDatabaseObjectNode(children,opened,it,path,label)}};opened.close()}
        fun setExpanded(v:Boolean){expanded=v;chevron.text=if(v)"▾" else "▸";if(v){loadChildren();children.visibility=View.VISIBLE;children.alpha=0f;children.animate().alpha(1f).setDuration(130).start()}else{children.animate().alpha(0f).setDuration(90).withEndAction{children.visibility=View.GONE}.start()}}
        row.setOnClickListener{if(File(path).absolutePath!=dbFile.absolutePath){if(!File(path).exists()&&sample)runCatching{copyBundledDatabase("Parks_and_Recreation.db")};activateDatabase(path,label)}else setExpanded(!expanded)};chevron.setOnClickListener{setExpanded(!expanded)};row.setOnLongClickListener{if(!sample)showDatabaseActions(label,path);!sample};if(android.os.Build.VERSION.SDK_INT>=23&&!sample)row.setOnContextClickListener{showDatabaseDeleteMenu(row,label,path);true}
    }
    private fun showDatabaseDeleteMenu(anchor:View,label:String,path:String){
        val popup=PopupWindow(this);val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(4),dp(4),dp(4),dp(4));background=rounded(Color.rgb(31,32,38),1,Color.rgb(76,77,85),10f);elevation=dp(10).toFloat()}
        val del=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),0,dp(10),0);isClickable=true;background=rounded(Color.TRANSPARENT,0,Color.TRANSPARENT,7f)}
        del.addView(TextView(this).apply{text="⌫";textSize=13f;setTextColor(red);gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(25),dp(32))})
        del.addView(TextView(this).apply{text="Delete database";textSize=12f;setTextColor(Color.rgb(238,234,238));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(dp(126),dp(32))})
        del.setOnHoverListener{v,e->if(e.action==MotionEvent.ACTION_HOVER_ENTER)v.setBackgroundColor(Color.rgb(60,44,50));else if(e.action==MotionEvent.ACTION_HOVER_EXIT)v.setBackgroundColor(Color.TRANSPARENT);false};del.setOnClickListener{popup.dismiss();confirmDeleteDatabase(label,path)};root.addView(del)
        popup.contentView=root;popup.width=dp(158);popup.height=dp(40);popup.isFocusable=true;popup.isOutsideTouchable=true;popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));val loc=IntArray(2);anchor.getLocationOnScreen(loc);val x=(loc[0]+anchor.width-dp(158)).coerceAtLeast(dp(8));val y=(loc[1]+anchor.height+dp(4)).coerceAtMost(resources.displayMetrics.heightPixels-dp(48));popup.showAtLocation(anchor,Gravity.TOP or Gravity.START,x,y);animatePopupIn(root)
    }
    private fun addDatabaseObjectNode(parent:LinearLayout,source:SQLiteDatabase,name:String,path:String,label:String){
        val safe=name.replace("\"","\"\"")
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(36);setPadding(0,0,dp(4),0);tag="schema:$name";isClickable=true}
        row.addView(TextView(this).apply{text="▦";textSize=12f;setTextColor(Color.rgb(166,160,177));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(28),dp(36))})
        row.addView(TextView(this).apply{text=name;textSize=11.5f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(36),1f)})
        row.addView(TextView(this).apply{text=try{source.rawQuery("SELECT COUNT(*) FROM \"$safe\"",null).use{if(it.moveToFirst())"${it.getLong(0)} rows" else ""}}catch(_:Exception){""};textSize=9f;setTextColor(Color.rgb(118,122,134));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-2,dp(36))})
        parent.addView(row)
        row.setOnClickListener{try{if(File(path).absolutePath!=dbFile.absolutePath)activateDatabase(path,label);insertSql("SELECT * FROM \"$safe\";\n");showTablePreviewInline(name)}catch(e:Exception){showError("Could not open $name: ${e.message?:"table error"}")}}
        row.setOnLongClickListener{if(File(path).absolutePath==dbFile.absolutePath)showTableContextMenu(name);true}
    }
    private fun ensureSamplePath(label:String):String{
        val asset=if(label=="Northwind")"Northwind.db" else "Parks_and_Recreation.db"
        val f=File(filesDir,"Sample_${asset.replace(Regex("[^A-Za-z0-9._-]"),"_")}")
        if(!f.exists())assets.open(asset).use{i->f.outputStream().use{o->i.copyTo(o)}}
        return f.path
    }
    private fun addDatabaseRow(parent:LinearLayout,label:String,path:String,sample:Boolean){
        val active=File(path).absolutePath==dbFile.absolutePath
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(44);setPadding(dp(10),0,dp(6),0);background=rounded(if(active)Color.rgb(36,38,45) else Color.TRANSPARENT,if(active)1 else 0,if(active)Color.rgb(62,64,72) else Color.TRANSPARENT,10f);isClickable=true;contentDescription=if(active)"Selected database $label" else "Select database $label"}
        val icon=TextView(this).apply{text=if(sample)"✿" else "●";textSize=11f;setTextColor(if(active)blue else Color.rgb(145,141,154));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(24),dp(40))}
        val nameView=TextView(this).apply{this.text=label;textSize=12f;setTextColor(if(active)white else Color.rgb(196,192,202));setTypeface(null,if(active)android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(40),1f)}
        val meta=TextView(this).apply{this.text=if(File(path).exists())databaseSummarySafe(path) else "";textSize=9f;setTextColor(Color.rgb(118,122,134));gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(-2,dp(40))}
        row.addView(icon);row.addView(nameView);row.addView(meta)
        row.setOnClickListener{
            if(active && !sample){databaseSwitcherPopup?.dismiss();showDatabaseActions(label,path);return@setOnClickListener}
            try{
                if(!File(path).exists() && sample){copyBundledDatabase(if(label=="Northwind")"Northwind.db" else "Parks_and_Recreation.db")}
                activateDatabase(path,label);databaseSwitcherPopup?.dismiss()
            }catch(e:Exception){showError("Could not open $label: ${e.message?:"database error"}")}
        }
        parent.addView(row,LinearLayout.LayoutParams(-1,dp(44)).apply{bottomMargin=dp(3)})
    }
    private fun databaseSummarySafe(path:String):String=try{val d=SQLiteDatabase.openDatabase(path,null,SQLiteDatabase.OPEN_READONLY);val r=databaseSummary(d);d.close();r}catch(_:Exception){""}
    private fun showDatabaseActions(label:String,path:String){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(TextView(this).apply{text=databaseSummarySafe(path);textSize=12f;setTextColor(Color.rgb(145,141,154));setPadding(0,0,0,dp(12))})
        val delete=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Delete Database";isAllCaps=false;setTextColor(red)}
        box.addView(delete,LinearLayout.LayoutParams(-1,dp(42)))
        val dialog=cardDialog(label,box);dialogRef=dialog;dialog.setOnDismissListener{if(dialogRef===dialog)dialogRef=null}
        delete.setOnClickListener{dialog.dismiss();confirmDeleteDatabase(label,path)}
        dialog.show()
    }
    private fun confirmDeleteDatabase(label:String,path:String){
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        content.addView(TextView(this).apply{text="This database and its local data will be removed from Project Lily.";textSize=12.5f;setTextColor(white);setPadding(0,dp(8),0,dp(8))})
        content.addView(TextView(this).apply{text="This action cannot be undone.";textSize=10f;setTextColor(Color.rgb(145,141,154));setPadding(0,0,0,dp(6))})
        cardDialog("Delete $label?",content,"Confirm Delete"){
            try{
                val deletingActive=File(path).absolutePath==dbFile.absolutePath
                if(deletingActive){try{db.close()}catch(_:Exception){};File(path).delete();unregisterUserDatabase(path);copyBundledDatabase("Parks_and_Recreation.db");prefs.edit().putString("active_db_path",dbFile.path).apply()}
                else {File(path).delete();unregisterUserDatabase(path)}
                refreshSchemaPanel();statusOk("Deleted $label")
            }catch(e:Exception){showError("Delete failed: ${e.message?:"error"}")}
        }.show()
    }
    private fun tableHasColumn(table:String,filter:String):Boolean=try{db.rawQuery("PRAGMA table_info('"+table.replace("'","''")+"')",null).use{c->while(c.moveToNext())if(c.getString(1).contains(filter,true))return true};false}catch(_:Exception){false}
    private fun addTreeSection(root:LinearLayout,title:String,type:String,always:Boolean){
        val names=mutableListOf<String>()
        db.rawQuery("SELECT name FROM sqlite_master WHERE type=? AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",arrayOf(type)).use{c->while(c.moveToNext()){val n=c.getString(0);if(schemaFilter.isBlank()||n.contains(schemaFilter,true)||type!="table"||tableHasColumn(n,schemaFilter))names.add(n)}}
        if(names.isEmpty()&&!always)return
        val section=TextView(this).apply{text=title;textSize=9f;letterSpacing=.14f;setTextColor(Color.rgb(112,116,129));setTypeface(null,android.graphics.Typeface.BOLD);setPadding(dp(8),dp(8),dp(8),dp(6))}
        root.addView(section)
        if(names.isEmpty()){
            root.addView(TextView(this).apply{text="No tables yet";textSize=11f;setTextColor(Color.rgb(130,134,147));setPadding(dp(16),dp(4),dp(8),dp(8))})
            return
        }
        names.forEach{name->addTreeNode(root,name,type)}
    }
    private fun addTreeNode(parent:LinearLayout,name:String,type:String){
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(38);setPadding(dp(4),0,dp(4),0);setBackgroundResource(R.drawable.tree_row);tag="schema:$name"}
        val chevron=TextView(this).apply{text="▸";textSize=18f;setTextColor(blue);gravity=Gravity.CENTER;setPadding(0,0,0,dp(2));layoutParams=LinearLayout.LayoutParams(dp(32),dp(40))}
        val icon=TextView(this).apply{text=if(type=="table")"▦" else if(type=="view")"◫" else "◇";textSize=13f;setTextColor(Color.rgb(166,160,177));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(28),dp(40))}
        val label=TextView(this).apply{text=name;textSize=12f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(40),1f)}
        val meta=TextView(this).apply{this.text=if(type=="table")tableRowCountText(name) else "";textSize=10f;setTextColor(Color.rgb(125,129,141));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-2,dp(40))}
        row.addView(chevron);row.addView(icon);row.addView(label);row.addView(meta)
        val children=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(32),0,0,0)}
        parent.addView(row);parent.addView(children)
        var expanded=false
        fun setExpanded(value:Boolean){expanded=value;chevron.text=if(expanded)"▾" else "▸";children.visibility=if(expanded)View.VISIBLE else View.GONE}
        chevron.setOnClickListener{setExpanded(!expanded)}
        row.setOnClickListener{
            if(type=="table"){
                setExpanded(!expanded)
                showTablePreviewInline(name)
            }else insertSql(name)
        }
        if(type=="table") row.setOnLongClickListener{showTableContextMenu(name);true}
        if(type=="table"){
            val columnsRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(36);setPadding(0,0,dp(4),0)}
            val cc=TextView(this).apply{text="▸";textSize=17f;setTextColor(Color.rgb(155,150,168));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(32),dp(36))}
            val ci=TextView(this).apply{text="◇";textSize=12f;setTextColor(Color.rgb(155,150,168));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(28),dp(36))}
            val ct=TextView(this).apply{text="Columns";textSize=11f;setTextColor(Color.rgb(196,192,202));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(0,dp(36),1f)}
            columnsRow.addView(cc);columnsRow.addView(ci);columnsRow.addView(ct);children.addView(columnsRow)
            val columns=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setPadding(dp(28),0,0,dp(4))}
            children.addView(columns)
            var columnsExpanded=false
            fun setColumnsExpanded(value:Boolean){columnsExpanded=value;cc.text=if(columnsExpanded)"▾" else "▸";columns.visibility=if(columnsExpanded)View.VISIBLE else View.GONE}
            cc.setOnClickListener{setColumnsExpanded(!columnsExpanded)}
            columnsRow.setOnClickListener{setColumnsExpanded(!columnsExpanded)}
            db.rawQuery("PRAGMA table_info('${name.replace("'","''")}')",null).use{c->while(c.moveToNext()){
                val col=c.getString(1);val typ=c.getString(2).ifBlank{"ANY"};val pk=c.getInt(5)>0
                val cr=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(32);setPadding(0,0,dp(4),0);tag="schema:$col"}
                cr.addView(TextView(this).apply{text="◆";textSize=9f;setTextColor(Color.rgb(150,145,163));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(28),dp(32))})
                cr.addView(TextView(this).apply{text=col;textSize=11f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1;layoutParams=LinearLayout.LayoutParams(0,dp(32),1f)})
                cr.addView(TextView(this).apply{text=if(pk)"$typ · PK" else typ;textSize=9f;setTextColor(Color.rgb(125,129,141));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-2,dp(32))})
                cr.setOnClickListener{insertSql("\"${col.replace("\"","\"\"")}\"")}
                columns.addView(cr)
            }}
        }
    }
    private fun showTableContextMenu(table:String){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val actions=listOf(
            "Browse Data" to {showTablePreviewInline(table)},
            "Generate SELECT" to {insertSql("SELECT * FROM \"${table.replace("\"","\"\"")}\";\n")},
            "Generate INSERT" to {showTableInsertTemplate(table)},
            "Structure" to {inspectTable(table)},
            "Edit Data" to {showDataEditor(table)},
            "Table Designer" to {showTableDesigner(table)},
            "Export Table as SQL" to {exportTableSql(table)},
            "Export Table as CSV" to {exportTableCsv(table)},
            "Duplicate Table" to {duplicateTable(table)},
            "Rename Table" to {renameTable(table)},
            "Delete Table" to {confirmDeleteTable(table)}
        )
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_NEVER}
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        actions.forEachIndexed{idx,pair->val b=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text=pair.first;isAllCaps=false;setOnClickListener{pair.second()}};list.addView(b,LinearLayout.LayoutParams(-1,dp(38)).apply{if(idx>0)topMargin=dp(4)})}
        scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(360)))
        cardDialog(table,box).show()
    }
    private fun duplicateTable(table:String){
        val oldSafe=table.replace("\"","\"\"")
        try{
            val base=table+"_copy";var n=base;var i=2
            while(tableNames().any{it.equals(n,true)}){n=base+i;i++}
            val ddl=executionTableDefinition(table) ?: throw Exception("Could not read table definition")
            val open=ddl.indexOf('(')
            if(open<0)throw Exception("Invalid table definition")
            val head=ddl.substring(0,open)
            val marker=Regex("(?is)^(.*?CREATE\\s+TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?)").find(head)
                ?: throw Exception("Unsupported table definition")
            val quotedNew="\"${n.replace("\"","\"\"")}\""
            val newDdl=marker.groupValues[1]+quotedNew+" "+ddl.substring(open)
            val indexSql=mutableListOf<String>()
            db.rawQuery("SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name=? AND sql IS NOT NULL",arrayOf(table)).use{c->
                while(c.moveToNext())indexSql.add(c.getString(0))
            }
            db.beginTransaction()
            try{
                db.execSQL(newDdl)
                db.execSQL("INSERT INTO $quotedNew SELECT * FROM \"$oldSafe\"")
                indexSql.forEach{sql->
                    val rewritten=sql.replace(Regex("(?i)\\b${Regex.escape(table)}\\b"),n)
                    try{db.execSQL(rewritten)}catch(_:Exception){}
                }
                db.setTransactionSuccessful()
            }finally{db.endTransaction()}
            refreshSchemaPanel();statusOk("Duplicated $table as $n")
        }catch(e:Exception){
            try{
                val base=table+"_copy";var n=base;var i=2
                while(tableNames().any{it.equals(n,true)}){n=base+i;i++}
                val newSafe=n.replace("\"","\"\"")
                db.execSQL("CREATE TABLE \"$newSafe\" AS SELECT * FROM \"$oldSafe\"")
                refreshSchemaPanel();statusOk("Duplicated $table as $n")
            }catch(inner:Exception){showError("Could not duplicate table: ${inner.message?:e.message?:"error"}")}
        }
    }
    private fun executionTableDefinition(table:String):String?=db.rawQuery("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",arrayOf(table)).use{if(it.moveToFirst())it.getString(0) else null}
    private fun renameTable(table:String){
        val input=EditText(this).apply{setSingleLine(true);setText(table);setTextColor(white);setHintTextColor(Color.rgb(105,108,119));background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),9f);setPadding(dp(10),0,dp(10),0)}
        cardDialog("Rename table",input,"Rename"){try{val n=input.text.toString().trim();if(!n.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")))throw Exception("Invalid table name");db.execSQL("ALTER TABLE \"${table.replace("\"","\"\"")}\" RENAME TO \"${n.replace("\"","\"\"")}\"");refreshSchemaPanel();statusOk("Renamed to $n")}catch(e:Exception){showError("Rename failed: ${e.message?:"error"}")}}.show()
    }
    private fun confirmDeleteTable(table:String){
        cardDialog("Delete $table?",TextView(this).apply{text="This removes the table and all of its rows. This cannot be undone.";textSize=13f;setTextColor(white);setPadding(0,dp(8),0,dp(8))},"Delete"){try{db.execSQL("DROP TABLE \"${table.replace("\"","\"\"")}\"");refreshSchemaPanel();statusOk("Deleted $table")}catch(e:Exception){showError("Delete failed: ${e.message?:"error"}")}}.show()
    }
    private var pendingTableSqlExport:String?=null; private var pendingTableCsvExport:String?=null; private var pendingDatabaseSqlExport=false; private var pendingDatabaseExportPath:String?=null
    private fun exportTableSql(table:String){
        pendingTableSqlExport=table
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/sql";putExtra(Intent.EXTRA_TITLE,"${table}.sql")}
        startActivityForResult(i,92)
    }
    private fun exportTableCsv(table:String){
        pendingTableCsvExport=table
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/csv";putExtra(Intent.EXTRA_TITLE,"${table}.csv")}
        startActivityForResult(i,93)
    }
    private fun streamTableCsvExport(uri:Uri,table:String){
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        Thread{
            try{
                val safe=table.replace("\"","\"\"")
                contentResolver.openOutputStream(uri)?.use{raw->
                    OutputStreamWriter(raw,Charsets.UTF_8).buffered().use{w->
                        executionDb.rawQuery("SELECT * FROM \"$safe\"",null).use{c->
                            for(i in 0 until c.columnCount){if(i>0)w.write(','.code);w.write(csvEscape(c.getColumnName(i)))}
                            w.newLine()
                            while(c.moveToNext()){
                                for(i in 0 until c.columnCount){
                                    if(i>0)w.write(','.code)
                                    w.write(csvEscape(if(c.isNull(i))"" else c.getString(i)))
                                }
                                w.newLine()
                            }
                        }
                    }
                } ?: throw Exception("Could not open output file")
                runOnUiThread{if(!isFinishing&&!isDestroyed)statusOk("Exported table $table as CSV")}
            }catch(e:Exception){runOnUiThread{if(!isFinishing&&!isDestroyed)showError("Table CSV export failed: ${e.message?:"error"}")}}
        }.start()
    }
    private fun streamTableSqlExport(uri:Uri,table:String){
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        Thread{
            try{
                val safe=table.replace("\"","\"\"")
                contentResolver.openOutputStream(uri)?.use{raw->
                    OutputStreamWriter(raw,Charsets.UTF_8).buffered().use{w->
                        executionDb.rawQuery("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",arrayOf(table)).use{c->
                            if(!c.moveToFirst())throw Exception("Table no longer exists")
                            w.write((c.getString(0) ?: "").trimEnd(';'));w.write(";\n\n")
                        }
                        executionDb.rawQuery("SELECT * FROM \"$safe\"",null).use{c->
                            val cols=(0 until c.columnCount).map{c.getColumnName(it)}
                            val quotedCols=cols.joinToString(", "){"\"${it.replace("\"","\"\"")}\""}
                            while(c.moveToNext()){
                                val vals=(0 until c.columnCount).joinToString(", "){i->sqliteLiteral(c,i)}
                                w.write("INSERT INTO \"$safe\" ($quotedCols) VALUES ($vals);\n")
                            }
                        }
                    }
                } ?: throw Exception("Could not open output file")
                runOnUiThread{if(!isFinishing&&!isDestroyed)statusOk("Exported table $table")}
            }catch(e:Exception){runOnUiThread{if(!isFinishing&&!isDestroyed)showError("Table export failed: ${e.message?:"error"}")}}
        }.start()
    }
    private fun showTableInsertTemplate(table:String){
        val cols=mutableListOf<String>();db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())cols.add(c.getString(1))}
        if(cols.isEmpty())return
        val quoted=cols.joinToString(", "){"\"${it.replace("\"","\"\"")}\""};insertSql("INSERT INTO \"${table.replace("\"","\"\"")}\" ($quoted) VALUES (${cols.joinToString(", "){ "?" }});\n")
    }
    private fun tableRowCountText(name:String):String{
        return try{
            // Exact COUNT(*) can be surprisingly expensive on very large tables and
            // used to run for every Explorer refresh. Prefer planner statistics when
            // available; otherwise show a lightweight "table" label.
            val estimate=runCatching{db.rawQuery("SELECT stat FROM sqlite_stat1 WHERE tbl=? ORDER BY rowid DESC LIMIT 1",arrayOf(name)).use{c->if(c.moveToFirst())c.getString(0).substringBefore(' ').toLongOrNull() else null}}.getOrNull()
            if(estimate!=null)"~$estimate rows" else "table"
        }catch(_:Exception){"table"}
    }
    private fun showTablePreviewInline(table:String){
        dismissAutocomplete()
        val safe=table.replace("\"","\"\"")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10))}
        val title=TextView(this).apply{text=table;textSize=15f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,0,0,4)}
        box.addView(title)
        val meta=TextView(this).apply{textSize=11f;setTextColor(Color.rgb(130,134,147));setPadding(0,0,0,8)}
        meta.text="${tableColumnCount(table)} columns  ·  ${tableRowCountText(table)}  ·  first 50 shown"
        box.addView(meta)
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val select=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Insert SELECT *";isAllCaps=false;setOnClickListener{insertSql("SELECT * FROM \"$safe\";")}}
        actions.addView(select)
        box.addView(actions)
        val data=mutableListOf<List<String>>()
        db.rawQuery("SELECT * FROM \"$safe\" LIMIT 50",null).use{c->
            data.add((0 until c.columnCount).map{c.getColumnName(it)})
            while(c.moveToNext())data.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)})
        }
        box.addView(buildPreviewGrid(data),LinearLayout.LayoutParams(-1,0,1f))
        resultContainer.removeAllViews();resultContainer.addView(box)
        statusOk("Previewing $table")
    }
    private fun buildPreviewGrid(data:List<List<String>>):View{
        val table=TableLayout(this)
        table.isStretchAllColumns=false
        if(data.isEmpty()) return TextView(this).apply{text="No columns";setPadding(dp(12),dp(12),dp(12),dp(12));setTextColor(white)}
        val header=TableRow(this)
        for(v in data[0]) header.addView(cell(v,true){})
        table.addView(header)
        for(i in 1 until data.size){
            val row=TableRow(this)
            for(v in data[i]) row.addView(cell(v,false){copyText(v)})
            table.addView(row)
        }
        if(data.size==1) table.addView(TextView(this).apply{text="(0 rows)";setPadding(dp(16),dp(16),dp(16),dp(16));setTextColor(white)})
        val hs=HorizontalScrollView(this)
        hs.addView(table)
        val vs=ScrollView(this)
        vs.addView(hs)
        return vs
    }
    private fun tableColumnCount(table:String):Int{var n=0;db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())n++};return n}
    private fun showSchema(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),dp(0));minimumHeight=dp(420)}
        val hint=TextView(this).apply{text="Select a database above. Expand a table to browse columns.";textSize=12f;setTextColor(Color.rgb(128,132,145));setPadding(0,0,0,dp(10))}
        box.addView(hint)
        val import=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Import .db / .sql";isAllCaps=false;setOnClickListener{dismissAutocomplete();pickFile()}}
        box.addView(import,LinearLayout.LayoutParams(-1,dp(42)).apply{bottomMargin=dp(10)})
        val scroll=ScrollView(this);scroll.addView(interactiveSchemaView());box.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        cardDialog("Database Explorer",box).show()
    }
    private fun refreshSchemaPanel(){schemaPanel?.let{it.removeAllViews();it.addView(interactiveSchemaView(),LinearLayout.LayoutParams(-1,-2))}}
    private fun firstTable():String{db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name LIMIT 1",null).use{c->if(c.moveToFirst())return c.getString(0)};return ""}
    private fun chooseDatabase(){showSchema()}
    private fun statusOk(s:String){status.text="✓ $s";status.setTextColor(green)};private fun showError(s:String){status.text="✕ $s";status.setTextColor(red)}
    private fun formatSql(sql:String):String{
        if(sql.isBlank())return sql
        fun mask(source:String):String{
            val out=StringBuilder(source.length);var quote:Char?=null;var bracket=false;var backtick=false;var line=false;var block=false;var i=0
            while(i<source.length){val c=source[i];val n=if(i+1<source.length)source[i+1] else '\u0000'
                if(line){out.append(if(c=='\n')'\n' else ' ');if(c=='\n')line=false;i++;continue}
                if(block){if(c=='*'&&n=='/'){out.append("  ");i+=2;block=false}else{out.append(if(c=='\n')'\n' else ' ');i++};continue}
                if(quote!=null){out.append(if(c=='\n')'\n' else ' ');if(c==quote){if(n==quote){out.append(' ');i+=2;continue};quote=null};i++;continue}
                if(bracket){out.append(' ');if(c==']'){if(n==']'){out.append(' ');i+=2;continue};bracket=false};i++;continue}
                if(backtick){out.append(' ');if(c=='`'){if(n=='`'){out.append(' ');i+=2;continue};backtick=false};i++;continue}
                if(c=='-'&&n=='-'){out.append("  ");i+=2;line=true;continue};if(c=='/'&&n=='*'){out.append("  ");i+=2;block=true;continue}
                if(c=='\''||c=='"'){out.append(' ');quote=c;i++;continue};if(c=='['){out.append(' ');bracket=true;i++;continue};if(c=='`'){out.append(' ');backtick=true;i++;continue}
                out.append(c);i++
            }
            return out.toString()
        }
        var text=sql.replace("\r\n","\n").replace('\r','\n').trim()
        val masked=mask(text)
        val patterns=listOf(
            Regex("\\s+(SELECT|FROM|WHERE|GROUP\\s+BY|ORDER\\s+BY|HAVING|LIMIT|OFFSET|UNION(?:\\s+ALL)?|INTERSECT|EXCEPT|VALUES|SET|RETURNING)\\b",RegexOption.IGNORE_CASE),
            Regex("\\s+((?:LEFT|RIGHT|FULL|INNER|OUTER|CROSS)\\s+)?JOIN\\s+",RegexOption.IGNORE_CASE),
            Regex("\\s+ON\\s+",RegexOption.IGNORE_CASE)
        )
        val positions=mutableListOf<Int>();patterns.forEach{r->r.findAll(masked).forEach{m->positions.add(m.range.first)}}
        for(pos in positions.distinct().sortedDescending()) if(pos>0&&pos<text.length) text=text.substring(0,pos).trimEnd()+"\n"+text.substring(pos).trimStart()
        return text.replace(Regex("\\n{3,}"),"\n\n").trim()
    }
    private fun clearEditor(){
        if(editor.text.isNullOrBlank()){return}
        val message = TextView(this).apply {
            setText("Remove all SQL from the current query tab?")
            setTextColor(white)
            textSize = 13f
            setPadding(0, dp(6), 0, dp(6))
        }
        cardDialog("Clear editor", message, "Clear") {
            editor.setText("")
            editor.requestFocus()
            updateAutocomplete()
        }.show()
    }
    private fun toggleComment(){
        val start=minOf(editor.selectionStart.coerceAtLeast(0),editor.selectionEnd.coerceAtLeast(0))
        val end=maxOf(editor.selectionStart.coerceAtLeast(0),editor.selectionEnd.coerceAtLeast(0))
        val text=editor.text.toString();if(text.isEmpty())return
        val lineStart=text.lastIndexOf('\n',start-1).let{if(it<0)0 else it+1}
        val selectionEnd=if(start==end)end else end
        val lineEnd=text.indexOf('\n',selectionEnd).let{if(it<0)text.length else it}
        val block=text.substring(lineStart,lineEnd)
        val lines=block.split('\n')
        val shouldUncomment=lines.filter{it.trim().isNotEmpty()}.all{it.trimStart().startsWith("--")}
        val replacement=lines.joinToString("\n"){line->
            if(line.trim().isEmpty())line
            else if(shouldUncomment){val idx=line.indexOf("--");if(idx>=0)line.removeRange(idx,minOf(idx+2,line.length)).removePrefix(" ").removePrefix(" ") else line}
            else {val indent=line.takeWhile{it==' '||it=='\t'};indent+"-- "+line.drop(indent.length)}
        }
        editor.text.replace(lineStart,lineEnd,replacement)
        val delta=replacement.length-block.length
        val newStart=(if(start>lineEnd)start+delta else start).coerceIn(0,editor.length())
        val newEnd=(if(end>lineEnd)end+delta else (end+delta).coerceIn(newStart,editor.length())).coerceIn(0,editor.length())
        editor.setSelection(if(start==end)newStart else newStart,newEnd)
        highlight()
    }
    private fun highlight(){
        if(highlighting)return;highlighting=true
        val e=editor.text;val pos=editor.selectionStart
        e.getSpans(0,e.length,ForegroundColorSpan::class.java).forEach{e.removeSpan(it)}
        val text=e.toString()
        val keywordColor=Color.rgb(111,181,214)
        val clauseColor=Color.rgb(190,166,218)
        val functionColor=Color.rgb(215,169,222)
        val stringColor=Color.rgb(153,198,153)
        val numberColor=Color.rgb(205,181,137)
        val commentColor=Color.rgb(112,117,124)
        val identifierColor=Color.rgb(224,225,227)
        val patterns=listOf(
            Pattern.compile("(?i)\\b(?:SELECT|FROM|WHERE|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|DROP|ALTER|TRUNCATE|REPLACE|SHOW|DESCRIBE|DESC|USE|WITH|RECURSIVE|RETURNING|EXPLAIN|PRAGMA)\\b") to keywordColor,
            Pattern.compile("(?i)\\b(?:JOIN|INNER|LEFT|RIGHT|FULL|OUTER|CROSS|NATURAL|ON|USING|GROUP\\s+BY|ORDER\\s+BY|HAVING|LIMIT|OFFSET|UNION(?:\\s+ALL)?|INTERSECT|EXCEPT|DISTINCT|AS|AND|OR|NOT|IS|LIKE|IN|BETWEEN|ESCAPE|CASE|WHEN|THEN|ELSE|END|OVER|PARTITION|ROWS|RANGE|GROUPS|ASC|DESC)\\b") to clauseColor,
            Pattern.compile("(?i)\\b(?:COUNT|SUM|AVG|MIN|MAX|TOTAL|GROUP_CONCAT|ROW_NUMBER|RANK|DENSE_RANK|NTILE|LAG|LEAD|FIRST_VALUE|LAST_VALUE|NTH_VALUE|FILTER|COALESCE|NULLIF|IFNULL|CAST|CONCAT|IF|DATE_FORMAT|NOW|CURDATE|CURTIME)\\s*(?=\\()") to functionColor,
            Pattern.compile("'(?:''|[^'])*'") to stringColor,
            Pattern.compile("--[^\\n]*") to commentColor,
            Pattern.compile("/\\*[\\s\\S]*?\\*/") to commentColor,
            Pattern.compile("\\b\\d+(?:\\.\\d+)?\\b") to numberColor,
            Pattern.compile("`[^`]+`|\\\"[^\\\"]+\\\"") to identifierColor
        )
        for((p,col) in patterns)p.matcher(text).run{while(find())e.setSpan(ForegroundColorSpan(col),start(),end(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)}
        editor.setSelection(pos.coerceIn(0,e.length));highlighting=false
    }
    private fun showFindReplace(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun field(hint:String):EditText=EditText(this).apply{this.hint=hint;setSingleLine(true);textSize=13f;setTextColor(white);setHintTextColor(Color.rgb(105,108,119));setPadding(dp(12),0,dp(12),0);background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),10f)}
        val find=field("Find");val replace=field("Replace with")
        box.addView(find,LinearLayout.LayoutParams(-1,dp(40)));box.addView(replace,LinearLayout.LayoutParams(-1,dp(40)).apply{topMargin=dp(6)})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val next=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Find next";isAllCaps=false}
        val repl=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="Replace";isAllCaps=false}
        val all=Button(ContextThemeWrapper(this,R.style.FlatButton_Accent)).apply{text="Replace all";isAllCaps=false}
        row.addView(next,LinearLayout.LayoutParams(0,dp(36),1f));row.addView(repl,LinearLayout.LayoutParams(0,dp(36),1f).apply{marginStart=dp(4)});row.addView(all,LinearLayout.LayoutParams(0,dp(36),1f).apply{marginStart=dp(4)})
        box.addView(row,LinearLayout.LayoutParams(-1,dp(36)).apply{topMargin=dp(7)})
        val info=TextView(this).apply{textSize=11f;setTextColor(Color.rgb(128,132,145));setPadding(0,dp(8),0,0)};box.addView(info)
        val d=cardDialog("Find & Replace",box);d.show()
        fun selectNext(){val q=find.text.toString();if(q.isBlank()){info.text="Enter text to find.";return};val text=editor.text.toString();val start=(editor.selectionEnd.coerceAtLeast(0)).coerceAtMost(text.length);val hit=text.indexOf(q,start,true).let{if(it>=0)it else text.indexOf(q,0,true)};if(hit>=0){editor.requestFocus();editor.setSelection(hit,hit+q.length);info.text="Found at position $hit"}else info.text="No match found."}
        next.setOnClickListener{selectNext()}
        repl.setOnClickListener{val q=find.text.toString();if(q.isBlank()){info.text="Enter text to find.";return@setOnClickListener};val a=editor.selectionStart;val z=editor.selectionEnd;if(a!=z&&editor.text.substring(a,z).equals(q,true)){editor.text.replace(a,z,replace.text.toString());info.text="Replaced 1 match."}else{selectNext();info.text="Select a match, then tap Replace."}}
        all.setOnClickListener{val q=find.text.toString();if(q.isBlank()){info.text="Enter text to find.";return@setOnClickListener};val old=editor.text.toString();val replText=replace.text.toString();val out=Regex(Regex.escape(q),RegexOption.IGNORE_CASE).replace(old,replText);val n=(old.length-out.length+replText.length-1).coerceAtLeast(0);editor.setText(out);editor.setSelection(editor.length());info.text="Replacement complete."}
    }
    private fun showGoToLine(){
        val input=EditText(this).apply{hint="Line number";inputType=android.text.InputType.TYPE_CLASS_NUMBER;setSingleLine(true);textSize=14f;setTextColor(white);setHintTextColor(Color.rgb(105,108,119));setPadding(dp(12),0,dp(12),0);background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),10f)}
        cardDialog("Go to line",input,"Go"){val line=(input.text.toString().toIntOrNull()?:1).coerceAtLeast(1);val layout=editor.layout;val target=if(layout!=null&&line-1<layout.lineCount)layout.getLineStart(line-1) else editor.length();editor.requestFocus();editor.setSelection(target);editor.post{editor.scrollTo(0,(line-1)*editor.lineHeight);};statusOk("Moved to line $line")}.show()
        input.requestFocus()
    }
    private fun explainCurrentQuery(){
        val source=editor.text.toString();val selected=if(editor.selectionStart!=editor.selectionEnd)source.substring(minOf(editor.selectionStart,editor.selectionEnd),maxOf(editor.selectionStart,editor.selectionEnd)) else source
        val q=splitSql(selected).lastOrNull{isQueryStatement(it)}?.trim()
        if(q.isNullOrBlank()){showError("Select a SELECT query to explain");return}
        try{val compatible=runCompatibleSql(q);val plan=planRows("EXPLAIN QUERY PLAN $compatible");addResultTab("Plan",buildPlanView(plan),false,plan.map{listOf(it.first.toString(),it.second.toString(),it.third)},"Plan");selectTab(tabs.lastIndex);statusOk("Query plan generated")}catch(e:Exception){showError("Explain failed: ${e.message?:"SQL error"}")}
    }
    private fun tableNames():List<String>{val out=mutableListOf<String>();db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",null).use{c->while(c.moveToNext())out.add(c.getString(0))};return out}
    private fun showTableDesignerChooser(){
        val items=listOf("＋  Create new table")+tableNames()
        cardListDialog("Table Designer",items){i->if(i==0)showCreateTableDesigner()else showTableDesigner(items[i])}
    }
    private fun showCreateTableDesigner(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val name=EditText(this).apply{hint="Table name";setSingleLine(true);setTextColor(white);setHintTextColor(Color.rgb(105,108,119));background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),10f);setPadding(dp(12),0,dp(12),0)}
        val cols=EditText(this).apply{hint="Columns — one per line: id INTEGER PK\nname TEXT NOT NULL\nsalary NUMERIC";setTextColor(white);setHintTextColor(Color.rgb(105,108,119));gravity=Gravity.TOP;inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE;minLines=6;background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),10f);setPadding(dp(12),dp(10),dp(12),dp(10))}
        box.addView(name,LinearLayout.LayoutParams(-1,dp(44)));box.addView(cols,LinearLayout.LayoutParams(-1,dp(150)).apply{topMargin=dp(8)})
        cardDialog("Create table",box,"Create"){try{val tn=name.text.toString().trim();if(!tn.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")))throw Exception("Invalid table name");val defs=cols.text.toString().lines().map{it.trim()}.filter{it.isNotBlank()}.map{line->val parts=line.split(Regex("\\s+"),2);if(parts.size<2)throw Exception("Each column needs a name and type");val cn=parts[0];if(!cn.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")))throw Exception("Invalid column name: $cn");"\"${cn.replace("\"","\"\"")}\" ${parts[1]}"}.joinToString(", ");if(defs.isBlank())throw Exception("Add at least one column");db.execSQL("CREATE TABLE \"${tn.replace("\"","\"\"")}\" ($defs)");refreshSchemaPanel();statusOk("Table created: $tn")}catch(e:Exception){showError("Could not create table: ${e.message?:"error"}")}}.show()
    }
    private fun showTableDesigner(table:String){
        val safe=table.replace("\"","\"\"")
        data class Def(var name:String,var type:String,var pk:Boolean=false,var notNull:Boolean=false,var unique:Boolean=false,var defaultValue:String="")
        val defs=mutableListOf<Def>()
        db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext()){defs.add(Def(c.getString(1),c.getString(2).ifBlank{"TEXT"},c.getInt(5)>0,c.getInt(3)>0,false,(c.getString(4) ?: "").trim()))}}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val hint=TextView(this).apply{text="Edit the table structure. Changes rebuild the table and preserve values for matching columns.";textSize=10.5f;setTextColor(Color.rgb(128,132,145));setPadding(0,0,0,dp(8))};box.addView(hint)
        val scroll=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(250)))
        fun field(value:String,hintText:String):EditText=EditText(this).apply{setSingleLine(true);setText(value);setHint(hintText);setTextColor(white);setHintTextColor(Color.rgb(95,99,110));textSize=11f;background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),8f);setPadding(dp(8),0,dp(8),0)}
        fun check(labelText:String,checked:Boolean,onChange:(Boolean)->Unit):CheckBox=CheckBox(this).apply{text=labelText;isChecked=checked;textSize=10f;setTextColor(Color.rgb(190,186,197));buttonTintList=android.content.res.ColorStateList.valueOf(Color.rgb(194,196,200));setOnCheckedChangeListener{_,v->onChange(v)}}
        fun render(){
            list.removeAllViews()
            val header=TextView(this).apply{text="COLUMN   TYPE                 OPTIONS";textSize=9f;setTextColor(Color.rgb(112,116,129));setPadding(dp(4),dp(2),0,dp(5))};list.addView(header)
            defs.forEachIndexed{index,d->
                val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(7),dp(7),dp(7),dp(7));background=rounded(Color.rgb(24,26,33),1,Color.rgb(45,47,57),9f)}
                val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                val name=field(d.name,"column");val type=field(d.type,"type")
                top.addView(name,LinearLayout.LayoutParams(0,dp(38),1.15f));top.addView(type,LinearLayout.LayoutParams(0,dp(38),.9f).apply{marginStart=dp(6)})
                val remove=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="×";isAllCaps=false;setTextColor(red);setOnClickListener{defs.removeAt(index);render()}};top.addView(remove,LinearLayout.LayoutParams(dp(42),dp(38)).apply{marginStart=dp(6)})
                row.addView(top)
                val opts=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                opts.addView(check("PK",d.pk){d.pk=it},LinearLayout.LayoutParams(0,dp(38),.75f));opts.addView(check("NOT NULL",d.notNull){d.notNull=it},LinearLayout.LayoutParams(0,dp(38),1.15f));opts.addView(check("UNIQUE",d.unique){d.unique=it},LinearLayout.LayoutParams(0,dp(38),.9f))
                row.addView(opts)
                val def=field(d.defaultValue,"DEFAULT expression (optional)");row.addView(def,LinearLayout.LayoutParams(-1,dp(36)).apply{topMargin=dp(2)})
                fun sync(){d.name=name.text.toString().trim();d.type=type.text.toString().trim();d.defaultValue=def.text.toString().trim()}
                name.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){d.name=s?.toString()?.trim().orEmpty()};override fun afterTextChanged(s:Editable?){}})
                type.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){d.type=s?.toString()?.trim().orEmpty()};override fun afterTextChanged(s:Editable?){}})
                def.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){d.defaultValue=s?.toString()?.trim().orEmpty()};override fun afterTextChanged(s:Editable?){}})
                name.setOnFocusChangeListener{_,has->if(!has)sync()};type.setOnFocusChangeListener{_,has->if(!has)sync()};def.setOnFocusChangeListener{_,has->if(!has)sync()}
                list.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(6)})
            }
        }
        val add=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="＋  Add column";isAllCaps=false;setOnClickListener{defs.add(Def("column${defs.size+1}","TEXT"));render()}}
        val preview=Button(ContextThemeWrapper(this,R.style.FlatButton)).apply{text="SQL preview";isAllCaps=false;setOnClickListener{defs.forEach{it.name=it.name.trim();it.type=it.type.trim()};showTableDesignerSql(table,defs.map{it.name to it.type})}}
        box.addView(add,LinearLayout.LayoutParams(-1,dp(38)).apply{topMargin=dp(6)});box.addView(preview,LinearLayout.LayoutParams(-1,dp(38)).apply{topMargin=dp(5)})
        cardDialog("Design · $table",box,"Apply"){
            try{
                defs.forEach{it.name=it.name.trim();it.type=it.type.trim();it.defaultValue=it.defaultValue.trim();if(!it.name.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")))throw Exception("Invalid column name: ${it.name}");if(it.type.isBlank())throw Exception("Column ${it.name} needs a type")}
                val pk=defs.filter{it.pk};if(pk.size>1)throw Exception("Use one primary key column in this editor")
                val tableQuoted="\"$safe\"";val temp="__lily_edit_${System.currentTimeMillis()}"
                val defsSql=defs.joinToString(", "){d->"\"${d.name}\" ${d.type}"+(if(d.pk)" PRIMARY KEY" else "")+(if(d.notNull)" NOT NULL" else "")+(if(d.unique)" UNIQUE" else "")+(if(d.defaultValue.isNotBlank())" DEFAULT ${d.defaultValue}" else "")}
                val oldCols=mutableListOf<String>();db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())oldCols.add(c.getString(1))};val keep=defs.map{it.name}.filter{n->oldCols.any{it.equals(n,true)}}
                val indexSql=mutableListOf<String>();db.rawQuery("SELECT sql FROM sqlite_master WHERE type='index' AND tbl_name=? AND sql IS NOT NULL",arrayOf(table)).use{c->while(c.moveToNext())indexSql.add(c.getString(0))}
                db.beginTransaction();try{db.execSQL("CREATE TABLE \"$temp\" ($defsSql)");if(keep.isNotEmpty()){val cols=keep.joinToString(","){"\"${it.replace("\"","\"\"")}\""};db.execSQL("INSERT INTO \"$temp\" ($cols) SELECT $cols FROM $tableQuoted")};db.execSQL("DROP TABLE $tableQuoted");db.execSQL("ALTER TABLE \"$temp\" RENAME TO $tableQuoted");indexSql.forEach{sql->try{db.execSQL(sql)}catch(_:Exception){}};db.setTransactionSuccessful()}finally{db.endTransaction()}
                refreshSchemaPanel();statusOk("Table updated: $table")
            }catch(e:Exception){showError("Could not apply design: ${e.message?:"error"}")}
        }.show()
        render()
    }
    private fun showTableDesignerSql(table:String,columns:List<Pair<String,String>>){
        val sql="CREATE TABLE \"${table.replace("\"","\"\"")}\" (\n"+columns.joinToString(",\n"){(n,t)->"  \"${n.replace("\"","\"\"")}\" ${t.ifBlank{"TEXT"}}"}+"\n);"
        val previewText=EditText(this).apply{setText(sql);setTextColor(white);textSize=11f;gravity=Gravity.TOP;minLines=8;setTextIsSelectable(true);background=rounded(Color.rgb(24,26,33),1,Color.rgb(48,51,62),9f);setPadding(dp(10),dp(8),dp(10),dp(8))}
        cardDialog("SQL Preview",previewText,"Insert"){insertSql(sql+"\n")}.show()
    }
    private fun showDataEditorChooser(){cardListDialog("Data Editor",tableNames()){i->showDataEditor(tableNames()[i])}}
    private fun showDataEditor(table:String){
        val safe=table.replace("\"","\"\"");val pk=mutableListOf<Pair<String,Int>>();db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())if(c.getInt(5)>0)pk.add(c.getString(1) to c.getInt(5))};if(pk.isEmpty()){showError("$table has no primary key; safe row editing needs a primary key");return};val pkName=pk.minBy{it.second}.first
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val hint=TextView(this).apply{text="Tap a row to edit it. Primary key: $pkName";textSize=11f;setTextColor(Color.rgb(128,132,145));setPadding(0,0,0,dp(8))};box.addView(hint)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val scroll=ScrollView(this);scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(300)))
        fun render(){list.removeAllViews();db.rawQuery("SELECT * FROM \"$safe\" LIMIT 100",null).use{c->val headers=(0 until c.columnCount).map{c.getColumnName(it)};while(c.moveToNext()){val values=(0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)};val row=TextView(this);row.text=values.joinToString("  ·  ");row.textSize=11f;row.setTextColor(white);row.setSingleLine(true);row.ellipsize=android.text.TextUtils.TruncateAt.END;row.setPadding(dp(10),dp(9),dp(10),dp(9));row.background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),8f);val pkIdx=headers.indexOfFirst{it.equals(pkName,true)};val pkValue=values.getOrElse(pkIdx){""};row.setOnClickListener{editDataRow(table,headers,values,pkName,pkValue){render()}};list.addView(row,LinearLayout.LayoutParams(-1,dp(36)).apply{bottomMargin=dp(4)})}}}
        render();cardDialog("Data · $table",box).show()
    }
    private fun editDataRow(table:String,headers:List<String>,values:List<String>,pkName:String,pkValue:String,onSaved:()->Unit){
        val safe=table.replace("\"","\"\"")
        val sets=headers.filterNot{it.equals(pkName,true)}.map{ "\"${it.replace("\"","\"\"")}\"=?" }
        if(sets.isEmpty()){
            showError("$table only has a primary key column; there are no editable fields")
            return
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val inputs=mutableListOf<EditText>()
        headers.forEachIndexed{i,h->
            val e=EditText(this).apply{
                setSingleLine(true);setText(if(values.getOrNull(i)=="NULL")"" else values.getOrNull(i).orEmpty())
                setTextColor(white);setHintTextColor(Color.rgb(105,108,119));hint=h;setPadding(dp(10),0,dp(10),0)
                background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),8f)
                isEnabled=!h.equals(pkName,true)
            }
            inputs.add(e);box.addView(e,LinearLayout.LayoutParams(-1,dp(40)).apply{bottomMargin=dp(5)})
        }
        cardDialog("Edit row",box,"Save"){
            try{
                val args=headers.filterNot{it.equals(pkName,true)}.map{h->inputs[headers.indexOf(h)].text.toString()}.toMutableList()
                args.add(pkValue)
                val sql="UPDATE \"$safe\" SET ${sets.joinToString(", ")} WHERE \"${pkName.replace("\"","\"\"")}\"=?"
                db.execSQL(sql,args.toTypedArray());statusOk("Row updated");onSaved()
            }catch(e:Exception){showError("Update failed: ${e.message?:"error"}")}
        }.show()
    }
    private fun showSchemaInspector(){
        val names=tableNames();if(names.isEmpty()){showError("No tables in the active database");return};cardListDialog("Schema Inspector",names){i->inspectTable(names[i])}
    }
    private fun inspectTable(table:String){
        val safe=table.replace("\"","\"\"");val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val summary=TextView(this).apply{textSize=11f;setTextColor(Color.rgb(150,146,158));setPadding(0,0,0,dp(8))};val cols=StringBuilder("COLUMNS\n");db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())cols.append("• ").append(c.getString(1)).append("  ").append(c.getString(2).ifBlank{"ANY"}).append(if(c.getInt(5)>0)"  PK" else "").append(if(c.getInt(3)>0)"  NOT NULL" else "").append("\n")};val idx=StringBuilder("\nINDEXES\n");db.rawQuery("PRAGMA index_list('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())idx.append("• ").append(c.getString(1)).append(if(c.getInt(2)>0)"  UNIQUE" else "").append("\n")};val fk=StringBuilder("\nFOREIGN KEYS\n");db.rawQuery("PRAGMA foreign_key_list('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())fk.append("• ").append(c.getString(3)).append(" → ").append(c.getString(2)).append(".").append(c.getString(4)).append("\n")};summary.text="${tableColumnCount(table)} columns  ·  ${tableRowCountText(table)}\n\n$cols$idx$fk";body.addView(summary);body.addView(TextView(this).apply{text="SQL definition";textSize=11f;setTextColor(Color.rgb(128,132,145));setPadding(0,dp(8),0,dp(4))});db.rawQuery("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",arrayOf(table)).use{c->if(c.moveToFirst())body.addView(TextView(this).apply{setText(c.getString(0));textSize=11f;setTextColor(Color.rgb(190,186,197));setPadding(0,0,0,dp(8));setTextIsSelectable(true)})};val scroll=ScrollView(this).apply{addView(body)};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};box.addView(scroll,LinearLayout.LayoutParams(-1,dp(360)));cardDialog("Inspect · $table",box).show()
    }
    private fun optimizeDatabase(){
        if(queryRunning){showError("Stop the running query before optimizing the database");return}
        if(!::db.isInitialized||!db.isOpen){showError("No active database");return}
        status.text="Optimizing database…";status.setTextColor(Color.rgb(170,165,178))
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        Thread{
            val started=System.nanoTime()
            try{
                // ANALYZE refreshes planner statistics; PRAGMA optimize lets SQLite
                // decide which maintenance is actually useful instead of forcing a
                // potentially huge VACUUM on a multi-GB database.
                try{executionDb.execSQL("PRAGMA optimize")}catch(_:Exception){}
                try{executionDb.execSQL("ANALYZE")}catch(_:Exception){}
                runOnUiThread{statusOk("Database optimized · ${elapsed(started)} ms");refreshSchemaPanel()}
            }catch(e:Exception){runOnUiThread{showError("Optimization failed: ${e.message?:"error"}")}}
        }.start()
    }
    private fun databasePerformanceInfo(){
        if(!::db.isInitialized||!db.isOpen){showError("No active database");return}
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        Thread{
            try{
                var pageSize=0L;var pageCount=0L;var freelist=0L
                executionDb.rawQuery("PRAGMA page_size",null).use{if(it.moveToFirst())pageSize=it.getLong(0)}
                executionDb.rawQuery("PRAGMA page_count",null).use{if(it.moveToFirst())pageCount=it.getLong(0)}
                executionDb.rawQuery("PRAGMA freelist_count",null).use{if(it.moveToFirst())freelist=it.getLong(0)}
                val tables=executionDb.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata'",null).use{if(it.moveToFirst())it.getInt(0) else 0}
                val size=pageSize*pageCount
                val free=pageSize*freelist
                runOnUiThread{
                    val text="${databaseLabel(executionDb.path)}\n\nTables  $tables\nDatabase  ${humanBytes(size)}\nFree pages  ${humanBytes(free)}\nPage size  ${humanBytes(pageSize)}\n\nLily keeps large results paged and streams imports/exports so database size does not become Android UI memory usage."
                    cardDialog("Database Performance",TextView(this).apply{setText(text);textSize=12f;setTextColor(white);setPadding(0,dp(8),0,dp(8));setTextIsSelectable(true)}).show()
                }
            }catch(e:Exception){runOnUiThread{showError("Could not read database stats: ${e.message?:"error"}")}}
        }.start()
    }
    private fun checkDatabaseIntegrity(){
        if(queryRunning){showError("Stop the running query before checking integrity");return}
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        status.text="Checking database integrity…";status.setTextColor(Color.rgb(170,165,178))
        Thread{
            try{
                val result=executionDb.rawQuery("PRAGMA integrity_check",null).use{c->
                    if(c.moveToFirst())c.getString(0) else "unknown"
                }
                runOnUiThread{
                    if(!isFinishing&&!isDestroyed){
                        if(result.equals("ok",true))statusOk("Database integrity check passed") else showError("Integrity check: $result")
                    }
                }
            }catch(e:Exception){runOnUiThread{if(!isFinishing&&!isDestroyed)showError("Integrity check failed: ${e.message?:"error"}")}}
        }.start()
    }
    private fun exportJson(){
        if(queryRunning){showError("Stop the running query before exporting");return}
        if(activeTab<0||tabs[activeTab].isError||tabs[activeTab].query.isNullOrBlank()){showError("Select a successful result query first");return}
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"query-result.json")}
        pendingCsv="__STREAM_JSON__";startActivityForResult(i,91)
    }
    private fun sqliteLiteral(c:Cursor,index:Int):String{
        return when(c.getType(index)){
            Cursor.FIELD_TYPE_NULL -> "NULL"
            Cursor.FIELD_TYPE_INTEGER -> c.getLong(index).toString()
            Cursor.FIELD_TYPE_FLOAT -> c.getDouble(index).toString()
            Cursor.FIELD_TYPE_BLOB -> { val bytes=c.getBlob(index); "X'"+bytes.joinToString(""){(it.toInt() and 0xFF).toString(16).padStart(2,'0').uppercase(Locale.US)}+"'" }
            else -> "'${c.getString(index).replace("'","''")}'"
        }
    }
    private fun jsonValue(c:Cursor,index:Int):String{
        return when(c.getType(index)){
            Cursor.FIELD_TYPE_NULL -> "null"
            Cursor.FIELD_TYPE_INTEGER -> c.getLong(index).toString()
            Cursor.FIELD_TYPE_FLOAT -> c.getDouble(index).toString()
            Cursor.FIELD_TYPE_BLOB -> "\"${jsonEscape(c.getBlob(index).joinToString(""){(it.toInt() and 0xFF).toString(16).padStart(2,'0').uppercase(Locale.US)})}\""
            else -> "\"${jsonEscape(c.getString(index))}\""
        }
    }
    private fun streamExportResult(uri:Uri, format:String, query:String){
        val executionDb=if(::db.isInitialized&&db.isOpen)db else null
        if(executionDb==null){showError("No active database");return}
        Thread {
            try{
                contentResolver.openOutputStream(uri)?.use{out->
                    OutputStreamWriter(out,Charsets.UTF_8).buffered().use{w->
                        executionDb.rawQuery(query,null).use{c->
                            if(format=="csv"){
                                for(i in 0 until c.columnCount){if(i>0)w.write(','.code);w.write(csvEscape(c.getColumnName(i)))};w.newLine()
                                while(c.moveToNext()){for(i in 0 until c.columnCount){if(i>0)w.write(','.code);w.write(csvEscape(if(c.isNull(i))"" else c.getString(i)))};w.newLine()}
                            }else{
                                w.write('['.code);var first=true
                                while(c.moveToNext()){if(!first)w.write(",\n");first=false;w.write("  {");for(i in 0 until c.columnCount){if(i>0)w.write(", ");w.write("\"${jsonEscape(c.getColumnName(i))}\":${jsonValue(c,i)}")};w.write("}")};w.newLine();w.write("]\n")
                            }
                        }
                    }
                } ?: throw Exception("Could not open destination")
                runOnUiThread{if(!isFinishing&&!isDestroyed)statusOk(if(format=="csv")"CSV exported from query" else "JSON exported from query")}
            }catch(e:Exception){runOnUiThread{if(!isFinishing&&!isDestroyed)showError("Export failed: ${e.message?:"error"}")}}
        }.start()
    }
    private fun jsonEscape(v:String)=v.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r")
    private fun showHistory(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        top.addView(TextView(this).apply{text="Recent queries";textSize=11f;setTextColor(Color.rgb(128,132,145));layoutParams=LinearLayout.LayoutParams(0,dp(32),1f)})
        val clear=TextView(this).apply{text="Clear";textSize=12f;setTextColor(blue);gravity=Gravity.CENTER;setPadding(dp(10),0,dp(10),0);isClickable=true;contentDescription="Clear query history"}
        top.addView(clear,LinearLayout.LayoutParams(dp(64),dp(32)))
        box.addView(top)
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_IF_CONTENT_SCROLLS}
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        fun render(){
            list.removeAllViews()
            if(history.isEmpty()){list.addView(TextView(this).apply{text="No query history yet.\nRun a query and it will appear here.";textSize=12f;setTextColor(Color.rgb(150,146,158));setPadding(dp(8),dp(16),dp(8),dp(16))})}
            else history.forEachIndexed{index,q->
                val row=TextView(this).apply{text=q.replace(Regex("\\s+")," ").trim();textSize=12f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setSingleLine(true);ellipsize=android.text.TextUtils.TruncateAt.END;setPadding(dp(10),0,dp(10),0);background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),10f);isClickable=true;contentDescription="Restore query ${index+1}"}
                row.setOnClickListener{editor.setText(q);editor.setSelection(editor.length());statusOk("Query restored from history");dialogRef?.dismiss()}
                list.addView(row,LinearLayout.LayoutParams(-1,dp(38)).apply{if(index>0)topMargin=dp(5)})
            }
        }
        scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(300)))
        val dialog=cardDialog("Quick History",box);dialogRef=dialog;dialog.setOnDismissListener{if(dialogRef===dialog)dialogRef=null}
        clear.setOnClickListener{
            if(history.isEmpty())return@setOnClickListener
            cardDialog("Clear history?",TextView(this).apply{text="This will remove all saved query history.";textSize=13f;setTextColor(white);setPadding(0,dp(8),0,dp(8))},"Clear"){history.clear();savePrefs();render()}.show()
        }
        render();dialog.show()
    }
    private fun saveSnippetDialog(){
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL
        val hint=TextView(this);hint.text="Give this query a short name.";hint.textSize=12f;hint.setTextColor(Color.rgb(127,131,144));box.addView(hint)
        val input=EditText(this);input.hint="e.g. My JOIN practice";input.setSingleLine(true);input.textSize=14f;input.setTextColor(white);input.setPadding(dp(12),0,dp(12),0);input.background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),12f);box.addView(input,LinearLayout.LayoutParams(-1,dp(48)).apply{topMargin=dp(10)})
        cardDialog("Save snippet",box,"Save"){val name=input.text.toString().trim();if(name.isNotEmpty()){snippets[name]=editor.text.toString();prefs.edit().putString("snippet:$name",editor.text.toString()).apply();statusOk("Snippet saved: $name")}}.show()
        input.requestFocus()
    }
    private fun showSnippetMenu(){
        val names=snippets.keys.toList();val items=if(names.isEmpty())listOf("＋  Save current snippet") else listOf("＋  Save current snippet")+names
        cardListDialog("Snippets",items){i->if(i==0)saveSnippetDialog()else{editor.setText(snippets[names[i-1]]);editor.setSelection(editor.length());statusOk("Snippet loaded")}}
    }
    private fun profileActiveQuery(){
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        if(activeTab<0||tabs[activeTab].isError||tabs[activeTab].query.isNullOrBlank()){showError("Select a successful result first");return}
        val q=tabs[activeTab].query!!.trim()
        if(!isQueryStatement(q)){showError("Profile is available for query statements");return}
        Thread{
            val started=System.nanoTime();var rowCount=0;var capped=false
            try{
                val compatible=runCompatibleSql(q)
                if(compatible.startsWith("EXPLAIN",true)){executionDb.rawQuery(compatible,null).use{c->while(c.moveToNext()){rowCount++;if(rowCount>=10000){capped=true;break}}}}
                else{executionDb.rawQuery(compatible,null).use{c->while(c.moveToNext()){rowCount++;if(rowCount>=10000){capped=true;break}}}}
                val ms=elapsed(started)
                val plan=runCatching{planRowsUsing(executionDb,"EXPLAIN QUERY PLAN $compatible")}.getOrElse{emptyList()}
                val scans=plan.filter{it.third.contains("SCAN",true)}
                val searches=plan.filter{it.third.contains("SEARCH",true)}
                val sorts=plan.count{it.third.contains("USE TEMP B-TREE",true)||it.third.contains("SORT",true)}
                runOnUiThread{
                    val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
                    val summary=TextView(this).apply{
                        text="Execution  $ms ms\nRows observed  ${if(capped)"10,000+" else rowCount}\n\n"+
                            when{scans.isNotEmpty()&&searches.isEmpty()->"⚠ Full table scan detected";sorts>0->"⚠ Temporary sort detected";else->"✓ Query executed and plan inspected"}
                        textSize=12.5f;setTextColor(white);setPadding(0,dp(4),0,dp(8))
                    };box.addView(summary)
                    if(scans.isNotEmpty())box.addView(TextView(this).apply{text="Scans  ${scans.size}   ·   Indexed searches  ${searches.size}   ·   Sorts  $sorts";textSize=10.5f;setTextColor(Color.rgb(150,146,158));setPadding(0,0,0,dp(7))})
                    box.addView(buildPlanView(plan),LinearLayout.LayoutParams(-1,dp(205)))
                    val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
                    if(scans.isNotEmpty())actions.addView(Button(ContextThemeWrapper(this,R.style.FlatButton_Accent)).apply{text="Index Advisor";isAllCaps=false;setOnClickListener{dialogRef?.dismiss();showIndexAdvisorForQuery(q)}} ,LinearLayout.LayoutParams(0,dp(36),1f))
                    box.addView(actions,LinearLayout.LayoutParams(-1,dp(36)).apply{topMargin=dp(6)})
                    cardDialog("Query Profile",box).show()
                }
            }catch(e:Exception){runOnUiThread{showError("Profile failed: ${e.message?:"SQL error"}")}}
        }.start()
    }
    private fun showIndexAdvisor(){
        val q=if(activeTab>=0&&!tabs[activeTab].isError)tabs[activeTab].query else editor.text.toString()
        if(q.isNullOrBlank()){showError("Write or run a query first");return}
        showIndexAdvisorForQuery(q.trim())
    }
    private data class IndexSuggestion(val table:String,val column:String,val reason:String)
    private fun showIndexAdvisorForQuery(q:String){
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        Thread{
            try{
                val plan=runCatching{val compatible=runCompatibleSql(q);planRowsUsing(executionDb,"EXPLAIN QUERY PLAN $compatible")}.getOrElse{emptyList()}
                val suggestions=mutableListOf<IndexSuggestion>()
                val tables=Regex("(?i)\\b(?:FROM|JOIN|UPDATE|INTO)\\s+([A-Za-z_][A-Za-z0-9_]*)").findAll(q).map{it.groupValues[1]}.distinct().toList()
                val predicates=Regex("(?i)\\b([A-Za-z_][A-Za-z0-9_]*)\\s*(?:=|<|>|<=|>=|LIKE|IN)\\s*").findAll(q).map{it.groupValues[1]}.distinct().toList()
                val joins=Regex("(?i)\\b(?:ON|WHERE)\\s+(?:[A-Za-z_][A-Za-z0-9_]*\\.)?([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(?:[A-Za-z_][A-Za-z0-9_]*\\.)?([A-Za-z_][A-Za-z0-9_]*)").findAll(q).flatMap{sequenceOf(it.groupValues[1],it.groupValues[2])}.distinct().toList()
                for(t in tables){
                    val existing=mutableSetOf<String>()
                    val safe=t.replace("'","''")
                    runCatching{executionDb.rawQuery("PRAGMA index_list('$safe')",null).use{c->while(c.moveToNext()){val idx=c.getString(1);executionDb.rawQuery("PRAGMA index_info('${idx.replace("'","''")}')",null).use{ic->while(ic.moveToNext())existing.add(ic.getString(2))}}}}
                    for(col in (predicates+joins).distinct()){
                        if(existing.none{it.equals(col,true)}) suggestions.add(IndexSuggestion(t,col,if(joins.contains(col))"Used in a join predicate" else "Used in a filter predicate"))
                    }
                }
                val fullScans=plan.count{it.third.contains("SCAN",true)}
                runOnUiThread{
                    val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
                    val intro=TextView(this).apply{text=if(suggestions.isEmpty())"No obvious missing single-column index was detected.\n\nLily does not create indexes automatically." else "Potential improvements based on the query plan.\nLily will never create an index without your approval.";textSize=11.5f;setTextColor(Color.rgb(150,146,158));setPadding(0,0,0,dp(8))};box.addView(intro)
                    val scroll=ScrollView(this);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
                    suggestions.distinctBy{it.table.lowercase()+"."+it.column.lowercase()}.take(12).forEach{sg->
                        val sql="CREATE INDEX idx_${sg.table}_${sg.column} ON \"${sg.table.replace("\"","\"\"")}\"(\"${sg.column.replace("\"","\"\"")}\");"
                        val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(8),dp(10),dp(8));background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),9f)}
                        row.addView(TextView(this).apply{text="${sg.table}.${sg.column}";textSize=12f;setTextColor(white)})
                        row.addView(TextView(this).apply{text="${sg.reason}\n$sql";textSize=10.5f;setTextColor(Color.rgb(170,165,178));setPadding(0,dp(3),0,0);setTextIsSelectable(true)})
                        list.addView(row,LinearLayout.LayoutParams(-1,dp(68)).apply{bottomMargin=dp(5)})
                    }
                    if(fullScans>0)list.addView(TextView(this).apply{text="⚠ $fullScans scan operation(s) appear in the current plan.";textSize=11f;setTextColor(orange);setPadding(dp(8),dp(8),dp(8),dp(8))})
                    if(suggestions.isEmpty()&&fullScans==0)list.addView(TextView(this).apply{text="✓ Plan looks reasonable for the available schema.";textSize=12f;setTextColor(green);setPadding(dp(8),dp(12),dp(8),dp(12))})
                    scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(280)));cardDialog("Index Advisor",box).show()
                }
            }catch(e:Exception){runOnUiThread{showError("Index Advisor failed: ${e.message?:"error"}")}}
        }.start()
    }
    private fun goToDefinition(){
        val pos=editor.selectionStart.coerceAtLeast(0);val before=editor.text.substring(0,pos);val after=editor.text.substring(pos.coerceAtMost(editor.length()));
        val token=(Regex("[A-Za-z_][A-Za-z0-9_]*$").find(before)?.value ?: Regex("^[A-Za-z_][A-Za-z0-9_]*").find(after)?.value).orEmpty()
        if(token.isBlank()){showError("Place the cursor on a table or column name first");return}
        val tables=tableNames();val table=tables.firstOrNull{it.equals(token,true)}
        if(table!=null){inspectTable(table);return}
        val matches=tables.flatMap{t->tableColumnsFor(t,token).map{t to it}}
        if(matches.size==1){editor.insertAtCursor(matches[0].second);statusOk("Definition: ${matches[0].first}.${matches[0].second}");return}
        if(matches.isNotEmpty()){cardListDialog("Column Definition",matches.map{"${it.first}.${it.second}"}){i->insertSql(matches[i].second);statusOk("Inserted ${matches[i].first}.${matches[i].second}")};return}
        showError("No table or column named $token was found")
    }
    private fun searchActiveResult(){
        if(activeTab<0||tabs[activeTab].csv==null){showError("Select a result first");return}
        val source=tabs[activeTab].csv!!
        val input=EditText(this).apply{
            hint="Search rows";setSingleLine(true);setTextColor(white);setHintTextColor(Color.rgb(105,108,119))
            background=rounded(Color.rgb(28,30,38),1,Color.rgb(54,56,66),10f);setPadding(dp(12),0,dp(12),0)
        }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(input,LinearLayout.LayoutParams(-1,dp(38)))
        val count=TextView(this).apply{setTextColor(Color.rgb(150,146,158));textSize=11f;setPadding(0,dp(8),0,dp(4))}
        box.addView(count)
        val scroll=ScrollView(this)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        scroll.addView(list)
        box.addView(scroll,LinearLayout.LayoutParams(-1,dp(220)))
        fun render(){
            list.removeAllViews()
            val needle=input.text.toString().trim()
            val matches=source.drop(1).filter{row->
                needle.isBlank() || row.joinToString(" ").lowercase(Locale.US).indexOf(needle.lowercase(Locale.US))>=0
            }
            count.text="${matches.size} matching row(s)"
            if(matches.isEmpty()){
                list.addView(TextView(this).apply{
                    text="No matching rows";setTextColor(Color.rgb(150,146,158));setPadding(dp(8),dp(14),dp(8),dp(14))
                })
            }else{
                matches.take(500).forEach{row->
                    list.addView(TextView(this).apply{
                        text=row.joinToString("  ·  ");setTextColor(white);textSize=11f;setSingleLine(true)
                        ellipsize=android.text.TextUtils.TruncateAt.END;setPadding(dp(8),dp(7),dp(8),dp(7))
                        setOnClickListener{copyText(row.joinToString("\t"))}
                    })
                }
            }
        }
        input.addTextChangedListener(object:TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()}
            override fun afterTextChanged(e:Editable?){}
        })
        render();cardDialog("Search Result",box).show();input.requestFocus()
    }
    private fun showExplain(msg:String){
        val lower=msg.lowercase();val hint=when{lower.contains("no such column")->"SQLite cannot find that column. Check spelling, table aliases, and whether the column belongs to the table you are querying.";lower.contains("no such table")->"SQLite cannot find that table. Check the table name and make sure you imported or created the right database.";lower.contains("syntax error")->"SQLite could not parse the SQL. Check commas, parentheses, quotes, keywords, and statement order.";lower.contains("constraint failed")->"A table constraint was violated. Check PRIMARY KEY, UNIQUE, NOT NULL, FOREIGN KEY, or CHECK rules.";lower.contains("datatype mismatch")->"A value does not fit the operation or column type. Check casts and the values being inserted or compared.";lower.contains("ambiguous column")->"More than one table has that column name. Qualify it with a table name or alias, for example e.salary.";else->"Run the statement again and inspect the SQLite message above. Start by checking table names, column names, aliases, commas, quotes, and parentheses."}
        val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;val icon=TextView(this);icon.text="SQLite error";icon.textSize=12f;icon.setTextColor(red);icon.setTypeface(null,android.graphics.Typeface.BOLD);box.addView(icon);val text=TextView(this);text.text=hint;text.textSize=14f;text.setTextColor(white);text.setPadding(0,dp(8),0,dp(8));box.addView(text);cardDialog("Explain this error",box).show()
    }
    private fun showPractice(){
        val challenges=listOf("Find employees older than 40","Join salary with demographics","Find the highest 3 salaries","Count employees by gender","Show all departments")
        cardListDialog("Practice mode",challenges.mapIndexed{i,s->"${i+1}.  $s"}){which->currentChallenge=which;editor.setText(challengeSql[which]);editor.setSelection(editor.length());statusOk("Challenge loaded — run it, then tap Check")}
    }
    private fun checkPractice(){if(currentChallenge<0){showError("Load a practice challenge first");return};try{val user=editor.text.toString();val expected=challengeSql[currentChallenge];val ur=collectResult(user);val er=collectResult(expected);if(ur==er)statusOk("Practice check passed ✓ — result matches the expected output")else showError("Practice check did not match the expected output. Compare columns, rows, ordering, and filters.")}catch(e:Exception){showError("Practice check error: ${e.message?:"SQL error"}")}}
    private fun collectResult(sql:String):List<List<String>>{val q=splitSql(sql).lastOrNull{isQueryStatement(it)}?:throw Exception("No query found");db.rawQuery(q,null).use{c->val out=mutableListOf<List<String>>();out.add((0 until c.columnCount).map{c.getColumnName(it)});while(c.moveToNext())out.add((0 until c.columnCount).map{if(c.isNull(it))"NULL" else c.getString(it)});return out}}
    private fun planRowsUsing(database:SQLiteDatabase,sql:String):List<Triple<Int,Int,String>>{val out=mutableListOf<Triple<Int,Int,String>>();database.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(Triple(c.getInt(0),c.getInt(1),c.getString(3))) };return out}
    private fun planRows(sql:String):List<Triple<Int,Int,String>>{val out=mutableListOf<Triple<Int,Int,String>>();db.rawQuery(sql,null).use{c->while(c.moveToNext())out.add(Triple(c.getInt(0),c.getInt(1),c.getString(3))) };return out}
    private fun buildPlanView(rows:List<Triple<Int,Int,String>>):View{val t=LinearLayout(this);t.orientation=LinearLayout.VERTICAL;t.setPadding(18,16,18,16);for((id,parent,detail) in rows){val v=TextView(this);v.text=(if(parent==0)"▸ " else "  └─ ")+detail+"  [id=$id parent=$parent]";v.textSize=13f;v.setTextColor(white);v.setPadding(8,8,8,8);t.addView(v)};val s=ScrollView(this);s.addView(t);return s}
    private fun exportDatabaseSql(){
        if(queryRunning){showError("Stop the running query before exporting");return}
        pendingDatabaseSqlExport=true
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/sql";putExtra(Intent.EXTRA_TITLE,"${dbFile.nameWithoutExtension}.sql")}
        startActivityForResult(i,94)
    }
    private fun streamDatabaseSqlExport(uri:Uri){
        val executionDb=if(::db.isInitialized&&db.isOpen)db else {showError("No active database");return}
        Thread{
            try{
                contentResolver.openOutputStream(uri)?.use{raw->
                    OutputStreamWriter(raw,Charsets.UTF_8).buffered().use{w->
                        w.write("PRAGMA foreign_keys=OFF;\nBEGIN TRANSACTION;\n\n")
                        executionDb.rawQuery("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",null).use{c->
                            while(c.moveToNext()){
                                val name=c.getString(0);val ddl=c.getString(1)
                                if(!ddl.isNullOrBlank())w.write(ddl.trimEnd(';')+";\n")
                                val safe=name.replace("\"","\"\"")
                                executionDb.rawQuery("SELECT * FROM \"$safe\"",null).use{r->
                                    val cols=(0 until r.columnCount).map{r.getColumnName(it)}
                                    val quotedCols=cols.joinToString(", "){"\"${it.replace("\"","\"\"")}\""}
                                    while(r.moveToNext()){
                                        val vals=(0 until r.columnCount).joinToString(", "){i->sqliteLiteral(r,i)}
                                        w.write("INSERT INTO \"$safe\" ($quotedCols) VALUES ($vals);\n")
                                    }
                                }
                                w.write("\n")
                            }
                        }
                        executionDb.rawQuery("SELECT type, name, sql FROM sqlite_master WHERE type IN ('index','trigger','view') AND sql IS NOT NULL ORDER BY CASE type WHEN 'view' THEN 1 WHEN 'index' THEN 2 ELSE 3 END, name",null).use{c->
                            while(c.moveToNext())w.write(c.getString(2).trimEnd(';')+";\n")
                        }
                        w.write("\nCOMMIT;\nPRAGMA foreign_keys=ON;\n")
                    }
                } ?: throw Exception("Could not open output file")
                runOnUiThread{if(!isFinishing&&!isDestroyed)statusOk("Database SQL export complete")}
            }catch(e:Exception){runOnUiThread{if(!isFinishing&&!isDestroyed)showError("Database SQL export failed: ${e.message?:"error"}")}}
        }.start()
    }
    private fun exportDatabase(){
        if(queryRunning){showError("Stop the running query before exporting");return}
        val source=dbFile
        pendingDatabaseExportPath=source.path
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,"ProjectLily-${source.name}")}
        startActivityForResult(i,88)
    }
    private fun exportCsv(){
        if(queryRunning){showError("Stop the running query before exporting");return}
        if(activeTab<0||tabs[activeTab].isError||tabs[activeTab].query.isNullOrBlank()){showError("Select a successful result query first");return}
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="text/csv";putExtra(Intent.EXTRA_TITLE,"query-result.csv")}
        startActivityForResult(i,90)
    }
    private fun csvEscape(s:String)=if(s.contains(',')||s.contains('"')||s.contains('\n'))"\"${s.replace("\"","\"\"")}\"" else s
    private fun dp(value:Int):Int=(value*resources.displayMetrics.density).roundToInt()
    private fun rounded(fill:Int, stroke:Int, strokeColor:Int, radius:Float):android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply{
            setColor(fill)
            if(stroke>0)setStroke(dp(stroke),strokeColor)
            cornerRadius=dp(radius.toInt()).toFloat()
        }
    private fun animatePopupIn(view:View){view.alpha=0f;view.scaleX=.97f;view.scaleY=.97f;view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(145).setInterpolator(android.view.animation.DecelerateInterpolator()).start()}
    private fun showEditorContextMenu(anchor:View,x:Float,y:Float){
        val hasSelection=editor.selectionStart!=editor.selectionEnd
        val popup=PopupWindow(this)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(4),dp(4),dp(4),dp(4));background=rounded(Color.rgb(29,30,36),1,Color.rgb(78,79,87),11f);elevation=dp(9).toFloat()}
        fun item(icon:String,label:String,enabled:Boolean=true,action:()->Unit){
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(6),0,dp(8),0);isClickable=enabled;alpha=if(enabled)1f else .42f;background=rounded(Color.TRANSPARENT,0,Color.TRANSPARENT,7f)}
            row.addView(TextView(this).apply{text=icon;textSize=11f;setTextColor(Color.rgb(218,218,223));gravity=Gravity.CENTER;layoutParams=LinearLayout.LayoutParams(dp(23),dp(29))})
            row.addView(TextView(this).apply{text=label;textSize=11.5f;setTextColor(Color.rgb(236,235,239));gravity=Gravity.CENTER_VERTICAL;layoutParams=LinearLayout.LayoutParams(-2,dp(29))})
            row.setOnHoverListener{v,e->if(e.action==MotionEvent.ACTION_HOVER_ENTER)v.setBackgroundColor(Color.rgb(53,54,62));else if(e.action==MotionEvent.ACTION_HOVER_EXIT)v.setBackgroundColor(Color.TRANSPARENT);false}
            row.setOnClickListener{if(enabled){popup.dismiss();action()}};root.addView(row)
        }
        fun divider(){root.addView(View(this).apply{setBackgroundColor(Color.rgb(65,66,73))},LinearLayout.LayoutParams(-1,1).apply{topMargin=dp(2);bottomMargin=dp(2)})}
        item("↶","Undo"){editor.onTextContextMenuItem(android.R.id.undo)};divider();item("✂","Cut",hasSelection){editor.onTextContextMenuItem(android.R.id.cut)};item("▣","Copy",hasSelection){editor.onTextContextMenuItem(android.R.id.copy)};item("▢","Paste"){editor.onTextContextMenuItem(android.R.id.paste)};item("⌗","Select all"){editor.onTextContextMenuItem(android.R.id.selectAll)};divider();item("✦","Auto-fill"){if(android.os.Build.VERSION.SDK_INT>=26)editor.onTextContextMenuItem(android.R.id.autofill)};item("↗","Share"){val text=if(hasSelection)editor.text.substring(minOf(editor.selectionStart,editor.selectionEnd),maxOf(editor.selectionStart,editor.selectionEnd)) else editor.text.toString();val share=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)};startActivity(Intent.createChooser(share,"Share SQL"))}
        popup.contentView=root;popup.width=dp(126);popup.height=dp(222);popup.isFocusable=true;popup.isOutsideTouchable=true;popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));val loc=IntArray(2);anchor.getLocationOnScreen(loc);val screenW=resources.displayMetrics.widthPixels;val screenH=resources.displayMetrics.heightPixels;val px=(loc[0]+x).toInt();val py=(loc[1]+y).toInt();val left=px.coerceIn(dp(8),screenW-popup.width-dp(8));val top=(if(py+popup.height+dp(5)<screenH)py+dp(5) else py-popup.height-dp(5)).coerceIn(dp(8),screenH-popup.height-dp(8));popup.showAtLocation(anchor,Gravity.TOP or Gravity.START,left,top);animatePopupIn(root)
    }
    private fun installMacPointerIcons(){
        if(android.os.Build.VERSION.SDK_INT<24)return
        val size=dp(20);val bmp=android.graphics.Bitmap.createBitmap(size,size,android.graphics.Bitmap.Config.ARGB_8888);val c=Canvas(bmp);val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.FILL};val path=android.graphics.Path().apply{moveTo(dp(2).toFloat(),dp(1).toFloat());lineTo(dp(2).toFloat(),dp(16).toFloat());lineTo((6.5f*resources.displayMetrics.density).toFloat(),dp(12.5f).toFloat());lineTo((9.5f*resources.displayMetrics.density).roundToInt().toFloat(),dp(18).toFloat());lineTo(dp(12).toFloat(),dp(16.5f).toFloat());lineTo(dp(9).toFloat(),dp(11.5f).toFloat());lineTo(dp(14).toFloat(),dp(11.5f).toFloat());close()};p.color=Color.argb(190,0,0,0);c.save();c.translate((.7f*resources.displayMetrics.density).toFloat(),(.7f*resources.displayMetrics.density).toFloat());c.drawPath(path,p);c.restore();p.color=Color.WHITE;c.drawPath(path,p);val icon=android.view.PointerIcon.create(bmp,dp(2).toFloat(),dp(1).toFloat());fun apply(v:View){v.pointerIcon=icon;if(v is ViewGroup)for(i in 0 until v.childCount)apply(v.getChildAt(i))};apply(window.decorView);editor.pointerIcon=android.view.PointerIcon.getSystemIcon(this,android.view.PointerIcon.TYPE_TEXT)
    }
    private fun insertSql(text:String){
        dismissAutocomplete()
        val start=editor.selectionStart.coerceAtLeast(0)
        val end=editor.selectionEnd.coerceAtLeast(0)
        val a=minOf(start,end).coerceIn(0,editor.length())
        val b=maxOf(start,end).coerceIn(a,editor.length())
        try{
            editor.text.replace(a,b,text)
            editor.setSelection((a+text.length).coerceAtMost(editor.length()))
            editor.requestFocus()
            highlight()
        }catch(e:Exception){showError("Could not insert into editor")}
    }
    private fun cardDialog(titleText:String, content:View, positiveText:String?=null, positiveAction:(()->Unit)?=null):AlertDialog{
        val outer=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(14),dp(18),dp(16))
            background=rounded(Color.rgb(20,22,29),1,Color.rgb(58,53,64),18f)
        }
        val titleRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val title=TextView(this).apply{text=titleText;textSize=15f;setTextColor(white);setTypeface(null,android.graphics.Typeface.BOLD);gravity=Gravity.CENTER_VERTICAL;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1}
        titleRow.addView(title,LinearLayout.LayoutParams(0,dp(32),1f))
        val close=TextView(this).apply{text="×";textSize=22f;setTextColor(Color.rgb(145,140,151));gravity=Gravity.CENTER;isClickable=true;contentDescription="Close";setOnClickListener{}}
        titleRow.addView(close,LinearLayout.LayoutParams(dp(32),dp(32)))
        outer.addView(titleRow)
        val divider=View(this).apply{setBackgroundColor(Color.rgb(42,44,53))}
        outer.addView(divider,LinearLayout.LayoutParams(-1,dp(1)).apply{topMargin=dp(8);bottomMargin=dp(12)})
        outer.addView(content,LinearLayout.LayoutParams(-1,0,1f))
        val dialog=AlertDialog.Builder(this).setView(outer).create()
        close.setOnClickListener{dialog.dismiss()}
        positiveText?.let{label->
            val action=Button(ContextThemeWrapper(this,R.style.FlatButton_Accent)).apply{text=label;isAllCaps=false;setOnClickListener{positiveAction?.invoke();dialog.dismiss()}}
            outer.addView(action,LinearLayout.LayoutParams(-1,dp(42)).apply{topMargin=dp(12)})
        }
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setOnShowListener{dialog.window?.let{w->w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.34f);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);val maxW=dp(430);val screenW=resources.displayMetrics.widthPixels;w.setLayout(minOf(maxW,screenW-dp(28)),WindowManager.LayoutParams.WRAP_CONTENT)};outer.alpha=0f;outer.scaleX=.97f;outer.scaleY=.97f;outer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(150).setInterpolator(android.view.animation.DecelerateInterpolator()).start()}
        return dialog
    }
    private fun cardListDialog(title:String, items:List<String>, onPick:(Int)->Unit){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_NEVER}
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        if(items.isEmpty()){
            list.addView(TextView(this).apply{text="Nothing here yet.";textSize=12f;setTextColor(Color.rgb(150,146,158));setPadding(dp(8),dp(14),dp(8),dp(14))})
        }else{
            items.forEachIndexed{index,label->
                val row=TextView(this).apply{text=label;textSize=12.5f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL;setPadding(dp(11),0,dp(11),0);background=rounded(Color.rgb(28,30,38),1,Color.rgb(48,51,62),9f);isClickable=true;ellipsize=android.text.TextUtils.TruncateAt.END;maxLines=1}
                row.setOnClickListener{onPick(index);dialogRef?.dismiss()}
                list.addView(row,LinearLayout.LayoutParams(-1,dp(38)).apply{if(index>0)topMargin=dp(4)})
            }
        }
        scroll.addView(list);box.addView(scroll,LinearLayout.LayoutParams(-1,dp(310)))
        val dialog=cardDialog(title,box)
        dialogRef=dialog
        dialog.setOnDismissListener{if(dialogRef===dialog)dialogRef=null}
        dialog.show()
    }
    private var dialogRef:AlertDialog?=null
    private fun EditText.insertAtCursor(value:String){val p=selectionStart.coerceAtLeast(0);text.replace(p,p,value);setSelection((p+value.length).coerceAtMost(length()))}
    private fun updateAutocomplete(){
        dismissAutocomplete()
        if(!editor.hasFocus() || !::db.isInitialized || !db.isOpen) return
        val cursor=editor.selectionStart
        if(cursor<0 || editor.selectionStart!=editor.selectionEnd) return
        val before=editor.text.substring(0,cursor)
        val tokenMatch=Regex("[A-Za-z_][A-Za-z0-9_]*$").find(before)
        val token=tokenMatch?.value.orEmpty()
        val tokenStart=if(token.isNotEmpty())cursor-token.length else cursor
        val left=before.substring(0,tokenStart)
        val trimmed=left.trimEnd()
        val qualified=Regex("([A-Za-z_][A-Za-z0-9_]*)\\.$").find(trimmed)?.groupValues?.get(1)
        val mode=when{
            qualified!=null -> "qualified"
            token.isEmpty() -> null
            Regex("\\b(?:FROM|JOIN|UPDATE|INTO|TABLE)\\s*$",RegexOption.IGNORE_CASE).containsMatchIn(trimmed) -> "table"
            Regex("\\b(?:SELECT|WHERE|ON|ORDER\\s+BY|GROUP\\s+BY|HAVING|SET|AND|OR)\\s*$",RegexOption.IGNORE_CASE).containsMatchIn(trimmed) -> "column"
            else -> null
        } ?: return
        val suggestions=when(mode){
            "table" -> tableSuggestions(token)
            "qualified" -> qualifiedColumnSuggestions(qualified!!,token)
            else -> columnSuggestions(before,token)
        }.distinct().take(6)
        if(suggestions.isEmpty()) return
        val popup=PopupWindow(this)
        autocompletePopup=popup
        autocompleteTokenStart=tokenStart
        val list=LinearLayout(this).apply{
            orientation=LinearLayout.VERTICAL
            setPadding(dp(3),dp(3),dp(3),dp(3))
            background=rounded(Color.rgb(20,22,29),1,Color.rgb(53,48,58),10f)
        }
        suggestions.forEachIndexed{index,suggestion->
            val row=TextView(this).apply{
                text=suggestion;textSize=13f;setTextColor(white);gravity=Gravity.CENTER_VERTICAL
                setPadding(dp(10),0,dp(10),0);isSingleLine=true
                background=rounded(if(index==0)Color.rgb(43,34,42) else Color.rgb(28,30,38),0,Color.TRANSPARENT,6f)
                setOnClickListener{
                    val start=autocompleteTokenStart;val end=editor.selectionStart
                    if(start in 0..end && end<=editor.length()){
                        try{
                            editor.text.replace(start,end,suggestion)
                            editor.setSelection((start+suggestion.length).coerceAtMost(editor.length()))
                        }catch(_:Throwable){}
                    }
                    dismissAutocomplete();editor.requestFocus()
                }
            }
            list.addView(row,LinearLayout.LayoutParams(-1,dp(32)).apply{if(index>0)topMargin=dp(2)})
        }
        popup.contentView=list;popup.width=dp(210);popup.height=dp(6+32*suggestions.size+2*(suggestions.size-1))
        popup.isFocusable=false;popup.isOutsideTouchable=true;popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));popup.elevation=dp(5).toFloat()
        editor.post{positionAutocomplete(popup)}
    }
    private fun tableSuggestions(token:String):List<String>{
        val out=mutableListOf<String>()
        db.rawQuery("SELECT name FROM sqlite_master WHERE (type='table' OR type='view') AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",null).use{c->while(c.moveToNext()){val n=c.getString(0);if(n.startsWith(token,true))out.add(n)}}
        return out
    }
    private fun columnSuggestions(before:String,token:String):List<String>{
        val tables=Regex("\\b(?:FROM|JOIN)\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s+(?:AS\\s+)?([A-Za-z_][A-Za-z0-9_]*))?",RegexOption.IGNORE_CASE).findAll(before)
            .flatMap{sequenceOf(it.groupValues[1],it.groupValues.getOrNull(2).orEmpty())}.filter{it.isNotBlank()}.toList().distinct()
        if(tables.isEmpty())return emptyList()
        return tables.flatMap{tableColumnsFor(it,token)}.distinct()
    }
    private fun qualifiedColumnSuggestions(qualifier:String,token:String):List<String>{
        val direct=tableSuggestions(qualifier).firstOrNull{it.equals(qualifier,true)}
        if(direct!=null)return tableColumnsFor(direct,token)
        val match=Regex("\\b(?:FROM|JOIN)\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s+AS)?\\s+${Regex.escape(qualifier)}\\b",RegexOption.IGNORE_CASE).find(editor.text.substring(0,editor.selectionStart))
        return match?.groupValues?.get(1)?.let{tableColumnsFor(it,token)} ?: emptyList()
    }
    private fun tableColumnsFor(table:String,token:String):List<String>{
        val out=mutableListOf<String>();val safe=table.replace("'","''")
        try{db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext()){val n=c.getString(1);if(token.isEmpty()||n.startsWith(token,true))out.add(n)}}}catch(_:Exception){}
        return out
    }
    private fun positionAutocomplete(popup:PopupWindow){
        if(autocompletePopup!==popup || !editor.isShown) return
        val layout=editor.layout ?: return
        val cursor=editor.selectionStart.coerceIn(0,editor.length())
        val line=layout.getLineForOffset(cursor)
        val x=layout.getPrimaryHorizontal(cursor).toInt()-editor.scrollX
        val lineTop=layout.getLineTop(line)-editor.scrollY
        val loc=IntArray(2)
        editor.getLocationOnScreen(loc)
        val popupW=popup.width
        val margin=dp(8)
        val screenW=resources.displayMetrics.widthPixels
        val screenH=resources.displayMetrics.heightPixels
        val px=(loc[0]+x).coerceIn(margin,(screenW-popupW-margin).coerceAtLeast(margin))
        val popupH=popup.height
        var py=loc[1]+lineTop+editor.lineHeight+dp(3)
        if(py+popupH>screenH-margin) py=loc[1]+lineTop-popupH-dp(3)
        py=py.coerceAtLeast(margin)
        try{popup.showAtLocation(editor,Gravity.TOP or Gravity.START,px,py)}catch(_:WindowManager.BadTokenException){dismissAutocomplete()}
    }
    private fun dismissAutocomplete(){
        autocompletePopup?.dismiss()
        autocompletePopup=null
        autocompleteTokenStart=-1
    }
    internal fun shouldKeepAutocompleteVisible():Boolean = suppressAutocompleteDismiss
    internal fun dismissAutocompleteFromEditor(){dismissAutocomplete()}
    override fun onKeyDown(keyCode:Int,event:KeyEvent):Boolean{if((event.isCtrlPressed||event.isMetaPressed)&&keyCode==KeyEvent.KEYCODE_ENTER){runSelectedOrAll();return true};if((event.isCtrlPressed||event.isMetaPressed)&&keyCode==KeyEvent.KEYCODE_SLASH){toggleComment();return true};return super.onKeyDown(keyCode,event)}
    override fun onDestroy(){importCancelled=true;queryCancelled=true;activeQueryCancellation?.cancel();dismissAutocomplete();if(::db.isInitialized&&db.isOpen)db.close();super.onDestroy()}
    override fun onPause(){persistCurrentScript();saveScriptTabs();super.onPause()}
}
