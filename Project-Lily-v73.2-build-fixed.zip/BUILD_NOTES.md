# Project Lily v72 — SQL Editor polish + custom import browser

Implemented from v71.1 baseline:

- Database deletion flow streamlined: right-click Delete now opens one confirmation dialog with **Confirm Delete**; no redundant second dialog.
- Existing long-press database actions retained, with the same single confirmation step.
- Parks & Recreation remains protected from deletion but is fully selectable/activatable, including from the database tree/switcher.
- Editor native Android selection/insertion action-mode toolbars are suppressed so Lily's custom context menu does not appear alongside Translate/Cut/Copy/Paste/Share.
- Editor context menu tightened to a compact macOS-inspired desktop menu with content-fitting width, smaller row heights, balanced icon/text spacing, subtle separators and restrained animation.
- Mouse pointer treatment refined: smaller, crisp macOS-inspired arrow with subtle outline; editor keeps the text I-beam.
- Import now opens a custom Lily import browser instead of immediately launching the native Android file picker.
- Import browser uses Android's Storage Access Framework for secure access: users add a folder once, Lily persists permission, and subsequent browsing/selection happens in Lily's UI.
- Browser supports folders and SQL/SQLite/CSV/TSV/JSON files, plus recent Lily-imported files.
- Native Android folder picker is used only when granting a new storage location; it is not the normal import UI.
- Existing SQL import hardening and background import/query behavior retained.
- No zoom percentage popup restored.
- Existing compact run/current-statement controls and lightweight interaction motion retained.

Build workflow: `.github/workflows/android-build.yml` uses Gradle 8.10.2 + JDK 17.


## v73 Performance
Moved expensive schema/file-provider/preview/autocomplete work to a shared background executor, added lazy async database tree expansion, debounced editor highlighting, and lifecycle-safe cancellation.

## v73.1 performance hardening
- Database summaries are cached and warmed asynchronously so sidebar/switcher opening does not synchronously open every database.
- Database tree expansion loads schema metadata asynchronously and only builds the expanded branch.
- Import Browser directory enumeration uses the background executor.
- Table previews use background DB reads before attaching the 50-row view.
- Autocomplete schema lookups run on the background executor and ignore stale results.
- Editor highlighting is debounced to avoid a full-document regex pass on every keystroke.
- Result grid remains bounded/virtualized: only visible rows are drawn.
