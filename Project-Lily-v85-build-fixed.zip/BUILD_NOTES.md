# Project Lily v83 — Result Export Isolated

- Added `ResultExportController.kt` to own CSV export for result-tab datasets.
- Middle window dot CSV action now exports the active successful result.
- Long-press or mouse right-click on a result tab opens a compact `Export CSV` action for that tab.
- Removed duplicate result/table CSV menu entries elsewhere.
- Removed visible Explain and +/- zoom controls from both phone and sw600dp layouts; pinch zoom behavior remains in the editor/result views.
- Kept SQL EXPLAIN support in the query engine intact; only the visible Explain UI/action was removed.
- Kept database/table SQL export functionality intact.
- No changes to database tree, import, autocomplete, gutter/mouse handling, command-palette movement, query execution, or error-panel behavior beyond removing the visible Explain Error button.

Build note: full Android Gradle build was not run in this environment because the Android SDK/Gradle toolchain is unavailable.
