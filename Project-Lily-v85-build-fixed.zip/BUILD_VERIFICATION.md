Project Lily v76.1 safety patch

Source baseline: v76 final fixes.
Verified: gutter current-line rectangle removed; line numbers use scroll-aware Layout coordinates; physical mouse secondary-click is intercepted by LineNumberEditText; Activity-level context-click listener removed; native ACTION_OPEN_DOCUMENT import retained; custom import-browser code absent; movable command palette position persistence retained; compact script-tab dimensions retained; current statement indicator is a no-op; duplicate startActionMode overrides absent.

Runtime Android/Gradle build was not executed in this environment because the Android SDK/Gradle toolchain is unavailable.
