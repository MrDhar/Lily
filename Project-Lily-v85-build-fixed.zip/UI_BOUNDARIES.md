# Project Lily — UI boundaries

This version intentionally separates the most regression-prone UI components.

- `LineNumberEditText.kt` — editor widget, gutter drawing, mouse secondary-click interception, selection/action-mode suppression.
- `VirtualResultGridView.kt` — result grid rendering, scrolling, zoom, column resizing.
- `LoadingDotsView.kt` — import progress animation.
- `MainActivity.kt` — application coordination and feature workflows.

## Safe-change rule

When fixing the gutter, edit `LineNumberEditText.kt` only unless a layout change is genuinely required.

When fixing mouse right-click/context behavior, edit `LineNumberEditText.kt` and the existing context-menu method only.

Do not change database-tree code, script-tab code, command-palette positioning, import workflow, or result/error logic for an editor-only fix.

The movable three-button command panel and its persisted position are intentionally preserved.
