package com.maalik.projectlily

import android.app.Activity
import android.content.Intent
import android.net.Uri
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets

/** Owns exporting data currently displayed in result tabs. */
internal class ResultExportController(
    private val activity: Activity,
    private val resultProvider: (Int) -> List<List<String>>?
) {
    companion object { const val REQUEST_CODE = 95 }


    private var pendingData: List<List<String>>? = null
    private var pendingTitle: String = "query-result"

    fun exportTab(index: Int, title: String? = null) {
        val data = resultProvider(index)
        if (data.isNullOrEmpty() || data.size < 1) {
            Toasts.error(activity, "No result data to export")
            return
        }
        pendingData = data
        pendingTitle = safeFileName(title ?: "query-result")
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "$pendingTitle.csv")
        }
        activity.startActivityForResult(intent, REQUEST_CODE)
    }

    fun exportActive(activeIndex: Int, title: String? = null) = exportTab(activeIndex, title)

    fun handleActivityResult(requestCode: Int, resultCode: Int, uri: Uri?): Boolean {
        if (requestCode != REQUEST_CODE) return false
        if (resultCode == Activity.RESULT_OK && uri != null) {
            pendingData?.let { writeCsv(uri, it, pendingTitle) }
        }
        pendingData = null
        pendingTitle = "query-result"
        return true
    }

    private fun writeCsv(uri: Uri, data: List<List<String>>, title: String) {
        Thread {
            try {
                activity.contentResolver.openOutputStream(uri)?.use { raw ->
                    OutputStreamWriter(raw, StandardCharsets.UTF_8).buffered().use { out ->
                        data.forEach { row ->
                            row.forEachIndexed { i, value ->
                                if (i > 0) out.write(','.code)
                                out.write(csvEscape(value))
                            }
                            out.newLine()
                        }
                    }
                } ?: throw IllegalStateException("Could not open output file")
                activity.runOnUiThread { Toasts.ok(activity, "Exported $title as CSV") }
            } catch (e: Exception) {
                activity.runOnUiThread { Toasts.error(activity, "CSV export failed: ${e.message ?: "error"}") }
            }
        }.start()
    }

    private fun safeFileName(value: String): String = value
        .replace(Regex("[^A-Za-z0-9._ -]"), "_")
        .trim()
        .ifBlank { "query-result" }
        .take(80)

    private fun csvEscape(value: String): String = if (
        value.contains(',') || value.contains('"') || value.contains('\n') || value.contains('\r')
    ) "\"${value.replace("\"", "\"\"")}\"" else value

    private object Toasts {
        fun ok(activity: Activity, message: String) = android.widget.Toast.makeText(activity, message, android.widget.Toast.LENGTH_SHORT).show()
        fun error(activity: Activity, message: String) = android.widget.Toast.makeText(activity, message, android.widget.Toast.LENGTH_LONG).show()
    }
}
