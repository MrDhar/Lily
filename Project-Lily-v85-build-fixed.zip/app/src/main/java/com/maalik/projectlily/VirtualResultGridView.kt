package com.maalik.projectlily

import android.animation.ValueAnimator
import android.content.*
import android.database.Cursor
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.text.*
import android.view.*
import android.widget.*
import android.view.animation.LinearInterpolator
import kotlin.math.min

class VirtualResultGridView(
    context: Context,
    private val rows: List<List<String>>,
    private val truncated: Boolean,
    private val onHeaderClick: ((Int) -> Unit)? = null,
    private val onCellClick: ((String) -> Unit)? = null,
    initialZoom: Float = 1f,
    private val onZoomChanged: ((Float) -> Unit)? = null
) : View(context) {
    private val density = resources.displayMetrics.density
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f * density; color = Color.rgb(231,227,233); typeface = android.graphics.Typeface.MONOSPACE }
    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f * density; color = Color.rgb(185,181,191); typeface = android.graphics.Typeface.MONOSPACE }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(48,51,62); strokeWidth = density }
    private val headerBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(28,31,39) }
    private val rowBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(24,26,33) }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f * density; color = Color.rgb(140,136,148) }
    private val baseRowHeight = (34f * density).toInt().coerceAtLeast(28)
    private val baseHeaderHeight = (38f * density).toInt().coerceAtLeast(32)
    private val rowHeight get() = (baseRowHeight * zoom).toInt().coerceAtLeast((24*density).toInt())
    private val headerHeight get() = (baseHeaderHeight * zoom).toInt().coerceAtLeast((28*density).toInt())
    private var scrollXpx = 0f
    private var scrollYpx = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var lastX = 0f
    private var lastY = 0f
    private var colWidths = IntArray(0)
    private var contentWidth = 0
    private var zoom = initialZoom.coerceIn(0.42f,1.30f)
    private val scaleDetector = android.view.ScaleGestureDetector(context, object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener(){ override fun onScale(d:android.view.ScaleGestureDetector):Boolean{ setZoom(zoom*d.scaleFactor); return true } })
    private var resizingColumn = -1
    private var resizeStartX = 0f
    private var resizeStartWidth = 0
    fun setZoom(value: Float) { zoom = value.coerceIn(0.42f, 1.30f); calculateWidths(); requestLayout(); invalidate(); onZoomChanged?.invoke(zoom) }
    init {
        isFocusable = true
        setBackgroundColor(Color.rgb(15,16,21))
        calculateWidths()
    }
    private fun calculateWidths() {
        if (rows.isEmpty()) return
        val cols = rows.maxOf { it.size }
        colWidths = IntArray(cols)
        for (c in 0 until cols) {
            var maxChars = 8
            val sampleEnd = min(rows.size, 1001)
            for (r in 0 until sampleEnd) maxChars = maxOf(maxChars, rows[r].getOrElse(c) { "" }.length.coerceAtMost(42))
            colWidths[c] = ((maxChars * 7.2f + 28f) * density * zoom).toInt().coerceIn((88*density).toInt(), (360*density).toInt())
        }
        contentWidth = colWidths.sum()
    }
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val desiredRows = rows.size.coerceAtMost(1001) + if (truncated) 1 else 0
        val desiredH = headerHeight + desiredRows * rowHeight
        val h = when (MeasureSpec.getMode(heightMeasureSpec)) {
            MeasureSpec.EXACTLY, MeasureSpec.AT_MOST -> MeasureSpec.getSize(heightMeasureSpec)
            else -> desiredH
        }
        setMeasuredDimension(w, h)
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (rows.isEmpty()) return
        val maxScrollX = (contentWidth - width).coerceAtLeast(0).toFloat()
        val footer = if (truncated) (rowHeight + 12 * density).toInt() else 0
        val contentHeight = headerHeight + (rows.size - 1).coerceAtLeast(0) * rowHeight + footer
        val maxScrollY = (contentHeight - height).coerceAtLeast(0).toFloat()
        scrollXpx = scrollXpx.coerceIn(0f, maxScrollX)
        scrollYpx = scrollYpx.coerceIn(0f, maxScrollY)
        // Body scrolls in both directions. The header is drawn separately so it
        // remains pinned while vertically scrolling, like a desktop data grid.
        canvas.save()
        canvas.clipRect(0f, headerHeight.toFloat(), width.toFloat(), height.toFloat())
        canvas.translate(-scrollXpx, -scrollYpx)
        var x=0f
        for(c in colWidths.indices){
            canvas.drawLine(x + colWidths[c], headerHeight.toFloat(), x + colWidths[c], contentHeight.toFloat(), linePaint)
            x += colWidths[c]
        }
        val firstRow=maxOf(1,1+((scrollYpx-headerHeight).toInt().coerceAtLeast(0)/rowHeight))
        val lastRow=min(rows.size,firstRow+height/rowHeight+4)
        for(r in firstRow until lastRow){
            val top=headerHeight+(r-1)*rowHeight
            if(r%2==0)canvas.drawRect(0f,top.toFloat(),contentWidth.toFloat(),(top+rowHeight).toFloat(),rowBg)
            x=0f
            for(c in colWidths.indices){
                canvas.drawText(ellipsize(rows[r].getOrElse(c){"NULL"},c),x+14*density,top+rowHeight/2f+4*density,textPaint)
                canvas.drawLine(x+colWidths[c],top.toFloat(),x+colWidths[c],(top+rowHeight).toFloat(),linePaint);x+=colWidths[c]
            }
            canvas.drawLine(0f,(top+rowHeight).toFloat(),contentWidth.toFloat(),(top+rowHeight).toFloat(),linePaint)
        }
        if(truncated){
            val footerY=headerHeight+(rows.size-1)*rowHeight
            canvas.drawText("Showing first ${rows.size-1} rows · result continues",14*density,footerY+rowHeight/2f+4*density,hintPaint)
        }
        canvas.restore()
        canvas.save()
        canvas.clipRect(0f,0f,width.toFloat(),headerHeight.toFloat())
        canvas.translate(-scrollXpx,0f)
        canvas.drawRect(0f,0f,contentWidth.toFloat(),headerHeight.toFloat(),headerBg)
        x=0f
        for(c in colWidths.indices){
            canvas.drawText(ellipsize(rows[0].getOrElse(c){""},c),x+14*density,headerHeight/2f+5*density,headerPaint)
            canvas.drawLine(x+colWidths[c],0f,x+colWidths[c],headerHeight.toFloat(),linePaint);x+=colWidths[c]
        }
        canvas.drawLine(0f,headerHeight.toFloat(),contentWidth.toFloat(),headerHeight.toFloat(),linePaint)
        canvas.restore()
    }
    private fun ellipsize(value: String, column: Int): String {
        val maxChars = ((colWidths.getOrElse(column){120} - 28*density*zoom) / (7.2f*density*zoom)).toInt().coerceAtLeast(6)
        return if (value.length > maxChars) value.take(maxChars - 1) + "…" else value
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if(scaleDetector.isInProgress)return true
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y; lastX = event.x; lastY = event.y; moved = false
                val cx = event.x + scrollXpx
                var x = 0f
                for (i in colWidths.indices) {
                    x += colWidths[i]
                    if (kotlin.math.abs(cx - x) <= 10*density) {
                        resizingColumn = i; resizeStartX = cx; resizeStartWidth = colWidths[i]; break
                    }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX; val dy = event.y - lastY
                if (kotlin.math.abs(event.x-downX) > 8*density || kotlin.math.abs(event.y-downY) > 8*density) moved = true
                if (resizingColumn >= 0) {
                    val cx = event.x + scrollXpx
                    colWidths[resizingColumn] = (resizeStartWidth + (cx - resizeStartX)).toInt().coerceIn((88*density).toInt(), (420*density).toInt())
                    contentWidth = colWidths.sum(); invalidate(); return true
                }
                scrollXpx -= dx; scrollYpx -= dy; lastX = event.x; lastY = event.y; invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                if (resizingColumn >= 0) { resizingColumn = -1; performClick(); return true }
                if (!moved) {
                    val cx = downX + scrollXpx; val cy = downY + scrollYpx
                    if (cy < headerHeight && cx >= 0) {
                        var x = 0f
                        for (i in colWidths.indices) { x += colWidths[i]; if (cx <= x) { onHeaderClick?.invoke(i); break } }
                    } else if (cy >= headerHeight && cy < headerHeight + (rows.size-1)*rowHeight) {
                        val row = 1 + ((cy - headerHeight) / rowHeight).toInt()
                        if (row in 1 until rows.size) {
                            var x = 0f
                            for (i in colWidths.indices) { x += colWidths[i]; if (cx <= x) { onCellClick?.invoke(rows[row].getOrElse(i){"NULL"}); break } }
                        }
                    }
                }
                performClick(); return true
            }
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
