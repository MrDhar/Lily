package com.maalik.projectlily

import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import java.util.Locale

/** Compact, MySQL-style completion. It is available at every SQL token position. */
class EditorAutocomplete(private val activity: MainActivity) {
    private val editor get() = activity.editorForShortcuts()
    private var popup: PopupWindow? = null
    private var tokenStart = -1
    private var items: List<Item> = emptyList()
    private var selected = 0
    private var generation = 0
    private var cachedDatabaseIdentity = 0
    private var cachedSchemaVersion = -1
    private val columnCache = HashMap<String, List<String>>()
    private data class Item(val text: String, val kind: String)

    private val keywords = listOf("SELECT","FROM","WHERE","INSERT","INTO","VALUES","UPDATE","SET","DELETE","CREATE","TABLE","DROP","ALTER","JOIN","INNER","LEFT","RIGHT","FULL","OUTER","CROSS","NATURAL","ON","USING","GROUP","BY","ORDER","ASC","DESC","HAVING","LIMIT","OFFSET","AS","DISTINCT","AND","OR","NOT","NULL","IS","LIKE","GLOB","REGEXP","IN","BETWEEN","ESCAPE","UNION","INTERSECT","EXCEPT","ALL","CASE","WHEN","THEN","ELSE","END","OVER","PARTITION","ROWS","RANGE","GROUPS","UNBOUNDED","PRECEDING","FOLLOWING","CURRENT","ROW","FILTER","WITH","RECURSIVE","EXISTS","RETURNING","PRIMARY","KEY","FOREIGN","REFERENCES","DEFAULT","UNIQUE","CHECK","CONSTRAINT","AUTOINCREMENT","GENERATED","ALWAYS","STORED","VIRTUAL","WITHOUT","ROWID","STRICT","COLLATE","INDEX","VIEW","TRIGGER","BEFORE","AFTER","INSTEAD","OF","FOR","EACH","BEGIN","CASCADE","RESTRICT","IF","RENAME","COLUMN","TO","ADD","TEMP","TEMPORARY","TRANSACTION","COMMIT","ROLLBACK","SAVEPOINT","RELEASE","ATTACH","DETACH","EXPLAIN","QUERY","PLAN","ANALYZE","VACUUM","PRAGMA","CAST","TRUE","FALSE","CURRENT_DATE","CURRENT_TIME","CURRENT_TIMESTAMP")
    private val functions = listOf("COUNT()","SUM()","AVG()","MIN()","MAX()","TOTAL()","GROUP_CONCAT()","COALESCE()","IFNULL()","NULLIF()","ROUND()","ABS()","LENGTH()","LOWER()","UPPER()","TRIM()","SUBSTR()","REPLACE()","DATE()","TIME()","DATETIME()","STRFTIME()","ROW_NUMBER()","RANK()","DENSE_RANK()","NTILE()","LAG()","LEAD()","FIRST_VALUE()","LAST_VALUE()","NTH_VALUE()")

    fun update() {
        dismiss(); val g=++generation
        if(!editor.hasFocus()||!activity.hasOpenDatabaseForAutocomplete()) return
        val cursor=editor.selectionStart.coerceIn(0,editor.length()); if(editor.selectionStart!=editor.selectionEnd)return
        val before=editor.text.substring(0,cursor); if(insideCommentOrString(before))return
        val m=Regex("[A-Za-z_][A-Za-z0-9_]*$").find(before); val token=m?.value.orEmpty(); val start=cursor-token.length
        val prefix=before.substring(0,start); val qualifier=Regex("([A-Za-z_][A-Za-z0-9_]*)\\.$").find(prefix)?.groupValues?.get(1)
        if(token.isEmpty()&&qualifier==null)return
        val db=activity.databaseForAutocompleteDirect(); val snapshot=before
        activity.backgroundExecutorForAutocompleteDirect().execute {
            val found=try{if(qualifier!=null)qualified(db,snapshot,qualifier,token)else broad(db,snapshot,token)}catch(_:Throwable){emptyList()}
            val result=found.distinctBy{it.kind+"|"+it.text.lowercase(Locale.US)}.take(10)
            activity.runOnUiThread{if(g!=generation||result.isEmpty()||!editor.hasFocus()||editor.selectionStart!=cursor||editor.selectionEnd!=cursor||editor.text.substring(0,cursor)!=snapshot)return@runOnUiThread;show(result,start)}
        }
    }

    private fun broad(db:SQLiteDatabase,before:String,token:String):List<Item>{
        val out=ArrayList<Item>(64); val low=token.lowercase(Locale.US); val tables=ArrayList<String>()
        val identity=System.identityHashCode(db)
        val version=runCatching{db.rawQuery("PRAGMA schema_version",null).use{if(it.moveToFirst())it.getInt(0) else -1}}.getOrDefault(-1)
        synchronized(columnCache){if(identity!=cachedDatabaseIdentity||version!=cachedSchemaVersion){columnCache.clear();cachedDatabaseIdentity=identity;cachedSchemaVersion=version}}
        db.rawQuery("SELECT name FROM sqlite_master WHERE (type='table' OR type='view') AND name NOT LIKE 'sqlite_%' AND name <> 'android_metadata' ORDER BY name",null).use{c->while(c.moveToNext()){val n=c.getString(0);tables.add(n);if(n.lowercase(Locale.US).startsWith(low))out.add(Item(n,"TABLE"))}}
        val seen=HashSet<String>(160)
        for(t in tables.take(80))for(c in columns(db,t))if(seen.add(c.lowercase(Locale.US))&&c.lowercase(Locale.US).startsWith(low))out.add(Item(c,"COL"))
        Regex("\\b(?:FROM|JOIN)\\s+[A-Za-z_][A-Za-z0-9_]*(?:\\s+(?:AS\\s+)?([A-Za-z_][A-Za-z0-9_]*))?",RegexOption.IGNORE_CASE).findAll(before).mapNotNull{it.groupValues.getOrNull(1)?.takeIf{a->a.isNotBlank()}}.distinct().forEach{if(it.startsWith(token,true))out.add(Item(it,"ALIAS"))}
        keywords.asSequence().filter{it.startsWith(token,true)}.take(8).forEach{out.add(Item(it,"SQL"))}
        functions.asSequence().filter{it.substringBefore('(').startsWith(token,true)}.take(6).forEach{out.add(Item(it,"FUNC"))}
        return out.sortedWith(compareBy<Item>({if(it.text.equals(token,true))0 else 1},{when(it.kind){"COL"->0;"TABLE"->1;"ALIAS"->2;"FUNC"->3;else->4}},{it.text.lowercase(Locale.US)}))
    }
    private fun qualified(db:SQLiteDatabase,before:String,q:String,token:String):List<Item>{
        val e=Regex.escape(q); val m=Regex("\\b(?:FROM|JOIN)\\s+([A-Za-z_][A-Za-z0-9_]*)(?:\\s+(?:AS\\s+)?$e)\\b",RegexOption.IGNORE_CASE).findAll(before).lastOrNull(); val table=m?.groupValues?.get(1)?:Regex("\\b(?:FROM|JOIN)\\s+([A-Za-z_][A-Za-z0-9_]*)",RegexOption.IGNORE_CASE).findAll(before).map{it.groupValues[1]}.lastOrNull{it.equals(q,true)}; return if(table!=null)columns(db,table).filter{it.startsWith(token,true)}.map{Item(it,"COL")}else emptyList()
    }
    private fun columns(db:SQLiteDatabase,table:String):List<String>{
        synchronized(columnCache){columnCache[table]?.let{return it}}
        val out=ArrayList<String>();try{db.rawQuery("PRAGMA table_info('${table.replace("'","''")}')",null).use{c->while(c.moveToNext())out.add(c.getString(1))}}catch(_:Throwable){}
        synchronized(columnCache){columnCache[table]=out.toList()};return out
    }
    private fun insideCommentOrString(s:String):Boolean{var q:Char?=null;var line=false;var block=false;var i=0;while(i<s.length){val c=s[i];val n=s.getOrNull(i+1);if(line){if(c=='\n'||c=='\r')line=false;i++;continue};if(block){if(c=='*'&&n=='/'){block=false;i+=2}else i++;continue};if(q!=null){if(c==q){if(n==q){i+=2;continue};q=null};i++;continue};if(c=='-'&&n=='-'){line=true;i+=2;continue};if(c=='/'&&n=='*'){block=true;i+=2;continue};if(c=='\''||c=='"'||c=='`')q=c;i++};return line||block||q!=null}

    private fun show(found:List<Item>,start:Int){dismiss();items=found;selected=0;tokenStart=start
        val list=LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;setPadding(activity.dpForAutocompleteDirect(3),activity.dpForAutocompleteDirect(3),activity.dpForAutocompleteDirect(3),activity.dpForAutocompleteDirect(3));background=activity.roundedForAutocompleteDirect(Color.rgb(20,22,29),1,Color.rgb(53,48,58),8f)}
        found.forEachIndexed{i,item->{val row=LinearLayout(activity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(activity.dpForAutocompleteDirect(5),0,activity.dpForAutocompleteDirect(7),0);isClickable=true};fun paint(on:Boolean){row.background=activity.roundedForAutocompleteDirect(if(on)Color.rgb(48,42,52)else Color.rgb(28,30,38),0,Color.TRANSPARENT,5f)};paint(i==0);val badge=TextView(activity).apply{text=item.kind;textSize=6.7f;setTypeface(null,Typeface.BOLD);setTextColor(Color.rgb(176,178,187));gravity=Gravity.CENTER;setPadding(activity.dpForAutocompleteDirect(4),0,activity.dpForAutocompleteDirect(4),0);background=activity.roundedForAutocompleteDirect(Color.rgb(39,40,47),0,Color.TRANSPARENT,4f)};val label=TextView(activity).apply{text=item.text;textSize=11.5f;setTextColor(activity.whiteForAutocompleteDirect());gravity=Gravity.CENTER_VERTICAL;setSingleLine(true);ellipsize=TextUtils.TruncateAt.END;setPadding(activity.dpForAutocompleteDirect(7),0,0,0);layoutParams=LinearLayout.LayoutParams(0,-1,1f)};row.addView(badge,LinearLayout.LayoutParams(-2,activity.dpForAutocompleteDirect(18)));row.addView(label);row.setOnClickListener{selected=i;accept()};list.addView(row,LinearLayout.LayoutParams(-1,activity.dpForAutocompleteDirect(27)).apply{if(i>0)topMargin=activity.dpForAutocompleteDirect(2)})}}
        popup=PopupWindow(activity).apply{contentView=list;width=activity.dpForAutocompleteDirect(240);height=activity.dpForAutocompleteDirect(6+27*found.size+2*(found.size-1));isFocusable=false;isOutsideTouchable=true;setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));elevation=activity.dpForAutocompleteDirect(7).toFloat()};editor.post{position()}
    }
    private fun position(){val p=popup?:return;if(!editor.isShown)return;val l=editor.layout?:return;val pos=editor.selectionStart.coerceIn(0,editor.length());val line=l.getLineForOffset(pos);val baseline=l.getLineBaseline(line);val x=editor.paddingLeft+l.getPrimaryHorizontal(pos).toInt();val y=baseline-editor.scrollY+editor.paddingTop+activity.dpForAutocompleteDirect(5);val loc=IntArray(2);editor.getLocationOnScreen(loc);val sw=activity.resources.displayMetrics.widthPixels;val sh=activity.resources.displayMetrics.heightPixels;var px=loc[0]+x;var py=loc[1]+y;val w=activity.dpForAutocompleteDirect(240);if(px+w>sw-activity.dpForAutocompleteDirect(8))px=sw-w-activity.dpForAutocompleteDirect(8);if(px<activity.dpForAutocompleteDirect(8))px=activity.dpForAutocompleteDirect(8);if(py+p.height>sh-activity.dpForAutocompleteDirect(8))py=loc[1]+y-p.height-activity.dpForAutocompleteDirect(4);try{p.showAtLocation(editor,Gravity.TOP or Gravity.START,px,py)}catch(_:WindowManager.BadTokenException){dismiss()}}
    fun handleNavigationKey(code:Int):Boolean{if(popup==null)return false;when(code){KeyEvent.KEYCODE_DPAD_DOWN->{move(1);return true};KeyEvent.KEYCODE_DPAD_UP->{move(-1);return true};KeyEvent.KEYCODE_ESCAPE->{dismiss();return true};KeyEvent.KEYCODE_TAB,KeyEvent.KEYCODE_ENTER->{accept();return true}};return false}
    private fun move(d:Int){val list=popup?.contentView as? LinearLayout?:return;if(items.isEmpty())return;selected=(selected+d).mod(items.size);for(i in 0 until list.childCount)list.getChildAt(i).background=activity.roundedForAutocompleteDirect(if(i==selected)Color.rgb(48,42,52)else Color.rgb(28,30,38),0,Color.TRANSPARENT,5f)}
    private fun accept(){val item=items.getOrNull(selected)?:return;val start=tokenStart;val end=editor.selectionStart;if(start in 0..end&&end<=editor.length())try{editor.text.replace(start,end,item.text);val caret=(start+item.text.length-if(item.text.endsWith("()"))1 else 0).coerceAtMost(editor.length());editor.setSelection(caret)}catch(_:Throwable){};dismiss();editor.requestFocus()}
    fun isVisible(): Boolean = popup?.isShowing == true

    fun dismiss(){generation++;popup?.dismiss();popup=null;tokenStart=-1;items=emptyList();selected=0}
}
